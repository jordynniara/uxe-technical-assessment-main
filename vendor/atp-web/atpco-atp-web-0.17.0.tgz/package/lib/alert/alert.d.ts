import { LitElement } from 'lit';
export declare enum AlertColor {
    DANGER = "danger",
    WARNING = "warning",
    INFO = "info"
}
export declare enum AlertAppearance {
    FULL = "full",
    PAGE = "page",
    EXPANDABLE = "expandable",
    TOAST = "toast"
}
/**
 * Alert displays an important message in a way that attracts the user's attention without interrupting the user's task.
 * It can be used as a window-level banner, a page-level banner, or a toast/snackbar notification.
 */
export declare class Alert extends LitElement {
    static styles: import('lit').CSSResult[];
    /**
     * sets the icon in the alert (not used in appearance: page)
     */
    icon?: string;
    /**
     * sets string label shown on the alert
     */
    label: string;
    /**
     * set appearance between full banner, page banner, toast
     */
    appearance: AlertAppearance;
    /**
     * set color
     */
    color: AlertColor;
    /**
     * show 'x' to close banner
     */
    hasClose: boolean;
    _showContent: boolean;
    render(): import('lit-html').TemplateResult<1>;
    private _getClasses;
    _useFocusInverse(): boolean;
    _toggleContent(): void;
    _closeHandler(): void;
    private _getColor;
}
declare global {
    interface HTMLElementTagNameMap {
        'atp-alert': Alert;
    }
}
