import { LitElement } from 'lit';
import { Dropdown } from '../dropdown/dropdown';
import { BadgeConfig } from '../icon/icon';
export interface HeaderActionConfig {
    id: string;
    icon: string;
    size: number;
    label: string;
    badge: BadgeConfig;
    rightAligned?: boolean;
}
/**
 * Header creates the standard page header on ATPCO apps.
 */
export declare class Header extends LitElement {
    static styles: import('lit').CSSResult[];
    /**
     * sets sets title on header
     */
    label: string;
    /**
     * sets current org shown in header
     */
    org: string;
    /**
     * sets whether user can change organizations
     */
    isSwitchable: boolean;
    /**
     * sets whether search is shown
     */
    hasSearch: boolean;
    /**
     * sets icons on the right of the sidebar
     */
    iconActions: HeaderActionConfig[];
    /**
     * set href for home button, if none is provided header will emit
     * homeEventOutput when atpco logo is clicked
     */
    homeHref: string;
    _slottedOrgElements: Dropdown[];
    _slottedDropdownElements: Dropdown[];
    render(): import('lit-html').TemplateResult<1>;
    _searchOpen: boolean;
    _menuMap: {};
    _activeIconId: string;
    firstUpdated(): Promise<void>;
    _setUpSlotMap(): Promise<void>;
    disconnectedCallback(): void;
    _toggleAllWrapper(): void;
    /** TODO: eventually remove hasDropdown arguement as all these toggles should have dropdown */
    _toggleMenu(id: string, status: boolean, hasDropdown?: boolean): void;
    _getSearchClasses(): string;
    _goHome(e: Event): void;
    _searchHandler(): void;
}
declare global {
    interface HTMLElementTagNameMap {
        'atp-header': Header;
    }
}
