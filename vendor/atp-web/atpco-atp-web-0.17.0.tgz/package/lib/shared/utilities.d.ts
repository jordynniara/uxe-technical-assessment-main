export declare function isClickOutside(event: MouseEvent, element: HTMLElement): boolean;
export declare function getUniqueID(id?: string): string;
export interface HDSClassMap {
    [key: string]: boolean;
}
export declare function classMapHDS(classMap: HDSClassMap): string;
