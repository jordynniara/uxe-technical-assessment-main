import { LitElement } from 'lit';
export interface TabConfig {
    name: string;
    badge?: string;
    disabled?: boolean;
    id: string;
    ariaControls?: string;
}
/**
 * Tab Set combines a tab bar with a set of matching tab panels,
 * so that clicking on a tab will show the corresponding
 * tab panel. The tabs and tab panels are zero-indexed.
 */
export declare class TabSet extends LitElement {
    static styles: import('lit').CSSResult[];
    /**
     * set tab items
     */
    tabs: TabConfig[];
    /**
     * set if tab set should take up all available width: default = true
     */
    isFullWidth: boolean;
    /**
     * set tab active index
     */
    activeIndex: number;
    /**
     * sets the value for the aria-label prop on the tablist
     * overriding native prop so that we can pass the value along to the tablist
     */
    ariaLabel: any;
    _lastKeyPressed: string;
    _tabBarRef: HTMLElement;
    render(): import('lit-html').TemplateResult<1>;
    _getTabClasses(item: TabConfig, index: number): string;
    _getTabSetClasses(): string;
    _getTabPanelClasses(index: number): string;
    _onKeyDown(e: KeyboardEvent): Promise<void>;
    connectedCallback(): Promise<void>;
    disconnectedCallback(): void;
    _tabHandler: () => void;
    _clickHandler(i: number): void;
}
declare global {
    interface HTMLElementTagNameMap {
        'atp-tab-set': TabSet;
    }
}
