import { LitElement } from 'lit';
import { MenuListItem } from '../shared/interfaces';
import { VisualPosition } from '../shared/enums';
/**
 * Dropdown creates a menu of user choices that "drops down" from its
 * triggering element. It supports both single and multi-select
 * functionality.
 *
 * It can be used with Button to create a component similar to an
 * HTML <code>&lt;select&gt;</code> element, or used with Input to create
 * a combobox component.
 */
export declare class Dropdown extends LitElement {
    static styles: import('lit').CSSResult[];
    /**
     * Required -- items list in the menu, takes array of MenuListItems.
     */
    itemsList: MenuListItem[];
    /**
     * Required -- indicates if menu is visible or not.
     */
    isMenuVisible: boolean;
    /**
     * set to true to show search input. Default: false
     */
    isSearchVisible: boolean;
    /**
     * use to preset a search value string. Default: ''
     */
    searchValue: string;
    /**
     * set the activeIndex in the list. Default: null
     */
    activeIds: string[];
    /**
     * use to preset search placeholder text. Default: Search
     */
    placeholder: string;
    /**
     * List opens at selected index (if one has been selected)
     */
    openAtActiveIndex: boolean;
    /**
     * send a close output event if a user clicks outside the dropdown while
     * the dropdown is open
     */
    closeOnClickOutside: boolean;
    /**
     * set css value for max height of the dropdown, default: '300px'
     */
    maxHeight: string;
    /**
     * set to true to show checkmarks
     */
    showCheckmarks: boolean;
    /**
     * set menu item description position
     */
    visualPosition: VisualPosition;
    render(): import('lit-html').TemplateResult<1>;
    _childDropdown: Dropdown;
    _hasClickedOnce: boolean;
    _focusIndex: number;
    _titleList: any[];
    _activeItem: {
        position: number;
        id: string;
        children: any[];
        index: number;
    };
    _isKeyboard: boolean;
    constructor();
    get filteredItemList(): MenuListItem[];
    connectedCallback(): void;
    disconnectedCallback(): void;
    updated(changedProps: Map<string, unknown>): Promise<void>;
    _handleChildClick({ detail }: {
        detail: any;
    }): void;
    startKeyScrolling(): void;
    disableKeyScrolling(): void;
    _closeDropdown(): void;
    _clickOutsideHandler: (e: MouseEvent) => void;
    _onClick(item: MenuListItem): void;
    _filterMenuItem(item: MenuListItem): boolean;
    _focusHandler(item: MenuListItem, index: number): void;
    _selectAll(i: number, isDeselectAll: boolean): void;
    _setTitleButtons(): void;
    _handleChildKeydown(e: KeyboardEvent): void;
    _onItemKeydown(e: KeyboardEvent, index: number, isParent?: boolean): void;
    _focusItem(index: number, isHover: boolean, direction?: number, isReturn?: boolean): void;
    _handleOpenAtActive(): Promise<void>;
}
declare global {
    interface HTMLElementTagNameMap {
        'atp-dropdown': Dropdown;
    }
}
