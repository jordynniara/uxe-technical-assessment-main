## 0.17.0 (2026-02-25)

### 🚀 Features

- **lit:** remove focus ring on select
- **lit:** animate solution attempt
- **atp-web:** card - animate collapsibles (pcat-3121)
- **lit:** fix tests
- **hub-ui:** migrate

### 🩹 Fixes

- **atp-web:** remove focus ring on select input
- **lit:** set aspect ratio
- **atp-web:** duplicate export
- add todo

### ❤️ Thank You

- Copilot
- Galen Wilk
- Jeff Yaus
- kdebacker

## 0.16.0 (2026-01-12)

### 🚀 Features

- **atp-web:** input - support textarea
- **atp-web:** rename list to listbounded

### ❤️ Thank You

- Jeff Yaus

## 0.15.0 (2025-12-17)

### 🚀 Features

- **lift:** stop menu focus scroll on hover

### 🩹 Fixes

- **lift:** single org org switcher

### ❤️ Thank You

- kdebacker

## 0.14.0 (2025-12-04)

### 🚀 Features

- **atp-web:** update readme with install instructions
- spacing update
- allow no hub-ui deps

### 🩹 Fixes

- **atp-web:** adjust component description
- **atp-web:** fix for readme

### ❤️ Thank You

- ATP2GXW
- kdebacker

## 0.13.0 (2025-11-25)

### 🚀 Features

- **atp-web:** update readme with install instructions

### 🩹 Fixes

- **atp-web:** add strong box-shadow token

### ❤️ Thank You

- ATP2GXW
