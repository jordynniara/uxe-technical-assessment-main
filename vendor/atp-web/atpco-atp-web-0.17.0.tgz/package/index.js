const B1 = globalThis, ae = B1.ShadowRoot && (B1.ShadyCSS === void 0 || B1.ShadyCSS.nativeShadow) && "adoptedStyleSheets" in Document.prototype && "replace" in CSSStyleSheet.prototype, re = /* @__PURE__ */ Symbol(), ve = /* @__PURE__ */ new WeakMap();
let Me = class {
  constructor(t, i, r) {
    if (this._$cssResult$ = !0, r !== re) throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");
    this.cssText = t, this.t = i;
  }
  get styleSheet() {
    let t = this.o;
    const i = this.t;
    if (ae && t === void 0) {
      const r = i !== void 0 && i.length === 1;
      r && (t = ve.get(i)), t === void 0 && ((this.o = t = new CSSStyleSheet()).replaceSync(this.cssText), r && ve.set(i, t));
    }
    return t;
  }
  toString() {
    return this.cssText;
  }
};
const Pe = (e) => new Me(typeof e == "string" ? e : e + "", void 0, re), g = (e, ...t) => {
  const i = e.length === 1 ? e[0] : t.reduce(((r, a, o) => r + ((s) => {
    if (s._$cssResult$ === !0) return s.cssText;
    if (typeof s == "number") return s;
    throw Error("Value passed to 'css' function must be a 'css' function result: " + s + ". Use 'unsafeCSS' to pass non-literal values, but take care to ensure page security.");
  })(a) + e[o + 1]), e[0]);
  return new Me(i, e, re);
}, Re = (e, t) => {
  if (ae) e.adoptedStyleSheets = t.map(((i) => i instanceof CSSStyleSheet ? i : i.styleSheet));
  else for (const i of t) {
    const r = document.createElement("style"), a = B1.litNonce;
    a !== void 0 && r.setAttribute("nonce", a), r.textContent = i.cssText, e.appendChild(r);
  }
}, ge = ae ? (e) => e : (e) => e instanceof CSSStyleSheet ? ((t) => {
  let i = "";
  for (const r of t.cssRules) i += r.cssText;
  return Pe(i);
})(e) : e;
const { is: De, defineProperty: je, getOwnPropertyDescriptor: Ne, getOwnPropertyNames: Ue, getOwnPropertySymbols: Fe, getPrototypeOf: qe } = Object, N1 = globalThis, me = N1.trustedTypes, Ge = me ? me.emptyScript : "", We = N1.reactiveElementPolyfillSupport, x1 = (e, t) => e, I1 = { toAttribute(e, t) {
  switch (t) {
    case Boolean:
      e = e ? Ge : null;
      break;
    case Object:
    case Array:
      e = e == null ? e : JSON.stringify(e);
  }
  return e;
}, fromAttribute(e, t) {
  let i = e;
  switch (t) {
    case Boolean:
      i = e !== null;
      break;
    case Number:
      i = e === null ? null : Number(e);
      break;
    case Object:
    case Array:
      try {
        i = JSON.parse(e);
      } catch {
        i = null;
      }
  }
  return i;
} }, oe = (e, t) => !De(e, t), fe = { attribute: !0, type: String, converter: I1, reflect: !1, useDefault: !1, hasChanged: oe };
Symbol.metadata ??= /* @__PURE__ */ Symbol("metadata"), N1.litPropertyMetadata ??= /* @__PURE__ */ new WeakMap();
let p1 = class extends HTMLElement {
  static addInitializer(t) {
    this._$Ei(), (this.l ??= []).push(t);
  }
  static get observedAttributes() {
    return this.finalize(), this._$Eh && [...this._$Eh.keys()];
  }
  static createProperty(t, i = fe) {
    if (i.state && (i.attribute = !1), this._$Ei(), this.prototype.hasOwnProperty(t) && ((i = Object.create(i)).wrapped = !0), this.elementProperties.set(t, i), !i.noAccessor) {
      const r = /* @__PURE__ */ Symbol(), a = this.getPropertyDescriptor(t, r, i);
      a !== void 0 && je(this.prototype, t, a);
    }
  }
  static getPropertyDescriptor(t, i, r) {
    const { get: a, set: o } = Ne(this.prototype, t) ?? { get() {
      return this[i];
    }, set(s) {
      this[i] = s;
    } };
    return { get: a, set(s) {
      const p = a?.call(this);
      o?.call(this, s), this.requestUpdate(t, p, r);
    }, configurable: !0, enumerable: !0 };
  }
  static getPropertyOptions(t) {
    return this.elementProperties.get(t) ?? fe;
  }
  static _$Ei() {
    if (this.hasOwnProperty(x1("elementProperties"))) return;
    const t = qe(this);
    t.finalize(), t.l !== void 0 && (this.l = [...t.l]), this.elementProperties = new Map(t.elementProperties);
  }
  static finalize() {
    if (this.hasOwnProperty(x1("finalized"))) return;
    if (this.finalized = !0, this._$Ei(), this.hasOwnProperty(x1("properties"))) {
      const i = this.properties, r = [...Ue(i), ...Fe(i)];
      for (const a of r) this.createProperty(a, i[a]);
    }
    const t = this[Symbol.metadata];
    if (t !== null) {
      const i = litPropertyMetadata.get(t);
      if (i !== void 0) for (const [r, a] of i) this.elementProperties.set(r, a);
    }
    this._$Eh = /* @__PURE__ */ new Map();
    for (const [i, r] of this.elementProperties) {
      const a = this._$Eu(i, r);
      a !== void 0 && this._$Eh.set(a, i);
    }
    this.elementStyles = this.finalizeStyles(this.styles);
  }
  static finalizeStyles(t) {
    const i = [];
    if (Array.isArray(t)) {
      const r = new Set(t.flat(1 / 0).reverse());
      for (const a of r) i.unshift(ge(a));
    } else t !== void 0 && i.push(ge(t));
    return i;
  }
  static _$Eu(t, i) {
    const r = i.attribute;
    return r === !1 ? void 0 : typeof r == "string" ? r : typeof t == "string" ? t.toLowerCase() : void 0;
  }
  constructor() {
    super(), this._$Ep = void 0, this.isUpdatePending = !1, this.hasUpdated = !1, this._$Em = null, this._$Ev();
  }
  _$Ev() {
    this._$ES = new Promise(((t) => this.enableUpdating = t)), this._$AL = /* @__PURE__ */ new Map(), this._$E_(), this.requestUpdate(), this.constructor.l?.forEach(((t) => t(this)));
  }
  addController(t) {
    (this._$EO ??= /* @__PURE__ */ new Set()).add(t), this.renderRoot !== void 0 && this.isConnected && t.hostConnected?.();
  }
  removeController(t) {
    this._$EO?.delete(t);
  }
  _$E_() {
    const t = /* @__PURE__ */ new Map(), i = this.constructor.elementProperties;
    for (const r of i.keys()) this.hasOwnProperty(r) && (t.set(r, this[r]), delete this[r]);
    t.size > 0 && (this._$Ep = t);
  }
  createRenderRoot() {
    const t = this.shadowRoot ?? this.attachShadow(this.constructor.shadowRootOptions);
    return Re(t, this.constructor.elementStyles), t;
  }
  connectedCallback() {
    this.renderRoot ??= this.createRenderRoot(), this.enableUpdating(!0), this._$EO?.forEach(((t) => t.hostConnected?.()));
  }
  enableUpdating(t) {
  }
  disconnectedCallback() {
    this._$EO?.forEach(((t) => t.hostDisconnected?.()));
  }
  attributeChangedCallback(t, i, r) {
    this._$AK(t, r);
  }
  _$ET(t, i) {
    const r = this.constructor.elementProperties.get(t), a = this.constructor._$Eu(t, r);
    if (a !== void 0 && r.reflect === !0) {
      const o = (r.converter?.toAttribute !== void 0 ? r.converter : I1).toAttribute(i, r.type);
      this._$Em = t, o == null ? this.removeAttribute(a) : this.setAttribute(a, o), this._$Em = null;
    }
  }
  _$AK(t, i) {
    const r = this.constructor, a = r._$Eh.get(t);
    if (a !== void 0 && this._$Em !== a) {
      const o = r.getPropertyOptions(a), s = typeof o.converter == "function" ? { fromAttribute: o.converter } : o.converter?.fromAttribute !== void 0 ? o.converter : I1;
      this._$Em = a;
      const p = s.fromAttribute(i, o.type);
      this[a] = p ?? this._$Ej?.get(a) ?? p, this._$Em = null;
    }
  }
  requestUpdate(t, i, r) {
    if (t !== void 0) {
      const a = this.constructor, o = this[t];
      if (r ??= a.getPropertyOptions(t), !((r.hasChanged ?? oe)(o, i) || r.useDefault && r.reflect && o === this._$Ej?.get(t) && !this.hasAttribute(a._$Eu(t, r)))) return;
      this.C(t, i, r);
    }
    this.isUpdatePending === !1 && (this._$ES = this._$EP());
  }
  C(t, i, { useDefault: r, reflect: a, wrapped: o }, s) {
    r && !(this._$Ej ??= /* @__PURE__ */ new Map()).has(t) && (this._$Ej.set(t, s ?? i ?? this[t]), o !== !0 || s !== void 0) || (this._$AL.has(t) || (this.hasUpdated || r || (i = void 0), this._$AL.set(t, i)), a === !0 && this._$Em !== t && (this._$Eq ??= /* @__PURE__ */ new Set()).add(t));
  }
  async _$EP() {
    this.isUpdatePending = !0;
    try {
      await this._$ES;
    } catch (i) {
      Promise.reject(i);
    }
    const t = this.scheduleUpdate();
    return t != null && await t, !this.isUpdatePending;
  }
  scheduleUpdate() {
    return this.performUpdate();
  }
  performUpdate() {
    if (!this.isUpdatePending) return;
    if (!this.hasUpdated) {
      if (this.renderRoot ??= this.createRenderRoot(), this._$Ep) {
        for (const [a, o] of this._$Ep) this[a] = o;
        this._$Ep = void 0;
      }
      const r = this.constructor.elementProperties;
      if (r.size > 0) for (const [a, o] of r) {
        const { wrapped: s } = o, p = this[a];
        s !== !0 || this._$AL.has(a) || p === void 0 || this.C(a, void 0, o, p);
      }
    }
    let t = !1;
    const i = this._$AL;
    try {
      t = this.shouldUpdate(i), t ? (this.willUpdate(i), this._$EO?.forEach(((r) => r.hostUpdate?.())), this.update(i)) : this._$EM();
    } catch (r) {
      throw t = !1, this._$EM(), r;
    }
    t && this._$AE(i);
  }
  willUpdate(t) {
  }
  _$AE(t) {
    this._$EO?.forEach(((i) => i.hostUpdated?.())), this.hasUpdated || (this.hasUpdated = !0, this.firstUpdated(t)), this.updated(t);
  }
  _$EM() {
    this._$AL = /* @__PURE__ */ new Map(), this.isUpdatePending = !1;
  }
  get updateComplete() {
    return this.getUpdateComplete();
  }
  getUpdateComplete() {
    return this._$ES;
  }
  shouldUpdate(t) {
    return !0;
  }
  update(t) {
    this._$Eq &&= this._$Eq.forEach(((i) => this._$ET(i, this[i]))), this._$EM();
  }
  updated(t) {
  }
  firstUpdated(t) {
  }
};
p1.elementStyles = [], p1.shadowRootOptions = { mode: "open" }, p1[x1("elementProperties")] = /* @__PURE__ */ new Map(), p1[x1("finalized")] = /* @__PURE__ */ new Map(), We?.({ ReactiveElement: p1 }), (N1.reactiveElementVersions ??= []).push("2.1.1");
const se = globalThis, S1 = se.trustedTypes, ye = S1 ? S1.createPolicy("lit-html", { createHTML: (e) => e }) : void 0, ze = "$lit$", G = `lit$${Math.random().toFixed(9).slice(2)}$`, Ee = "?" + G, Ke = `<${Ee}>`, r1 = document, k1 = () => r1.createComment(""), $1 = (e) => e === null || typeof e != "object" && typeof e != "function", le = Array.isArray, Ye = (e) => le(e) || typeof e?.[Symbol.iterator] == "function", Y1 = `[ 	
\f\r]`, w1 = /<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g, we = /-->/g, xe = />/g, e1 = RegExp(`>|${Y1}(?:([^\\s"'>=/]+)(${Y1}*=${Y1}*(?:[^ 	
\f\r"'\`<>=]|("|')|))|$)`, "g"), _e = /'/g, ke = /"/g, Ze = /^(?:script|style|textarea|title)$/i, Xe = (e) => (t, ...i) => ({ _$litType$: e, strings: t, values: i }), n = Xe(1), W = /* @__PURE__ */ Symbol.for("lit-noChange"), c = /* @__PURE__ */ Symbol.for("lit-nothing"), $e = /* @__PURE__ */ new WeakMap(), i1 = r1.createTreeWalker(r1, 129);
function Ae(e, t) {
  if (!le(e) || !e.hasOwnProperty("raw")) throw Error("invalid template strings array");
  return ye !== void 0 ? ye.createHTML(t) : t;
}
const Je = (e, t) => {
  const i = e.length - 1, r = [];
  let a, o = t === 2 ? "<svg>" : t === 3 ? "<math>" : "", s = w1;
  for (let p = 0; p < i; p++) {
    const d = e[p];
    let h, f, C = -1, R = 0;
    for (; R < d.length && (s.lastIndex = R, f = s.exec(d), f !== null); ) R = s.lastIndex, s === w1 ? f[1] === "!--" ? s = we : f[1] !== void 0 ? s = xe : f[2] !== void 0 ? (Ze.test(f[2]) && (a = RegExp("</" + f[2], "g")), s = e1) : f[3] !== void 0 && (s = e1) : s === e1 ? f[0] === ">" ? (s = a ?? w1, C = -1) : f[1] === void 0 ? C = -2 : (C = s.lastIndex - f[2].length, h = f[1], s = f[3] === void 0 ? e1 : f[3] === '"' ? ke : _e) : s === ke || s === _e ? s = e1 : s === we || s === xe ? s = w1 : (s = e1, a = void 0);
    const F = s === e1 && e[p + 1].startsWith("/>") ? " " : "";
    o += s === w1 ? d + Ke : C >= 0 ? (r.push(h), d.slice(0, C) + ze + d.slice(C) + G + F) : d + G + (C === -2 ? p : F);
  }
  return [Ae(e, o + (e[i] || "<?>") + (t === 2 ? "</svg>" : t === 3 ? "</math>" : "")), r];
};
class L1 {
  constructor({ strings: t, _$litType$: i }, r) {
    let a;
    this.parts = [];
    let o = 0, s = 0;
    const p = t.length - 1, d = this.parts, [h, f] = Je(t, i);
    if (this.el = L1.createElement(h, r), i1.currentNode = this.el.content, i === 2 || i === 3) {
      const C = this.el.content.firstChild;
      C.replaceWith(...C.childNodes);
    }
    for (; (a = i1.nextNode()) !== null && d.length < p; ) {
      if (a.nodeType === 1) {
        if (a.hasAttributes()) for (const C of a.getAttributeNames()) if (C.endsWith(ze)) {
          const R = f[s++], F = a.getAttribute(C).split(G), O1 = /([.?@])?(.*)/.exec(R);
          d.push({ type: 1, index: o, name: O1[2], strings: F, ctor: O1[1] === "." ? e5 : O1[1] === "?" ? t5 : O1[1] === "@" ? i5 : U1 }), a.removeAttribute(C);
        } else C.startsWith(G) && (d.push({ type: 6, index: o }), a.removeAttribute(C));
        if (Ze.test(a.tagName)) {
          const C = a.textContent.split(G), R = C.length - 1;
          if (R > 0) {
            a.textContent = S1 ? S1.emptyScript : "";
            for (let F = 0; F < R; F++) a.append(C[F], k1()), i1.nextNode(), d.push({ type: 2, index: ++o });
            a.append(C[R], k1());
          }
        }
      } else if (a.nodeType === 8) if (a.data === Ee) d.push({ type: 2, index: o });
      else {
        let C = -1;
        for (; (C = a.data.indexOf(G, C + 1)) !== -1; ) d.push({ type: 7, index: o }), C += G.length - 1;
      }
      o++;
    }
  }
  static createElement(t, i) {
    const r = r1.createElement("template");
    return r.innerHTML = t, r;
  }
}
function u1(e, t, i = e, r) {
  if (t === W) return t;
  let a = r !== void 0 ? i._$Co?.[r] : i._$Cl;
  const o = $1(t) ? void 0 : t._$litDirective$;
  return a?.constructor !== o && (a?._$AO?.(!1), o === void 0 ? a = void 0 : (a = new o(e), a._$AT(e, i, r)), r !== void 0 ? (i._$Co ??= [])[r] = a : i._$Cl = a), a !== void 0 && (t = u1(e, a._$AS(e, t.values), a, r)), t;
}
class Qe {
  constructor(t, i) {
    this._$AV = [], this._$AN = void 0, this._$AD = t, this._$AM = i;
  }
  get parentNode() {
    return this._$AM.parentNode;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  u(t) {
    const { el: { content: i }, parts: r } = this._$AD, a = (t?.creationScope ?? r1).importNode(i, !0);
    i1.currentNode = a;
    let o = i1.nextNode(), s = 0, p = 0, d = r[0];
    for (; d !== void 0; ) {
      if (s === d.index) {
        let h;
        d.type === 2 ? h = new M1(o, o.nextSibling, this, t) : d.type === 1 ? h = new d.ctor(o, d.name, d.strings, this, t) : d.type === 6 && (h = new a5(o, this, t)), this._$AV.push(h), d = r[++p];
      }
      s !== d?.index && (o = i1.nextNode(), s++);
    }
    return i1.currentNode = r1, a;
  }
  p(t) {
    let i = 0;
    for (const r of this._$AV) r !== void 0 && (r.strings !== void 0 ? (r._$AI(t, r, i), i += r.strings.length - 2) : r._$AI(t[i])), i++;
  }
}
class M1 {
  get _$AU() {
    return this._$AM?._$AU ?? this._$Cv;
  }
  constructor(t, i, r, a) {
    this.type = 2, this._$AH = c, this._$AN = void 0, this._$AA = t, this._$AB = i, this._$AM = r, this.options = a, this._$Cv = a?.isConnected ?? !0;
  }
  get parentNode() {
    let t = this._$AA.parentNode;
    const i = this._$AM;
    return i !== void 0 && t?.nodeType === 11 && (t = i.parentNode), t;
  }
  get startNode() {
    return this._$AA;
  }
  get endNode() {
    return this._$AB;
  }
  _$AI(t, i = this) {
    t = u1(this, t, i), $1(t) ? t === c || t == null || t === "" ? (this._$AH !== c && this._$AR(), this._$AH = c) : t !== this._$AH && t !== W && this._(t) : t._$litType$ !== void 0 ? this.$(t) : t.nodeType !== void 0 ? this.T(t) : Ye(t) ? this.k(t) : this._(t);
  }
  O(t) {
    return this._$AA.parentNode.insertBefore(t, this._$AB);
  }
  T(t) {
    this._$AH !== t && (this._$AR(), this._$AH = this.O(t));
  }
  _(t) {
    this._$AH !== c && $1(this._$AH) ? this._$AA.nextSibling.data = t : this.T(r1.createTextNode(t)), this._$AH = t;
  }
  $(t) {
    const { values: i, _$litType$: r } = t, a = typeof r == "number" ? this._$AC(t) : (r.el === void 0 && (r.el = L1.createElement(Ae(r.h, r.h[0]), this.options)), r);
    if (this._$AH?._$AD === a) this._$AH.p(i);
    else {
      const o = new Qe(a, this), s = o.u(this.options);
      o.p(i), this.T(s), this._$AH = o;
    }
  }
  _$AC(t) {
    let i = $e.get(t.strings);
    return i === void 0 && $e.set(t.strings, i = new L1(t)), i;
  }
  k(t) {
    le(this._$AH) || (this._$AH = [], this._$AR());
    const i = this._$AH;
    let r, a = 0;
    for (const o of t) a === i.length ? i.push(r = new M1(this.O(k1()), this.O(k1()), this, this.options)) : r = i[a], r._$AI(o), a++;
    a < i.length && (this._$AR(r && r._$AB.nextSibling, a), i.length = a);
  }
  _$AR(t = this._$AA.nextSibling, i) {
    for (this._$AP?.(!1, !0, i); t !== this._$AB; ) {
      const r = t.nextSibling;
      t.remove(), t = r;
    }
  }
  setConnected(t) {
    this._$AM === void 0 && (this._$Cv = t, this._$AP?.(t));
  }
}
class U1 {
  get tagName() {
    return this.element.tagName;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  constructor(t, i, r, a, o) {
    this.type = 1, this._$AH = c, this._$AN = void 0, this.element = t, this.name = i, this._$AM = a, this.options = o, r.length > 2 || r[0] !== "" || r[1] !== "" ? (this._$AH = Array(r.length - 1).fill(new String()), this.strings = r) : this._$AH = c;
  }
  _$AI(t, i = this, r, a) {
    const o = this.strings;
    let s = !1;
    if (o === void 0) t = u1(this, t, i, 0), s = !$1(t) || t !== this._$AH && t !== W, s && (this._$AH = t);
    else {
      const p = t;
      let d, h;
      for (t = o[0], d = 0; d < o.length - 1; d++) h = u1(this, p[r + d], i, d), h === W && (h = this._$AH[d]), s ||= !$1(h) || h !== this._$AH[d], h === c ? t = c : t !== c && (t += (h ?? "") + o[d + 1]), this._$AH[d] = h;
    }
    s && !a && this.j(t);
  }
  j(t) {
    t === c ? this.element.removeAttribute(this.name) : this.element.setAttribute(this.name, t ?? "");
  }
}
class e5 extends U1 {
  constructor() {
    super(...arguments), this.type = 3;
  }
  j(t) {
    this.element[this.name] = t === c ? void 0 : t;
  }
}
class t5 extends U1 {
  constructor() {
    super(...arguments), this.type = 4;
  }
  j(t) {
    this.element.toggleAttribute(this.name, !!t && t !== c);
  }
}
class i5 extends U1 {
  constructor(t, i, r, a, o) {
    super(t, i, r, a, o), this.type = 5;
  }
  _$AI(t, i = this) {
    if ((t = u1(this, t, i, 0) ?? c) === W) return;
    const r = this._$AH, a = t === c && r !== c || t.capture !== r.capture || t.once !== r.once || t.passive !== r.passive, o = t !== c && (r === c || a);
    a && this.element.removeEventListener(this.name, this, r), o && this.element.addEventListener(this.name, this, t), this._$AH = t;
  }
  handleEvent(t) {
    typeof this._$AH == "function" ? this._$AH.call(this.options?.host ?? this.element, t) : this._$AH.handleEvent(t);
  }
}
class a5 {
  constructor(t, i, r) {
    this.element = t, this.type = 6, this._$AN = void 0, this._$AM = i, this.options = r;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  _$AI(t) {
    u1(this, t);
  }
}
const r5 = se.litHtmlPolyfillSupport;
r5?.(L1, M1), (se.litHtmlVersions ??= []).push("3.3.1");
const o5 = (e, t, i) => {
  const r = i?.renderBefore ?? t;
  let a = r._$litPart$;
  if (a === void 0) {
    const o = i?.renderBefore ?? null;
    r._$litPart$ = a = new M1(t.insertBefore(k1(), o), o, void 0, i ?? {});
  }
  return a._$AI(e), a;
};
const ne = globalThis;
let b = class extends p1 {
  constructor() {
    super(...arguments), this.renderOptions = { host: this }, this._$Do = void 0;
  }
  createRenderRoot() {
    const t = super.createRenderRoot();
    return this.renderOptions.renderBefore ??= t.firstChild, t;
  }
  update(t) {
    const i = this.render();
    this.hasUpdated || (this.renderOptions.isConnected = this.isConnected), super.update(t), this._$Do = o5(i, this.renderRoot, this.renderOptions);
  }
  connectedCallback() {
    super.connectedCallback(), this._$Do?.setConnected(!0);
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this._$Do?.setConnected(!1);
  }
  render() {
    return W;
  }
};
b._$litElement$ = !0, b.finalized = !0, ne.litElementHydrateSupport?.({ LitElement: b });
const s5 = ne.litElementPolyfillSupport;
s5?.({ LitElement: b });
(ne.litElementVersions ??= []).push("4.2.1");
const u = (e) => (t, i) => {
  i !== void 0 ? i.addInitializer((() => {
    customElements.define(e, t);
  })) : customElements.define(e, t);
};
const l5 = { attribute: !0, type: String, converter: I1, reflect: !1, hasChanged: oe }, n5 = (e = l5, t, i) => {
  const { kind: r, metadata: a } = i;
  let o = globalThis.litPropertyMetadata.get(a);
  if (o === void 0 && globalThis.litPropertyMetadata.set(a, o = /* @__PURE__ */ new Map()), r === "setter" && ((e = Object.create(e)).wrapped = !0), o.set(i.name, e), r === "accessor") {
    const { name: s } = i;
    return { set(p) {
      const d = t.get.call(this);
      t.set.call(this, p), this.requestUpdate(s, d, e);
    }, init(p) {
      return p !== void 0 && this.C(s, void 0, e, p), p;
    } };
  }
  if (r === "setter") {
    const { name: s } = i;
    return function(p) {
      const d = this[s];
      t.call(this, p), this.requestUpdate(s, d, e);
    };
  }
  throw Error("Unsupported decorator location: " + r);
};
function l(e) {
  return (t, i) => typeof i == "object" ? n5(e, t, i) : ((r, a, o) => {
    const s = a.hasOwnProperty(o);
    return a.constructor.createProperty(o, r), s ? Object.getOwnPropertyDescriptor(a, o) : void 0;
  })(e, t, i);
}
function d5(e) {
  return l({ ...e, state: !0, attribute: !1 });
}
const Oe = (e, t, i) => (i.configurable = !0, i.enumerable = !0, Reflect.decorate && typeof t != "object" && Object.defineProperty(e, t, i), i);
function F1(e, t) {
  return (i, r, a) => {
    const o = (s) => s.renderRoot?.querySelector(e) ?? null;
    return Oe(i, r, { get() {
      return o(this);
    } });
  };
}
function z1(e) {
  return (t, i) => {
    const { slot: r, selector: a } = e ?? {}, o = "slot" + (r ? `[name=${r}]` : ":not([name])");
    return Oe(t, i, { get() {
      const s = this.renderRoot?.querySelector(o), p = s?.assignedElements(e) ?? [];
      return a === void 0 ? p : p.filter(((d) => d.matches(a)));
    } });
  };
}
const c5 = g`
  .alert {
    display: flex;
    align-items: center;
    gap: var(--atp-space-s);
    min-block-size: 48px;
    font-family: var(--atpco-font-family);
    font-size: var(--atp-font-size-body-s);
    font-weight: var(--atp-font-weight-semibold);
    line-height: var(--atp-line-height-body-s);
  }

  .alert .label-button-container {
    display: flex;
    align-items: center;
    gap: var(--atp-space-xs);
  }

  .buttons {
    display: flex;
    gap: var(--atp-space-xs);
  }

  .alert.full {
    padding: 0 40px;
    justify-content: space-between;
  }

  :where(.toast, .expandable, .page) {
    padding: 0 var(--atp-space-s);
    border-radius: var(--atp-border-radius-m);
    justify-content: flex-start;
  }

  .page .label-button-container {
    gap: var(--atp-space-s);
    flex-grow: 1;
  }

  :is(.toast, .expandable) .label-button-container {
    justify-content: space-between;
    flex-grow: 1;
  }

  .page.info {
    border: 1px solid var(--atp-content-primary-medium-enabled);
    background: var(--atp-element-fill-blue-medium-enabled);
    color: var(--atp-content-primary-medium-enabled);
  }

  .page.danger {
    border: 1px solid var(--atp-danger-primary-strong-enabled);
    background: var(--atp-element-fill-red-weak-enabled);
    color: var(--atp-danger-primary-strong-enabled);
  }

  .page.warning {
    border: 1px solid var(--atp-element-fill-orange-strong-enabled);
    background: var(--atp-element-fill-orange-weak-enabled);
    color: var(--atp-content-primary-medium-enabled);
  }

  .toast.info {
    color: var(--atp-content-inverse-medium-enabled);
    background: var(--atp-element-fill-primary-strong-enabled);
  }

  .expandable.info,
  .full.info {
    background: var(--atp-element-fill-blue-strong-enabled);
    color: var(--atp-content-inverse-medium-enabled);
  }

  .danger:where(.toast, .expandable, .full) {
    color: var(--atp-content-inverse-medium-enabled);
    background: var(--atp-danger-primary-strong-enabled);
  }

  .warning:where(.toast, .expandable, .full) {
    color: var(--atp-content-primary-medium-enabled);
    background: var(--atp-element-fill-orange-strong-enabled);
  }

  .expandable.open {
    border-radius: var(--atp-border-radius-m) var(--atp-border-radius-m) 0 0;
  }

  .outer-wrapper:has(.toast),
  .outer-wrapper:has(.expandable) {
    box-shadow: var(--atp-box-shadow-toast);
    border-radius: var(--atp-border-radius-m);
  }

  .content-wrapper {
    border-radius: 0 0 var(--atp-border-radius-m) var(--atp-border-radius-m);
    border: 1px solid var(--atp-element-fill-blue-strong-enabled);
    background: var(--atp-element-fill-blue-medium-enabled);
  }

  .danger + .content-wrapper {
    border: 1px solid var(--atp-danger-primary-strong-enabled);
    background: var(--atp-element-fill-red-weak-enabled);
  }

  .warning + .content-wrapper {
    border: 1px solid var(--atp-element-fill-orange-strong-enabled);
    background: var(--atp-element-fill-orange-weak-enabled);
  }

  .toggle {
    transition: 0.2s ease-out;
  }

  .toggle.rotate {
    transform: rotate(-90deg);
  }
`, p5 = g`
  :host {
    display: inline-flex;
    align-items: center;
    justify-content: center;
  }

  .icon-container {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    inline-size: fit-content;
    position: relative;
  }

  .icon-container .icon {
    fill: var(--atp-icon-fill, var(--atp-slate-900));
  }

  .badge {
    position: absolute;
    inset-block-end: 50%;
    inset-inline-start: 50%;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    block-size: calc(var(--atp-line-height-body-xs) + 2 * (var(--atp-space-xxxs)));
    inline-size: auto;
    aspect-ratio: 1;
    font-family: var(--atpco-font-family);
    font-size: var(--atp-font-size-body-xs);
    font-weight: var(--atp-font-weight-regular);
    line-height: var(--atp-line-height-body-xs);
    text-align: center;
    vertical-align: middle;
    border-radius: 50%;
  }
`;
const de = { ATTRIBUTE: 1, CHILD: 2 }, ce = (e) => (...t) => ({ _$litDirective$: e, values: t });
class pe {
  constructor(t) {
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  _$AT(t, i, r) {
    this._$Ct = t, this._$AM = i, this._$Ci = r;
  }
  _$AS(t, i) {
    return this.update(t, i);
  }
  update(t, i) {
    return this.render(...i);
  }
}
let Q1 = class extends pe {
  constructor(t) {
    if (super(t), this.it = c, t.type !== de.CHILD) throw Error(this.constructor.directiveName + "() can only be used in child bindings");
  }
  render(t) {
    if (t === c || t == null) return this._t = void 0, this.it = t;
    if (t === W) return t;
    if (typeof t != "string") throw Error(this.constructor.directiveName + "() called with a non-string value");
    if (t === this.it) return this._t;
    this.it = t;
    const i = [t];
    return i.raw = i, this._t = { _$litType$: this.constructor.resultType, strings: i, values: [] };
  }
};
Q1.directiveName = "unsafeHTML", Q1.resultType = 1;
const Le = ce(Q1), He = {
  "icon-search": `<symbol id="icon-search" viewBox="0 0 16 16">
      <path
        
        d="M15.75 14.7188C16.0625 15.0729 16.0729 15.4271 15.7812 15.7812C15.6354 15.9271 15.4583 16 15.25 16C15.0625 16 14.875 15.9271 14.6875 15.7812L10.5 11.5938C9.375 12.5104 8.03125 12.9792 6.46875 13C4.63542 12.9583 3.11458 12.3229 1.90625 11.0938C0.677083 9.86458 0.0416667 8.33333 0 6.5C0.0416667 4.66667 0.666667 3.13542 1.875 1.90625C3.10417 0.677083 4.63542 0.0416667 6.46875 0C8.30208 0.0416667 9.83333 0.677083 11.0625 1.90625C12.2917 3.13542 12.9271 4.66667 12.9688 6.5C12.9479 8.04167 12.4792 9.38542 11.5625 10.5312L15.75 14.7188ZM1.5 6.5C1.54167 7.91667 2.03125 9.09375 2.96875 10.0312C3.90625 10.9688 5.08333 11.4583 6.5 11.5C7.91667 11.4583 9.09375 10.9688 10.0312 10.0312C10.9688 9.09375 11.4583 7.91667 11.5 6.5C11.4583 5.08333 10.9688 3.90625 10.0312 2.96875C9.09375 2.03125 7.91667 1.54167 6.5 1.5C5.08333 1.54167 3.90625 2.03125 2.96875 2.96875C2.03125 3.90625 1.54167 5.08333 1.5 6.5Z"
      />
    </symbol>`,
  "icon-paperclip-vertical": `<symbol id="icon-paperclip-vertical" viewBox="0 0 16 16">
      <path
        
        d="M7.5 16C6.22917 15.9583 5.16667 15.5208 4.3125 14.6875C3.47917 13.8333 3.04167 12.7708 3 11.5V3.375C3.02083 2.41667 3.35417 1.625 4 1C4.625 0.354167 5.41667 0.0208333 6.375 0C7.33333 0.0208333 8.125 0.354167 8.75 1C9.39583 1.625 9.72917 2.41667 9.75 3.375V10.75C9.72917 11.3958 9.51042 11.9271 9.09375 12.3438C8.67708 12.7604 8.14583 12.9792 7.5 13C6.85417 12.9792 6.32292 12.7604 5.90625 12.3438C5.48958 11.9271 5.27083 11.3958 5.25 10.75V4.75C5.29167 4.29167 5.54167 4.04167 6 4C6.45833 4.04167 6.70833 4.29167 6.75 4.75V10.75C6.79167 11.2083 7.04167 11.4583 7.5 11.5C7.95833 11.4583 8.20833 11.2083 8.25 10.75V3.375C8.22917 2.85417 8.04167 2.41667 7.6875 2.0625C7.33333 1.70833 6.89583 1.52083 6.375 1.5C5.85417 1.52083 5.41667 1.70833 5.0625 2.0625C4.70833 2.41667 4.52083 2.85417 4.5 3.375V11.5C4.52083 12.3542 4.8125 13.0625 5.375 13.625C5.9375 14.1875 6.64583 14.4792 7.5 14.5C8.35417 14.4792 9.0625 14.1875 9.625 13.625C10.1875 13.0625 10.4792 12.3542 10.5 11.5V4.75C10.5417 4.29167 10.7917 4.04167 11.25 4C11.7083 4.04167 11.9583 4.29167 12 4.75V11.5C11.9583 12.7708 11.5208 13.8333 10.6875 14.6875C9.83333 15.5208 8.77083 15.9583 7.5 16Z"
      />
    </symbol>`,
  "icon-x": `<symbol id="icon-x" viewBox="0 0 384 512">
      <path
        
        d="M345 137c9.4-9.4 9.4-24.6 0-33.9s-24.6-9.4-33.9 0l-119 119L73 103c-9.4-9.4-24.6-9.4-33.9 0s-9.4 24.6 0 33.9l119 119L39 375c-9.4 9.4-9.4 24.6 0 33.9s24.6 9.4 33.9 0l119-119L311 409c9.4 9.4 24.6 9.4 33.9 0s9.4-24.6 0-33.9l-119-119L345 137z"
      />
    </symbol>`,
  "icon-xmark": `<symbol id="icon-xmark" viewBox="0 0 384 512">
      <path
        
        d="M345 137c9.4-9.4 9.4-24.6 0-33.9s-24.6-9.4-33.9 0l-119 119L73 103c-9.4-9.4-24.6-9.4-33.9 0s-9.4 24.6 0 33.9l119 119L39 375c-9.4 9.4-9.4 24.6 0 33.9s24.6 9.4 33.9 0l119-119L311 409c9.4 9.4 24.6 9.4 33.9 0s9.4-24.6 0-33.9l-119-119L345 137z"
      />
    </symbol>`,
  "icon-upload": `<symbol id="icon-upload" viewBox="0 0 16 16">
      <path
        
        d="M14 9.5C14.5625 9.52083 15.0312 9.71875 15.4062 10.0938C15.7812 10.4688 15.9792 10.9375 16 11.5V14C15.9792 14.5625 15.7812 15.0312 15.4062 15.4062C15.0312 15.7812 14.5625 15.9792 14 16H2C1.4375 15.9792 0.96875 15.7812 0.59375 15.4062C0.21875 15.0312 0.0208333 14.5625 0 14V11.5C0.0208333 10.9375 0.21875 10.4688 0.59375 10.0938C0.96875 9.71875 1.4375 9.52083 2 9.5H6V11H2C1.6875 11.0208 1.52083 11.1875 1.5 11.5V14C1.52083 14.3125 1.6875 14.4792 2 14.5H14C14.3125 14.4792 14.4792 14.3125 14.5 14V11.5C14.4792 11.1875 14.3125 11.0208 14 11H10V9.5H14ZM4.25 5.5C3.91667 5.8125 3.57292 5.82292 3.21875 5.53125C2.92708 5.17708 2.92708 4.82292 3.21875 4.46875L7.46875 0.21875C7.82292 -0.0729167 8.17708 -0.0729167 8.53125 0.21875L12.7812 4.46875C13.0729 4.82292 13.0729 5.17708 12.7812 5.53125C12.6354 5.67708 12.4583 5.75 12.25 5.75C12.0417 5.75 11.8646 5.67708 11.7188 5.53125L8.75 2.5625V11C8.70833 11.4583 8.45833 11.7083 8 11.75C7.54167 11.7083 7.29167 11.4583 7.25 11V2.5625L4.25 5.5ZM13.5 12.75C13.4583 13.2083 13.2083 13.4583 12.75 13.5C12.2917 13.4583 12.0417 13.2083 12 12.75C12.0417 12.2917 12.2917 12.0417 12.75 12C13.2083 12.0417 13.4583 12.2917 13.5 12.75Z"
      />
    </symbol>`,
  "icon-download": `<symbol id="icon-download" viewBox="0 0 16 16">
      <path
        
        d="M14 9.5C14.5625 9.52083 15.0312 9.71875 15.4062 10.0938C15.7812 10.4688 15.9792 10.9375 16 11.5V14C15.9792 14.5625 15.7812 15.0312 15.4062 15.4062C15.0312 15.7812 14.5625 15.9792 14 16H2C1.4375 15.9792 0.96875 15.7812 0.59375 15.4062C0.21875 15.0312 0.0208333 14.5625 0 14V11.5C0.0208333 10.9375 0.21875 10.4688 0.59375 10.0938C0.96875 9.71875 1.4375 9.52083 2 9.5H3.6875L5.1875 11H2C1.6875 11.0208 1.52083 11.1875 1.5 11.5V14C1.52083 14.3125 1.6875 14.4792 2 14.5H14C14.3125 14.4792 14.4792 14.3125 14.5 14V11.5C14.4792 11.1875 14.3125 11.0208 14 11H10.8438L12.3438 9.5H14ZM13.5 12.75C13.4583 13.2083 13.2083 13.4583 12.75 13.5C12.2917 13.4583 12.0417 13.2083 12 12.75C12.0417 12.2917 12.2917 12.0417 12.75 12C13.2083 12.0417 13.4583 12.2917 13.5 12.75ZM7.46875 11.5L3.1875 7.28125C2.89583 6.92708 2.89583 6.57292 3.1875 6.21875C3.54167 5.92708 3.89583 5.92708 4.25 6.21875L7.25 9.1875V0.75C7.29167 0.291667 7.54167 0.0416667 8 0C8.45833 0.0416667 8.70833 0.291667 8.75 0.75V9.1875L11.7188 6.21875C12.0729 5.92708 12.4271 5.92708 12.7812 6.21875C13.0729 6.57292 13.0729 6.92708 12.7812 7.28125L8.53125 11.5312C8.38542 11.6771 8.20833 11.75 8 11.75C7.79167 11.75 7.61458 11.6667 7.46875 11.5Z"
      />
    </symbol>`,
  "icon-trending-down": `<symbol id="icon-trending-down" viewBox="0 0 18 16">
      <path
        
        d="M18 6.75V12.25C17.9583 12.7083 17.7083 12.9583 17.25 13H11.75C11.2917 12.9583 11.0417 12.7083 11 12.25C11.0417 11.7917 11.2917 11.5417 11.75 11.5H15.4375L10 6.0625L6.5 9.5C6.375 9.66667 6.20833 9.75 6 9.75C5.79167 9.75 5.61458 9.66667 5.46875 9.5L0.21875 4.25C0.0729167 4.125 0 3.95833 0 3.75C0.0416667 3.29167 0.291667 3.04167 0.75 3C0.958333 3 1.13542 3.07292 1.28125 3.21875L6 7.9375L9.46875 4.46875C9.61458 4.32292 9.79167 4.25 10 4.25C10.2083 4.25 10.3854 4.32292 10.5312 4.46875L16.5 10.4375V6.75C16.5417 6.29167 16.7917 6.04167 17.25 6C17.7083 6.04167 17.9583 6.29167 18 6.75Z"
      />
    </symbol>`,
  "icon-trending-up": `<symbol id="icon-trending-up" viewBox="0 0 18 16">
      <path
        
        d="M18 3.75V9.25C17.9583 9.70833 17.7083 9.95833 17.25 10C16.7917 9.95833 16.5417 9.70833 16.5 9.25V5.5625L10.5312 11.5312C10.3854 11.6771 10.2083 11.75 10 11.75C9.79167 11.75 9.61458 11.6771 9.46875 11.5312L6 8.0625L1.28125 12.7812C1.13542 12.9271 0.958333 13 0.75 13C0.458333 12.9792 0.260417 12.8854 0.15625 12.7188C0.0520833 12.5312 0 12.375 0 12.25C0 12.0417 0.0729167 11.8646 0.21875 11.7188L5.46875 6.46875C5.61458 6.32292 5.79167 6.25 6 6.25C6.20833 6.25 6.38542 6.32292 6.53125 6.46875L10 9.9375L15.4375 4.5H11.75C11.2917 4.45833 11.0417 4.20833 11 3.75C11.0417 3.29167 11.2917 3.04167 11.75 3H17.25C17.7083 3.04167 17.9583 3.29167 18 3.75Z"
      />
    </symbol>`,
  "icon-expand-less": `<symbol id="icon-expand-less" viewBox="0 0 32 18">
      <path
        id="expand-less"
        d="M15.7-14.3,30,0l1.406-1.406-15.7-15.7L0-1.406,1.406,0Z"
        transform="translate(0 17.109)"
      />
    </symbol>`,
  "icon-help-filled": `<symbol id="icon-help-filled" viewBox="0 0 30 30">
      <path
        id="help-filled"
        d="M15,30a14.914,14.914,0,0,1-3.992-.531A14.973,14.973,0,0,1,.531,18.992a15.271,15.271,0,0,1,0-7.984A14.977,14.977,0,0,1,11.008.531a15.271,15.271,0,0,1,7.984,0A14.97,14.97,0,0,1,29.469,11.008a15.271,15.271,0,0,1,0,7.984A14.966,14.966,0,0,1,18.992,29.469,14.9,14.9,0,0,1,15,30Zm-1-8v2h2V22Zm.84-13a2.77,2.77,0,0,1,2.753,1.462A3.564,3.564,0,0,1,18,12a2.254,2.254,0,0,1-1.169,2.143c-.227.176-.346.269-.455.356C14.644,15.884,14,17.374,14,20h2c0-2,.395-2.956,1.625-3.939.095-.076.2-.157.409-.32l.028-.022A4.128,4.128,0,0,0,20,12a5.423,5.423,0,0,0-.633-2.462A4.756,4.756,0,0,0,14.84,7a4.416,4.416,0,0,0-4.262,2.567A5.723,5.723,0,0,0,10,12h2a3.872,3.872,0,0,1,.382-1.567A2.445,2.445,0,0,1,14.84,9Z"
      />
    </symbol>`,
  "icon-filter": `<symbol id="icon-filter" viewBox="0 0 16 16">
      <path
        
        d="M15.8804 0.84375C16.1096 1.38542 16.0366 1.88542 15.6616 2.34375L10.5054 8.6875V12.8125C10.5054 13.1458 10.3908 13.4271 10.1616 13.6562C9.93247 13.8854 9.64081 14 9.28664 14C9.03664 14 8.80747 13.9271 8.59914 13.7812L6.03664 11.7812C5.7033 11.5312 5.52622 11.2083 5.50539 10.8125V8.6875L0.349138 2.34375C-0.0258621 1.88542 -0.0987787 1.38542 0.130388 0.84375C0.401221 0.302083 0.849138 0.0208333 1.47414 0H14.5366C15.1616 0.0208333 15.6096 0.302083 15.8804 0.84375ZM9.22414 7.84375L14.4116 1.5H1.59914L6.78664 7.875C6.93247 8.0625 7.00539 8.27083 7.00539 8.5V10.6562L9.00539 12.1875V8.46875C9.00539 8.23958 9.07831 8.03125 9.22414 7.84375Z"
      />
    </symbol>`,
  "icon-filter-filled": `<symbol id="icon-filter-filled" viewBox="0 0 32 28">
      <path id="filter-filled" d="M0,0H32V3.422l-12,12V28H12V15.422l-12-12Z" />
    </symbol>`,
  "icon-expand-more": `<symbol id="icon-expand-more" viewBox="0 0 32 18">
      <path id="expand-more" d="M15.7,14.3,30,0l1.406,1.406-15.7,15.7L0,1.406,1.406,0Z" />
    </symbol>`,
  "icon-help": `<symbol id="icon-help" viewBox="0 0 16 16">
      <path
        
        d="M8 0C9.5 0.0208333 10.8438 0.385417 12.0312 1.09375C13.2396 1.80208 14.1979 2.76042 14.9062 3.96875C15.6146 5.15625 15.9792 6.5 16 8C15.9792 9.5 15.6146 10.8438 14.9062 12.0312C14.1979 13.2396 13.2396 14.1979 12.0312 14.9062C10.8438 15.6146 9.5 15.9792 8 16C6.5 15.9792 5.15625 15.6146 3.96875 14.9062C2.76042 14.1979 1.80208 13.2396 1.09375 12.0312C0.385417 10.8438 0.0208333 9.5 0 8C0.0208333 6.5 0.385417 5.15625 1.09375 3.96875C1.80208 2.76042 2.76042 1.80208 3.96875 1.09375C5.15625 0.385417 6.5 0.0208333 8 0ZM8 14.5C9.83333 14.4583 11.3646 13.8229 12.5938 12.5938C13.8229 11.3646 14.4583 9.83333 14.5 8C14.4583 6.16667 13.8229 4.63542 12.5938 3.40625C11.3646 2.17708 9.83333 1.54167 8 1.5C6.16667 1.54167 4.63542 2.17708 3.40625 3.40625C2.17708 4.63542 1.54167 6.16667 1.5 8C1.54167 9.83333 2.17708 11.3646 3.40625 12.5938C4.63542 13.8229 6.16667 14.4583 8 14.5ZM8 10.5C8.27083 10.5 8.5 10.5938 8.6875 10.7812C8.89583 10.9688 9 11.2083 9 11.5C9 11.7917 8.89583 12.0312 8.6875 12.2188C8.5 12.4062 8.27083 12.5 8 12.5C7.375 12.4583 7.04167 12.125 7 11.5C7 11.2083 7.09375 10.9688 7.28125 10.7812C7.46875 10.5938 7.70833 10.5 8 10.5ZM9.03125 4C9.67708 4.02083 10.1979 4.22917 10.5938 4.625C11.0104 5.04167 11.2188 5.5625 11.2188 6.1875C11.1979 6.97917 10.8438 7.60417 10.1562 8.0625L8.75 8.9375V9C8.70833 9.45833 8.45833 9.70833 8 9.75C7.54167 9.70833 7.29167 9.45833 7.25 9V8.5C7.25 8.22917 7.375 8.01042 7.625 7.84375L9.40625 6.75C9.63542 6.625 9.75 6.4375 9.75 6.1875C9.70833 5.77083 9.45833 5.54167 9 5.5H7.40625C7.01042 5.54167 6.79167 5.77083 6.75 6.1875C6.70833 6.64583 6.45833 6.89583 6 6.9375C5.54167 6.89583 5.29167 6.64583 5.25 6.1875C5.27083 5.5625 5.47917 5.04167 5.875 4.625C6.29167 4.22917 6.8125 4.02083 7.4375 4H9.03125Z"
      />
    </symbol>`,
  "icon-info-filled": `<symbol id="icon-info-filled" viewBox="0 0 30 30">
      <path
        id="info-filled"
        d="M15,30A15,15,0,0,1,4.393,4.393,15,15,0,1,1,25.606,25.606,14.9,14.9,0,0,1,15,30ZM14,12V22h2V12Zm0-4v2h2V8Z"
      />
    </symbol>`,
  "icon-chevron-left": `<symbol id="icon-chevron-left" viewBox="0 0 16 16">
      <path
        
        d="M9.96875 14.7726L4.25 8.56845C4.08333 8.35189 4 8.157 4 7.98376C4 7.78886 4.07292 7.60479 4.21875 7.43155L9.9375 1.22738C10.2708 0.924207 10.625 0.924207 11 1.22738C11.2917 1.57386 11.2917 1.942 11 2.33179L5.78125 7.98376L11.0312 13.6682C11.3229 14.058 11.3229 14.4261 11.0312 14.7726C10.6562 15.0758 10.3021 15.0758 9.96875 14.7726Z"
      />
    </symbol>`,
  "icon-chevron-right": `<symbol id="icon-chevron-right" viewBox="0 0 16 16">
      <path
        
        d="M5.78125 1.22777L11.5 7.47517C11.6458 7.62701 11.7188 7.80055 11.7188 7.99578C11.7188 8.19101 11.6458 8.3754 11.5 8.54894L5.78125 14.7638C5.44792 15.0675 5.09375 15.0783 4.71875 14.7963C4.42708 14.4276 4.42708 14.0588 4.71875 13.69L9.96875 7.96324L4.71875 2.33408C4.42708 1.94362 4.42708 1.57485 4.71875 1.22777C5.09375 0.924077 5.44792 0.924077 5.78125 1.22777Z"
      />
    </symbol>`,
  "icon-chevron-down": `<symbol id="icon-chevron-down" viewBox="0 0 16 16">
      <path
        
        d="M14.7731 5.78125L8.58333 11.5C8.36728 11.6667 8.17284 11.75 8 11.75C7.80556 11.75 7.62191 11.6771 7.44907 11.5312L1.22685 5.78125C1.07562 5.63542 1 5.45833 1 5.25C1 5.04167 1.07562 4.86458 1.22685 4.71875C1.57253 4.42708 1.93981 4.42708 2.3287 4.71875L8 9.96875L13.6713 4.71875C14.0602 4.42708 14.4275 4.4375 14.7731 4.75C14.9244 4.875 15 5.04167 15 5.25C15 5.45833 14.9244 5.63542 14.7731 5.78125Z"
      />
    </symbol>`,
  "icon-chevron-up": `<symbol id="icon-chevron-up" viewBox="0 0 16 16">
      <path
        
        d="M1.22738 10L7.46404 4.28125C7.63728 4.09375 7.82135 4 8.01624 4C8.21114 4 8.39521 4.07292 8.56845 4.21875L14.7726 9.9375C15.0758 10.2917 15.0758 10.6458 14.7726 11C14.4261 11.2917 14.058 11.3021 13.6682 11.0312L8.01624 5.8125L2.33179 11.0625C1.942 11.3542 1.57386 11.3438 1.22738 11.0312C0.924207 10.6771 0.924207 10.3333 1.22738 10Z"
      />
    </symbol>`,
  "icon-compress": `<symbol id="icon-compress" viewBox="0 0 16 16">
      <path
        
        d="M11.75 7C11.2917 6.95833 11.0417 6.70833 11 6.25V2.75C11.0417 2.29167 11.2917 2.04167 11.75 2C12.2083 2.04167 12.4583 2.29167 12.5 2.75V5.5H15.25C15.7083 5.54167 15.9583 5.79167 16 6.25C15.9583 6.70833 15.7083 6.95833 15.25 7H11.75ZM4.25 9C4.70833 9.04167 4.95833 9.29167 5 9.75V13.25C4.95833 13.7083 4.70833 13.9583 4.25 14C3.79167 13.9583 3.54167 13.7083 3.5 13.25V10.5H0.75C0.291667 10.4583 0.0416667 10.2083 0 9.75C0.0416667 9.29167 0.291667 9.04167 0.75 9H4.25ZM15.25 9C15.7083 9.04167 15.9583 9.29167 16 9.75C15.9583 10.2083 15.7083 10.4583 15.25 10.5H12.5V13.25C12.4583 13.7083 12.2083 13.9583 11.75 14C11.2917 13.9583 11.0417 13.7083 11 13.25V9.75C11.0417 9.29167 11.2917 9.04167 11.75 9H15.25ZM4.25 2C4.70833 2.04167 4.95833 2.29167 5 2.75V6.25C4.95833 6.70833 4.70833 6.95833 4.25 7H0.75C0.291667 6.95833 0.0416667 6.70833 0 6.25C0.0416667 5.79167 0.291667 5.54167 0.75 5.5H3.5V2.75C3.54167 2.29167 3.79167 2.04167 4.25 2Z"
      />
    </symbol>`,
  "icon-delete": `<symbol id="icon-delete" viewBox="0 0 16 16">
      <path
        
        d="M14.5 2.5C14.8125 2.52083 14.9792 2.6875 15 3V3.5C14.9792 3.8125 14.8125 3.97917 14.5 4H14V14C13.9792 14.5625 13.7812 15.0312 13.4062 15.4062C13.0312 15.7812 12.5625 15.9792 12 16H4C3.4375 15.9792 2.96875 15.7812 2.59375 15.4062C2.21875 15.0312 2.02083 14.5625 2 14V4H1.5C1.1875 3.97917 1.02083 3.8125 1 3.5V3C1.02083 2.6875 1.1875 2.52083 1.5 2.5H4.0625L5.125 0.71875C5.4375 0.260417 5.86458 0.0208333 6.40625 0H9.59375C10.1354 0.0208333 10.5625 0.260417 10.875 0.71875L11.9375 2.5H14.5ZM6.375 1.59375L5.8125 2.5H10.1875L9.625 1.59375C9.58333 1.53125 9.53125 1.5 9.46875 1.5H6.53125C6.46875 1.5 6.41667 1.53125 6.375 1.59375ZM12 14.5C12.3125 14.4792 12.4792 14.3125 12.5 14V4H3.5V14C3.52083 14.3125 3.6875 14.4792 4 14.5H12ZM8 13C7.6875 12.9792 7.52083 12.8125 7.5 12.5V6C7.52083 5.6875 7.6875 5.52083 8 5.5C8.3125 5.52083 8.47917 5.6875 8.5 6V12.5C8.47917 12.8125 8.3125 12.9792 8 13ZM5.5 13C5.1875 12.9792 5.02083 12.8125 5 12.5V6C5.02083 5.6875 5.1875 5.52083 5.5 5.5C5.8125 5.52083 5.97917 5.6875 6 6V12.5C5.97917 12.8125 5.8125 12.9792 5.5 13ZM10.5 13C10.1875 12.9792 10.0208 12.8125 10 12.5V6C10.0208 5.6875 10.1875 5.52083 10.5 5.5C10.8125 5.52083 10.9792 5.6875 11 6V12.5C10.9792 12.8125 10.8125 12.9792 10.5 13Z"
      />
    </symbol>`,
  "icon-crash": `<symbol id="icon-crash" viewBox="0 0 21 32">
      <path
        id="crash"
        d="M4.515,32h0L7.806,18H0L16.1,0,13.113,12H21ZM12.209,7.349,4.472,16H10.33L8.422,24.114,16.759,14h-6.2Z"
      />
    </symbol>`,
  "icon-crash-filled": `<symbol id="icon-crash-filled" viewBox="0 0 21 32">
      <path id="crash-filled" d="M16.1,0,13.113,12H21L4.513,32,7.805,18H0Z" />
    </symbol>`,
  "icon-info": `<symbol id="icon-info" viewBox="0 0 30 30">
      <g fill="none" fill-rule="evenodd">
        <path d="M0 0h32v32H0z" />
        <path
          
          fill-rule="nonzero"
          d="M15 28c7.18 0 13-5.82 13-13S22.18 2 15 2 2 7.82 2 15s5.82 13 13 13zm0 2C6.716 30 0 23.284 0 15 0 6.716 6.716 0 15 0c8.284 0 15 6.716 15 15 0 8.284-6.716 15-15 15zm-1-18h2v10h-2V12zm0-4h2v2h-2V8z"
        />
      </g>
    </symbol>`,
  "icon-more-vertical": `<symbol id="icon-more-vertical" viewBox="0 0 16 16">
      <path
        
        d="M8 3.5C7.58333 3.47917 7.22917 3.33333 6.9375 3.0625C6.66667 2.77083 6.52083 2.41667 6.5 2C6.52083 1.58333 6.66667 1.22917 6.9375 0.9375C7.22917 0.666667 7.58333 0.520833 8 0.5C8.41667 0.520833 8.77083 0.666667 9.0625 0.9375C9.33333 1.22917 9.47917 1.58333 9.5 2C9.47917 2.41667 9.33333 2.77083 9.0625 3.0625C8.77083 3.33333 8.41667 3.47917 8 3.5ZM8 12.5C8.41667 12.5208 8.77083 12.6667 9.0625 12.9375C9.33333 13.2292 9.47917 13.5833 9.5 14C9.47917 14.4167 9.33333 14.7708 9.0625 15.0625C8.77083 15.3333 8.41667 15.4792 8 15.5C7.58333 15.4792 7.22917 15.3333 6.9375 15.0625C6.66667 14.7708 6.52083 14.4167 6.5 14C6.52083 13.5833 6.66667 13.2292 6.9375 12.9375C7.22917 12.6667 7.58333 12.5208 8 12.5ZM8 6.5C8.41667 6.52083 8.77083 6.66667 9.0625 6.9375C9.33333 7.22917 9.47917 7.58333 9.5 8C9.47917 8.41667 9.33333 8.77083 9.0625 9.0625C8.77083 9.33333 8.41667 9.47917 8 9.5C7.58333 9.47917 7.22917 9.33333 6.9375 9.0625C6.66667 8.77083 6.52083 8.41667 6.5 8C6.52083 7.58333 6.66667 7.22917 6.9375 6.9375C7.22917 6.66667 7.58333 6.52083 8 6.5Z"
      />
    </symbol>`,
  "icon-more-horizontal": `<symbol id="icon-more-horizontal" viewBox="0 0 16 16">
      <path
        
        d="M12.5 8C12.5208 7.58333 12.6667 7.22917 12.9375 6.9375C13.2292 6.66667 13.5833 6.52083 14 6.5C14.4167 6.52083 14.7708 6.66667 15.0625 6.9375C15.3333 7.22917 15.4792 7.58333 15.5 8C15.4792 8.41667 15.3333 8.77083 15.0625 9.0625C14.7708 9.33333 14.4167 9.47917 14 9.5C13.5833 9.47917 13.2292 9.33333 12.9375 9.0625C12.6667 8.77083 12.5208 8.41667 12.5 8ZM3.5 8C3.47917 8.41667 3.33333 8.77083 3.0625 9.0625C2.77083 9.33333 2.41667 9.47917 2 9.5C1.58333 9.47917 1.22917 9.33333 0.9375 9.0625C0.666667 8.77083 0.520833 8.41667 0.5 8C0.520833 7.58333 0.666667 7.22917 0.9375 6.9375C1.22917 6.66667 1.58333 6.52083 2 6.5C2.41667 6.52083 2.77083 6.66667 3.0625 6.9375C3.33333 7.22917 3.47917 7.58333 3.5 8ZM9.5 8C9.47917 8.41667 9.33333 8.77083 9.0625 9.0625C8.77083 9.33333 8.41667 9.47917 8 9.5C7.58333 9.47917 7.22917 9.33333 6.9375 9.0625C6.66667 8.77083 6.52083 8.41667 6.5 8C6.52083 7.58333 6.66667 7.22917 6.9375 6.9375C7.22917 6.66667 7.58333 6.52083 8 6.5C8.41667 6.52083 8.77083 6.66667 9.0625 6.9375C9.33333 7.22917 9.47917 7.58333 9.5 8Z"
      />
    </symbol>`,
  "icon-settings": `<symbol id="icon-settings" viewBox="0 0 16 16">
      <path
        d="M15.75 9.84375C15.7292 10.1562 15.5729 10.6354 15.2812 11.2812C14.9896 11.9062 14.6458 12.4896 14.25 13.0312C13.8333 13.5729 13.4479 13.8542 13.0938 13.875C12.9479 13.875 12.8125 13.8438 12.6875 13.7812L11.6875 13.1875C11.3542 13.4167 11 13.625 10.625 13.8125V15C10.5833 15.375 10.3854 15.6146 10.0312 15.7188C9.36458 15.9062 8.67708 16 7.96875 16C7.30208 16 6.625 15.9062 5.9375 15.7188C5.58333 15.5938 5.39583 15.3438 5.375 14.9688V13.7812C5 13.6146 4.64583 13.4062 4.3125 13.1562L3.28125 13.75C3.15625 13.8125 3.02083 13.8438 2.875 13.8438C2.5 13.8229 2.11458 13.5312 1.71875 12.9688C1.30208 12.4062 0.958333 11.8125 0.6875 11.1875C0.395833 10.5625 0.25 10.1146 0.25 9.84375C0.25 9.57292 0.375 9.36458 0.625 9.21875L1.65625 8.625C1.63542 8.41667 1.625 8.20833 1.625 8C1.625 7.79167 1.63542 7.58333 1.65625 7.375L0.625 6.78125C0.375 6.63542 0.25 6.41667 0.25 6.125C0.270833 5.8125 0.427083 5.34375 0.71875 4.71875C1.01042 4.09375 1.35417 3.51042 1.75 2.96875C2.14583 2.42708 2.52083 2.14583 2.875 2.125C3.02083 2.125 3.15625 2.15625 3.28125 2.21875L4.3125 2.8125C4.64583 2.58333 5 2.375 5.375 2.1875V1C5.39583 0.625 5.58333 0.385417 5.9375 0.28125C6.625 0.09375 7.3125 0 8 0C8.70833 0 9.39583 0.09375 10.0625 0.28125C10.4167 0.385417 10.6042 0.625 10.625 1V2.1875C11 2.375 11.3542 2.58333 11.6875 2.8125L12.7188 2.21875C12.8438 2.15625 12.9792 2.125 13.125 2.125C13.5 2.16667 13.8854 2.45833 14.2812 3C14.6979 3.5625 15.0417 4.15625 15.3125 4.78125C15.6042 5.42708 15.75 5.875 15.75 6.125C15.75 6.41667 15.625 6.63542 15.375 6.78125L14.3438 7.375C14.3646 7.58333 14.375 7.79167 14.375 8C14.375 8.20833 14.3646 8.40625 14.3438 8.59375L15.375 9.1875C15.625 9.33333 15.75 9.55208 15.75 9.84375ZM12.9688 12.1562C13.4688 11.5938 13.8542 10.9479 14.125 10.2188L12.75 9.4375C12.7708 9.27083 12.7812 9.125 12.7812 9C12.8438 8.54167 12.875 8.20833 12.875 8C12.875 7.79167 12.8438 7.45833 12.7812 7C12.7812 6.875 12.7708 6.72917 12.75 6.5625L14.125 5.78125C13.8542 5.05208 13.4688 4.39583 12.9688 3.8125L11.625 4.59375C11.0833 4.19792 10.7083 3.9375 10.5 3.8125C10.3125 3.70833 9.98958 3.55208 9.53125 3.34375C9.40625 3.30208 9.27083 3.23958 9.125 3.15625V1.59375C8.85417 1.53125 8.47917 1.5 8 1.5C7.66667 1.5 7.29167 1.53125 6.875 1.59375V3.15625C6.25 3.42708 5.84375 3.61458 5.65625 3.71875C5.44792 3.84375 5.13542 4.05208 4.71875 4.34375C4.63542 4.42708 4.52083 4.51042 4.375 4.59375L3.03125 3.8125C2.53125 4.39583 2.14583 5.05208 1.875 5.78125L3.25 6.5625C3.22917 6.72917 3.21875 6.875 3.21875 7C3.15625 7.45833 3.125 7.79167 3.125 8C3.125 8.16667 3.13542 8.39583 3.15625 8.6875C3.17708 8.875 3.19792 9.125 3.21875 9.4375L1.875 10.1875C2.14583 10.9167 2.53125 11.5729 3.03125 12.1562L4.375 11.375C4.91667 11.7708 5.29167 12.0312 5.5 12.1562C5.6875 12.2604 6.01042 12.4167 6.46875 12.625C6.59375 12.6875 6.72917 12.75 6.875 12.8125V14.375C7.125 14.4375 7.5 14.4688 8 14.4688C8.33333 14.4688 8.70833 14.4375 9.125 14.375V12.8125C9.75 12.5417 10.1562 12.3542 10.3438 12.25C10.5521 12.1458 10.8646 11.9375 11.2812 11.625C11.3646 11.5417 11.4792 11.4583 11.625 11.375L12.9688 12.1562ZM8 4.96875C8.85417 4.98958 9.5625 5.28125 10.125 5.84375C10.6875 6.40625 10.9792 7.11458 11 7.96875C10.9792 8.82292 10.6875 9.53125 10.125 10.0938C9.5625 10.6562 8.85417 10.9479 8 10.9688C7.14583 10.9479 6.4375 10.6562 5.875 10.0938C5.3125 9.53125 5.02083 8.82292 5 7.96875C5.02083 7.11458 5.3125 6.40625 5.875 5.84375C6.4375 5.28125 7.14583 4.98958 8 4.96875ZM8 9.5C8.41667 9.47917 8.77083 9.33333 9.0625 9.0625C9.33333 8.77083 9.47917 8.41667 9.5 8C9.47917 7.58333 9.33333 7.22917 9.0625 6.9375C8.77083 6.66667 8.41667 6.52083 8 6.5C7.58333 6.52083 7.22917 6.66667 6.9375 6.9375C6.66667 7.22917 6.52083 7.58333 6.5 8C6.52083 8.41667 6.66667 8.77083 6.9375 9.0625C7.22917 9.33333 7.58333 9.47917 8 9.5Z"
      />
    </symbol>`,
  "icon-remove": `<symbol id="icon-remove" viewBox="0 0 16 16">
      <path
        
        d="M16 8C15.9583 8.45833 15.7083 8.70833 15.25 8.75H0.75C0.291667 8.70833 0.0416667 8.45833 0 8C0.0416667 7.54167 0.291667 7.29167 0.75 7.25H15.25C15.7083 7.29167 15.9583 7.54167 16 8Z"
      />
    </symbol>`,
  "icon-share": `<symbol id="icon-share"
      id="icon-share"
     viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      stroke-width="2"
      stroke-linecap="round"
      stroke-linejoin="round"
    >
      <path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8"></path>
      <polyline points="16 6 12 2 8 6"></polyline>
      <line x1="12" y1="2" x2="12" y2="15"></line>
    </symbol>`,
  "icon-email": `<symbol id="icon-email" viewBox="0 0 16 16">
      <path
        
        d="M14 2C14.5625 2.02083 15.0312 2.21875 15.4062 2.59375C15.7812 2.96875 15.9792 3.4375 16 4V12C15.9792 12.5625 15.7812 13.0312 15.4062 13.4062C15.0312 13.7812 14.5625 13.9792 14 14H2C1.4375 13.9792 0.96875 13.7812 0.59375 13.4062C0.21875 13.0312 0.0208333 12.5625 0 12V4C0.0208333 3.4375 0.21875 2.96875 0.59375 2.59375C0.96875 2.21875 1.4375 2.02083 2 2H14ZM2 3.5C1.6875 3.52083 1.52083 3.6875 1.5 4V4.6875L6.71875 9C7.09375 9.3125 7.52083 9.46875 8 9.46875C8.47917 9.46875 8.90625 9.3125 9.28125 9L14.5 4.6875V4C14.4792 3.6875 14.3125 3.52083 14 3.5H2ZM14 12.5C14.3125 12.4792 14.4792 12.3125 14.5 12V6.65625L10.25 10.1875C9.58333 10.7292 8.83333 11 8 11C7.16667 11 6.41667 10.7292 5.75 10.1875L1.5 6.65625V12C1.52083 12.3125 1.6875 12.4792 2 12.5H14Z"
      />
    </symbol>`,
  "icon-edit": `<symbol id="icon-edit" viewBox="0 0 16 16">
      <path
        
        d="M15.408 1.75C15.8038 2.16667 16.0017 2.63542 16.0017 3.15625C16.0017 3.69792 15.8038 4.17708 15.408 4.59375L4.97049 15.0312C4.90799 15.0938 4.82465 15.1354 4.72049 15.1562L0.595486 16C0.574653 16 0.543403 16 0.501736 16C0.147569 15.9583 -0.0190972 15.75 0.00173611 15.375L0.845486 11.25C0.866319 11.1667 0.907986 11.0833 0.970486 11L11.408 0.59375C11.8247 0.197917 12.3038 0 12.8455 0C13.3663 0 13.8351 0.197917 14.2517 0.59375L15.408 1.75ZM4.12674 13.75L4.87674 13H3.00174V11.125L2.25174 11.875L1.78299 14.2188L4.12674 13.75ZM4.50174 11.5H6.37674L11.908 6L10.033 4.125L4.50174 9.625V11.5Z"
      />
    </symbol>`,
  "icon-share-nodes": `<symbol id="icon-share-nodes" viewBox="0 0 16 16">
      <path
        
        d="M12 9C12.8542 9.02083 13.5625 9.3125 14.125 9.875C14.6875 10.4375 14.9792 11.1458 15 12C14.9792 12.8542 14.6875 13.5625 14.125 14.125C13.5625 14.6875 12.8542 14.9792 12 15C11.1458 14.9792 10.4375 14.6875 9.875 14.125C9.3125 13.5625 9.02083 12.8542 9 12C9 11.7917 9.02083 11.5833 9.0625 11.375L6.25 9.96875C5.66667 10.6354 4.91667 10.9792 4 11C3.14583 10.9792 2.4375 10.6875 1.875 10.125C1.3125 9.5625 1.02083 8.85417 1 8C1.02083 7.14583 1.3125 6.4375 1.875 5.875C2.4375 5.3125 3.14583 5.02083 4 5C4.91667 5.02083 5.66667 5.36458 6.25 6.03125L9.0625 4.625C9.02083 4.41667 9 4.20833 9 4C9.02083 3.14583 9.3125 2.4375 9.875 1.875C10.4375 1.3125 11.1458 1.02083 12 1C12.8542 1.02083 13.5625 1.3125 14.125 1.875C14.6875 2.4375 14.9792 3.14583 15 4C14.9792 4.85417 14.6875 5.5625 14.125 6.125C13.5625 6.6875 12.8542 6.97917 12 7C11.0833 6.97917 10.3333 6.63542 9.75 5.96875L6.9375 7.375C6.97917 7.58333 7 7.79167 7 8C7 8.20833 6.97917 8.41667 6.9375 8.625L9.75 10.0312C10.3333 9.36458 11.0833 9.02083 12 9ZM12 2.5C11.5833 2.52083 11.2292 2.66667 10.9375 2.9375C10.6667 3.22917 10.5208 3.58333 10.5 4C10.5208 4.41667 10.6667 4.77083 10.9375 5.0625C11.2292 5.33333 11.5833 5.47917 12 5.5C12.4167 5.47917 12.7708 5.33333 13.0625 5.0625C13.3333 4.77083 13.4792 4.41667 13.5 4C13.4792 3.58333 13.3333 3.22917 13.0625 2.9375C12.7708 2.66667 12.4167 2.52083 12 2.5ZM4 9.5C4.41667 9.47917 4.77083 9.33333 5.0625 9.0625C5.33333 8.77083 5.47917 8.41667 5.5 8C5.47917 7.58333 5.33333 7.22917 5.0625 6.9375C4.77083 6.66667 4.41667 6.52083 4 6.5C3.58333 6.52083 3.22917 6.66667 2.9375 6.9375C2.66667 7.22917 2.52083 7.58333 2.5 8C2.52083 8.41667 2.66667 8.77083 2.9375 9.0625C3.22917 9.33333 3.58333 9.47917 4 9.5ZM12 13.5C12.4167 13.4792 12.7708 13.3333 13.0625 13.0625C13.3333 12.7708 13.4792 12.4167 13.5 12C13.4792 11.5833 13.3333 11.2292 13.0625 10.9375C12.7708 10.6667 12.4167 10.5208 12 10.5C11.5833 10.5208 11.2292 10.6667 10.9375 10.9375C10.6667 11.2292 10.5208 11.5833 10.5 12C10.5208 12.4167 10.6667 12.7708 10.9375 13.0625C11.2292 13.3333 11.5833 13.4792 12 13.5Z"
      />
    </symbol>`,
  "icon-menu": `<symbol id="icon-menu" viewBox="0 0 16 16">
      <path
        
        d="M14.25 12.25C14.7083 12.2917 14.9583 12.5521 15 13.0312C14.9583 13.4688 14.7083 13.7083 14.25 13.75H1.71875C1.28125 13.7083 1.04167 13.4479 1 12.9688C1 12.7812 1.07292 12.6146 1.21875 12.4688C1.36458 12.3229 1.53125 12.25 1.71875 12.25H14.25ZM14.25 2.25C14.4583 2.25 14.6354 2.33333 14.7812 2.5C14.9271 2.64583 15 2.82292 15 3.03125C14.9583 3.46875 14.7083 3.70833 14.25 3.75H1.71875C1.53125 3.75 1.36458 3.66667 1.21875 3.5C1.07292 3.35417 1 3.17708 1 2.96875C1 2.78125 1.07292 2.61458 1.21875 2.46875C1.36458 2.32292 1.53125 2.25 1.71875 2.25H14.25ZM14.25 7.25C14.7083 7.29167 14.9583 7.54167 15 8C14.9583 8.45833 14.7083 8.70833 14.25 8.75H1.71875C1.28125 8.70833 1.04167 8.45833 1 8C1.04167 7.54167 1.28125 7.29167 1.71875 7.25H14.25Z"
      />
    </symbol>`,
  "icon-open-new": `<symbol id="icon-open-new" viewBox="0 0 16 16">
      <path
        
        d="M12.25 10C12.7083 10.0417 12.9583 10.2917 13 10.75V14.25C12.9792 14.75 12.8125 15.1667 12.5 15.5C12.1667 15.8125 11.75 15.9792 11.25 16H1.75C1.25 15.9792 0.833333 15.8125 0.5 15.5C0.1875 15.1667 0.0208333 14.75 0 14.25V4.75C0.0208333 4.25 0.1875 3.83333 0.5 3.5C0.833333 3.1875 1.25 3.02083 1.75 3H5.25C5.70833 3.04167 5.95833 3.29167 6 3.75C5.95833 4.20833 5.70833 4.45833 5.25 4.5H1.75C1.60417 4.52083 1.52083 4.60417 1.5 4.75V14.25C1.52083 14.3958 1.60417 14.4792 1.75 14.5H11.25C11.3958 14.4792 11.4792 14.3958 11.5 14.25V10.75C11.5417 10.2917 11.7917 10.0417 12.25 10ZM15.25 0C15.7083 0.0416667 15.9583 0.291667 16 0.75V6C15.9583 6.45833 15.7083 6.70833 15.25 6.75C14.7917 6.70833 14.5417 6.45833 14.5 6V2.5625L6.78125 10.2812C6.63542 10.4271 6.45833 10.5 6.25 10.5C6.04167 10.5 5.86458 10.4271 5.71875 10.2812C5.42708 9.92708 5.42708 9.57292 5.71875 9.21875L13.4375 1.5H10C9.54167 1.45833 9.29167 1.20833 9.25 0.75C9.29167 0.291667 9.54167 0.0416667 10 0H15.25Z"
      />
    </symbol>`,
  "icon-copy": `<symbol id="icon-copy" viewBox="0 0 16 16">
      <path
        
        d="M15.7188 2.21875C15.9062 2.40625 16 2.63542 16 2.90625V10C15.9792 10.5625 15.7812 11.0312 15.4062 11.4062C15.0312 11.7812 14.5625 11.9792 14 12H8C7.4375 11.9792 6.96875 11.7812 6.59375 11.4062C6.19792 11.0312 5.98958 10.5625 5.96875 10V2C5.98958 1.4375 6.1875 0.96875 6.5625 0.59375C6.9375 0.21875 7.40625 0.0208333 7.96875 0H13.0938C13.3646 0 13.5938 0.09375 13.7812 0.28125L15.7188 2.21875ZM14.5 10H14.4688V4H13C12.7083 4 12.4688 3.90625 12.2812 3.71875C12.0938 3.53125 12 3.29167 12 3L11.9688 1.5H7.96875C7.65625 1.54167 7.48958 1.70833 7.46875 2V10C7.48958 10.3125 7.65625 10.4792 7.96875 10.5H14C14.3125 10.4792 14.4792 10.3125 14.5 10ZM8.5 14L8.53125 13H10V14C9.97917 14.5625 9.78125 15.0312 9.40625 15.4062C9.03125 15.7812 8.5625 15.9792 8 16H2C1.4375 15.9792 0.96875 15.7812 0.59375 15.4062C0.21875 15.0312 0.0208333 14.5625 0 14V6C0.0208333 5.4375 0.21875 4.96875 0.59375 4.59375C0.96875 4.21875 1.4375 4.02083 2 4H5V5.5H2C1.6875 5.52083 1.52083 5.6875 1.5 6L1.46875 14C1.48958 14.3125 1.65625 14.4792 1.96875 14.5H8C8.3125 14.4792 8.47917 14.3125 8.5 14Z"
      />
    </symbol>`,
  "icon-paste": `<symbol id="icon-paste" viewBox="0 0 16 16">
      <path
        
        d="M15.7188 6.21875C15.9062 6.40625 16 6.63542 16 6.90625V14C15.9792 14.5625 15.7812 15.0312 15.4062 15.4062C15.0312 15.7812 14.5625 15.9792 14 16H8C7.4375 15.9792 6.96875 15.7812 6.59375 15.4062C6.21875 15.0312 6.02083 14.5521 6 13.9688V6C6 5.4375 6.1875 4.96875 6.5625 4.59375C6.95833 4.21875 7.4375 4.02083 8 4H13.0938C13.3646 4 13.5938 4.09375 13.7812 4.28125L15.7188 6.21875ZM14.5 14V8H13C12.7083 8 12.4688 7.90625 12.2812 7.71875C12.0938 7.53125 12 7.29167 12 7V5.5H8C7.6875 5.52083 7.52083 5.6875 7.5 6V14C7.52083 14.3125 7.6875 14.4792 8 14.5H14C14.3125 14.4792 14.4792 14.3125 14.5 14ZM9.9375 3H8C7.4375 3 6.9375 3.13542 6.5 3.40625C6.04167 3.67708 5.67708 4.04167 5.40625 4.5H3.5C3.20833 4.5 2.96875 4.40625 2.78125 4.21875C2.59375 4.03125 2.5 3.79167 2.5 3.5V3H2C1.6875 3.02083 1.52083 3.1875 1.5 3.5V12C1.52083 12.3125 1.6875 12.4792 2 12.5H5V14H2C1.4375 13.9792 0.96875 13.7812 0.59375 13.4062C0.21875 13.0312 0.0208333 12.5625 0 12V3.5C0.0208333 2.9375 0.21875 2.46875 0.59375 2.09375C0.96875 1.71875 1.4375 1.52083 2 1.5H3.28125C3.34375 1.0625 3.53125 0.708333 3.84375 0.4375C4.15625 0.145833 4.54167 0 5 0C5.45833 0 5.84375 0.145833 6.15625 0.4375C6.46875 0.708333 6.65625 1.0625 6.71875 1.5H8C8.47917 1.5 8.88542 1.64583 9.21875 1.9375C9.57292 2.20833 9.8125 2.5625 9.9375 3ZM5 2.25C5.3125 2.22917 5.47917 2.0625 5.5 1.75C5.47917 1.4375 5.3125 1.27083 5 1.25C4.6875 1.27083 4.52083 1.4375 4.5 1.75C4.52083 2.0625 4.6875 2.22917 5 2.25Z"
      />
    </symbol>`,
  "icon-add": `<symbol id="icon-add" viewBox="0 0 16 16">
      <path
        
        d="M14.5 8C14.4583 8.45833 14.2083 8.70833 13.75 8.75H8.75V13.75C8.70833 14.2083 8.45833 14.4583 8 14.5C7.54167 14.4583 7.29167 14.2083 7.25 13.75V8.75H2.25C1.79167 8.70833 1.54167 8.45833 1.5 8C1.54167 7.54167 1.79167 7.29167 2.25 7.25H7.25V2.25C7.29167 1.79167 7.54167 1.54167 8 1.5C8.45833 1.54167 8.70833 1.79167 8.75 2.25V7.25H13.75C14.2083 7.29167 14.4583 7.54167 14.5 8Z"
      />
    </symbol>`,
  "icon-minus": `<symbol id="icon-minus"
    viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      stroke-width="2"
      stroke-linecap="round"
      stroke-linejoin="round"
    >
      <line x1="5" y1="12" x2="19" y2="12"></line>
    </symbol>`,
  "icon-check": `<symbol id="icon-check" viewBox="0 0 16 16">
      <path
        
        d="M15.25 4.25L6.75 12.75C6.625 12.9167 6.45833 13 6.25 13C6.04167 13 5.86458 12.9271 5.71875 12.7812L1.21875 8.28125C0.927083 7.92708 0.927083 7.57292 1.21875 7.21875C1.57292 6.92708 1.92708 6.92708 2.28125 7.21875L6.25 11.1875L14.2188 3.21875C14.5729 2.92708 14.9271 2.92708 15.2812 3.21875C15.5729 3.57292 15.5625 3.91667 15.25 4.25Z"
      />
    </symbol>`,
  "icon-circle-xmark": `<symbol id="icon-circle-xmark" viewBox="0 0 16 16">
      <path
        
        d="M10.5 5.46875C10.8125 5.82292 10.8229 6.17708 10.5312 6.53125L9.0625 8L10.5312 9.46875C10.8229 9.82292 10.8229 10.1771 10.5312 10.5312C10.1771 10.8229 9.82292 10.8229 9.46875 10.5312L8 9.0625L6.53125 10.5312C6.17708 10.8229 5.82292 10.8229 5.46875 10.5312C5.17708 10.1771 5.17708 9.82292 5.46875 9.46875L6.90625 8L5.4375 6.53125C5.14583 6.17708 5.14583 5.82292 5.4375 5.46875C5.79167 5.17708 6.14583 5.17708 6.5 5.46875L8 6.9375L9.4375 5.46875C9.79167 5.17708 10.1458 5.17708 10.5 5.46875ZM8 0C9.5 0.0208333 10.8438 0.385417 12.0312 1.09375C13.2396 1.80208 14.1979 2.76042 14.9062 3.96875C15.6146 5.15625 15.9792 6.5 16 8C15.9792 9.5 15.6146 10.8438 14.9062 12.0312C14.1979 13.2396 13.2396 14.1979 12.0312 14.9062C10.8438 15.6146 9.5 15.9792 8 16C6.5 15.9792 5.15625 15.6146 3.96875 14.9062C2.76042 14.1979 1.80208 13.2396 1.09375 12.0312C0.385417 10.8438 0.0208333 9.5 0 8C0.0208333 6.5 0.385417 5.15625 1.09375 3.96875C1.80208 2.76042 2.76042 1.80208 3.96875 1.09375C5.15625 0.385417 6.5 0.0208333 8 0ZM8 14.5C9.83333 14.4583 11.3646 13.8229 12.5938 12.5938C13.8229 11.3646 14.4583 9.83333 14.5 8C14.4583 6.16667 13.8229 4.63542 12.5938 3.40625C11.3646 2.17708 9.83333 1.54167 8 1.5C6.16667 1.54167 4.63542 2.17708 3.40625 3.40625C2.17708 4.63542 1.54167 6.16667 1.5 8C1.54167 9.83333 2.17708 11.3646 3.40625 12.5938C4.63542 13.8229 6.16667 14.4583 8 14.5Z"
      />
    </symbol>`,
  "icon-cart": `<symbol id="icon-cart" viewBox="0 0 24 22">
      <path
        d="M10,20.5 C10,21.329 9.328,22 8.5,22 C7.672,22 7,21.329 7,20.5 C7,19.672 7.672,19 8.5,19 C9.328,19 10,19.672 10,20.5 Z M13.5,19 C12.672,19 12,19.671 12,20.5 C12,21.329 12.672,22 13.5,22 C14.328,22 15,21.329 15,20.5 C15,19.672 14.328,19 13.5,19 Z M19.805,4 L16.373,16 L5.945,16 L2.168,7 L0,7 L4.615,18 L17.854,18 L21.328,6 L23.257,6 L24,4 L19.805,4 Z M6,0 C12.712,1.617 13,9 13,9 L15,9 L11,13 L7,9 L9,9 C9,9 9.94,2.58 6,0 Z"
      />
    </symbol>`,
  "icon-picture": `<symbol id="icon-picture" viewBox="0 0 75 56.25">
      <rect style="fill: transparent" width="75" height="56.25" />
      <path
        d="M28.125,31.125a3.125,3.125,0,1,1,3.128,3.125A3.127,3.127,0,0,1,28.125,31.125Zm19.375,0L42.187,39.25l-4.062-5-10,12.5h31.25ZM65.625,9.25V3H0V49.875H6.25V9.25ZM75,15.5V59.25H12.5V15.5Zm-6.25,6.25h-50V53h50Z"
      />
    </symbol>`,
  "icon-file": `<symbol id="icon-file" viewBox="0 0 16 16">
      <path
        
        d="M13.4062 2.90625C13.8021 3.30208 14 3.78125 14 4.34375V14C13.9792 14.5625 13.7812 15.0312 13.4062 15.4062C13.0312 15.7812 12.5625 15.9792 12 16H4C3.4375 15.9792 2.96875 15.7812 2.59375 15.4062C2.21875 15.0312 2.02083 14.5625 2 14V2C2.02083 1.4375 2.21875 0.96875 2.59375 0.59375C2.96875 0.21875 3.4375 0.0208333 4 0H9.65625C10.2188 0 10.6979 0.197917 11.0938 0.59375L13.4062 2.90625ZM12 14.5C12.3125 14.4792 12.4688 14.3125 12.4688 14V5H10C9.70833 5 9.46875 4.90625 9.28125 4.71875C9.09375 4.53125 9 4.29167 9 4V1.5H4C3.6875 1.54167 3.52083 1.70833 3.5 2V14.0312C3.54167 14.3021 3.70833 14.4583 4 14.5H12Z"
      />
    </symbol>`,
  "icon-network-tree": `<symbol id="icon-network-tree" viewBox="0 0 20 16">
      <path
        
        d="M11.5 10C11.9167 10.0208 12.2708 10.1667 12.5625 10.4375C12.8333 10.7292 12.9792 11.0833 13 11.5V14.5C12.9792 14.9167 12.8333 15.2708 12.5625 15.5625C12.2708 15.8333 11.9167 15.9792 11.5 16H8.5C8.08333 15.9792 7.72917 15.8333 7.4375 15.5625C7.16667 15.2708 7.02083 14.9167 7 14.5V11.5C7.02083 11.0833 7.16667 10.7292 7.4375 10.4375C7.72917 10.1667 8.08333 10.0208 8.5 10H11.5ZM11.5 14.5V11.5H8.5V14.5H11.5ZM18.4688 0C18.9062 0.0208333 19.2604 0.166667 19.5312 0.4375C19.8229 0.729167 19.9688 1.08333 19.9688 1.5V4.5C19.9688 4.91667 19.8229 5.27083 19.5312 5.5625C19.2396 5.83333 18.8854 5.97917 18.4688 6H15.4688C15.0521 5.97917 14.6979 5.83333 14.4062 5.5625C14.1354 5.27083 13.9896 4.91667 13.9688 4.5V1.5C13.9896 1.08333 14.1354 0.729167 14.4062 0.4375C14.6979 0.166667 15.0521 0.0208333 15.4688 0H18.4688ZM18.5 4.5V1.5H15.5V4.5H18.5ZM12.25 2.25C12.7083 2.29167 12.9583 2.54167 13 3C12.9583 3.45833 12.7083 3.70833 12.25 3.75H6V4.5C6 4.83333 5.89583 5.13542 5.6875 5.40625L7.40625 8.375C7.59375 8.79167 7.5 9.13542 7.125 9.40625C7 9.46875 6.875 9.5 6.75 9.5C6.47917 9.5 6.26042 9.375 6.09375 9.125L4.3125 6H1.5C1.08333 5.97917 0.729167 5.83333 0.4375 5.5625C0.166667 5.27083 0.0208333 4.91667 0 4.5V1.5C0.0208333 1.08333 0.166667 0.729167 0.4375 0.4375C0.729167 0.166667 1.08333 0.0208333 1.5 0H4.5C4.91667 0.0208333 5.27083 0.166667 5.5625 0.4375C5.83333 0.729167 5.97917 1.08333 6 1.5V2.25H12.25ZM4.5 4.5V1.5H1.5V4.5H4.5Z"
      />
    </symbol>`,
  "icon-alert-circle": `<symbol id="icon-alert-circle" viewBox="0 0 16 16">
      <path
        
        d="M8 0C9.5 0.0208333 10.8438 0.385417 12.0312 1.09375C13.2396 1.80208 14.1979 2.76042 14.9062 3.96875C15.6146 5.15625 15.9792 6.5 16 8C15.9792 9.5 15.6146 10.8438 14.9062 12.0312C14.1979 13.2396 13.2396 14.1979 12.0312 14.9062C10.8438 15.6146 9.5 15.9792 8 16C6.5 15.9792 5.15625 15.6146 3.96875 14.9062C2.76042 14.1979 1.80208 13.2396 1.09375 12.0312C0.385417 10.8438 0.0208333 9.5 0 8C0.0208333 6.5 0.385417 5.15625 1.09375 3.96875C1.80208 2.76042 2.76042 1.80208 3.96875 1.09375C5.15625 0.385417 6.5 0.0208333 8 0ZM8 14.5C9.83333 14.4583 11.3646 13.8229 12.5938 12.5938C13.8229 11.3646 14.4583 9.83333 14.5 8C14.4583 6.16667 13.8229 4.63542 12.5938 3.40625C11.3646 2.17708 9.83333 1.54167 8 1.5C6.16667 1.54167 4.63542 2.17708 3.40625 3.40625C2.17708 4.63542 1.54167 6.16667 1.5 8C1.54167 9.83333 2.17708 11.3646 3.40625 12.5938C4.63542 13.8229 6.16667 14.4583 8 14.5ZM8 9.5C7.54167 9.45833 7.29167 9.20833 7.25 8.75V4.75C7.29167 4.29167 7.54167 4.04167 8 4C8.45833 4.04167 8.70833 4.29167 8.75 4.75V8.75C8.70833 9.20833 8.45833 9.45833 8 9.5ZM8 10.5312C8.27083 10.5312 8.5 10.625 8.6875 10.8125C8.875 11 8.96875 11.2396 8.96875 11.5312C8.96875 11.8021 8.875 12.0312 8.6875 12.2188C8.5 12.4062 8.27083 12.5 8 12.5C7.72917 12.5 7.5 12.4062 7.3125 12.2188C7.125 12.0312 7.03125 11.8021 7.03125 11.5312C7.03125 11.2396 7.125 11 7.3125 10.8125C7.5 10.625 7.72917 10.5312 8 10.5312Z"
      />
    </symbol>`,
  "icon-arrow-up": `<symbol id="icon-arrow-up" viewBox="0 0 16 16">
      <path
        
        d="M2.21875 6.75L7.46875 1.25C7.61458 1.08333 7.79167 1 8 1C8.20833 1 8.38542 1.07292 8.53125 1.21875L13.7812 6.71875C14.0729 7.09375 14.0729 7.44792 13.7812 7.78125C13.4062 8.07292 13.0521 8.07292 12.7188 7.78125L8.75 3.625V14.25C8.70833 14.6875 8.46875 14.9271 8.03125 14.9688C7.82292 14.9688 7.64583 14.9062 7.5 14.7812C7.33333 14.6354 7.25 14.4583 7.25 14.25V3.625L3.28125 7.78125C2.94792 8.07292 2.59375 8.07292 2.21875 7.78125C1.92708 7.44792 1.92708 7.10417 2.21875 6.75Z"
      />
    </symbol>`,
  "icon-arrow-left": `<symbol id="icon-arrow-left" viewBox="0 0 16 16">
      <path
        
        d="M14.9688 8C14.9271 8.45833 14.6771 8.70833 14.2188 8.75H3.625L7.78125 12.7188C8.07292 13.0521 8.07292 13.4062 7.78125 13.7812C7.44792 14.0729 7.09375 14.0729 6.71875 13.7812L1.21875 8.53125C1.07292 8.38542 1 8.20833 1 8C1 7.79167 1.07292 7.61458 1.21875 7.46875L6.71875 2.21875C7.09375 1.92708 7.44792 1.92708 7.78125 2.21875C8.07292 2.59375 8.07292 2.94792 7.78125 3.28125L3.625 7.25H14.25C14.6875 7.29167 14.9271 7.54167 14.9688 8Z"
      />
    </symbol>`,
  "icon-arrow-down": `<symbol id="icon-arrow-down" viewBox="0 0 16 16">
      <path
        
        d="M13.7812 9.28125L8.53125 14.7812C8.38542 14.9271 8.20833 15 8 15C7.79167 15 7.61458 14.9271 7.46875 14.7812L2.21875 9.28125C1.92708 8.90625 1.92708 8.55208 2.21875 8.21875C2.59375 7.92708 2.94792 7.92708 3.28125 8.21875L7.25 12.375V1.75C7.29167 1.29167 7.53125 1.04167 7.96875 1C8.17708 1 8.35417 1.07292 8.5 1.21875C8.66667 1.36458 8.75 1.54167 8.75 1.75V12.375L12.7188 8.21875C13.0521 7.92708 13.4062 7.92708 13.7812 8.21875C14.0729 8.55208 14.0729 8.90625 13.7812 9.28125Z"
      />
    </symbol>`,
  "icon-do-not-enter": `<symbol id="icon-do-not-enter" viewBox="0 0 16 16">
      <path
        
        d="M11.75 6.5C12.2083 6.54167 12.4583 6.79167 12.5 7.25V8.75C12.4583 9.20833 12.2083 9.45833 11.75 9.5H4.25C3.79167 9.45833 3.54167 9.20833 3.5 8.75V7.25C3.54167 6.79167 3.79167 6.54167 4.25 6.5H11.75ZM8 0C9.5 0.0208333 10.8438 0.385417 12.0312 1.09375C13.2396 1.80208 14.1979 2.76042 14.9062 3.96875C15.6146 5.15625 15.9792 6.5 16 8C15.9792 9.5 15.6146 10.8438 14.9062 12.0312C14.1979 13.2396 13.2396 14.1979 12.0312 14.9062C10.8438 15.6146 9.5 15.9792 8 16C6.5 15.9792 5.15625 15.6146 3.96875 14.9062C2.76042 14.1979 1.80208 13.2396 1.09375 12.0312C0.385417 10.8438 0.0208333 9.5 0 8C0.0208333 6.5 0.385417 5.15625 1.09375 3.96875C1.80208 2.76042 2.76042 1.80208 3.96875 1.09375C5.15625 0.385417 6.5 0.0208333 8 0ZM8 14.5C9.83333 14.4583 11.3646 13.8229 12.5938 12.5938C13.8229 11.3646 14.4583 9.83333 14.5 8C14.4583 6.16667 13.8229 4.63542 12.5938 3.40625C11.3646 2.17708 9.83333 1.54167 8 1.5C6.16667 1.54167 4.63542 2.17708 3.40625 3.40625C2.17708 4.63542 1.54167 6.16667 1.5 8C1.54167 9.83333 2.17708 11.3646 3.40625 12.5938C4.63542 13.8229 6.16667 14.4583 8 14.5Z"
      />
    </symbol>`,
  "icon-arrow-right": `<symbol id="icon-arrow-right" viewBox="0 0 16 16">
      <path
        
        d="M9.28125 2.21875L14.7812 7.46875C14.9271 7.61458 15 7.79167 15 8C15 8.20833 14.9271 8.38542 14.7812 8.53125L9.28125 13.7812C8.90625 14.0729 8.55208 14.0729 8.21875 13.7812C7.92708 13.4062 7.92708 13.0521 8.21875 12.7188L12.375 8.75H1.75C1.29167 8.70833 1.04167 8.45833 1 8C1.04167 7.54167 1.29167 7.29167 1.75 7.25H12.375L8.21875 3.28125C7.92708 2.94792 7.92708 2.59375 8.21875 2.21875C8.55208 1.92708 8.90625 1.92708 9.28125 2.21875Z"
      />
    </symbol>`,
  "icon-arrow-rotate-left": `<symbol id="icon-arrow-rotate-left" viewBox="0 0 16 16">
      <path
        
        d="M1.75 1C2.20833 1.04167 2.45833 1.29167 2.5 1.75V4.9375C3.14583 3.89583 3.98958 3.0625 5.03125 2.4375C6.07292 1.83333 7.22917 1.52083 8.5 1.5C9.8125 1.52083 10.9896 1.84375 12.0312 2.46875C13.0938 3.09375 13.9271 3.92708 14.5312 4.96875C15.1562 6.03125 15.4792 7.20833 15.5 8.5C15.4792 9.79167 15.1562 10.9688 14.5312 12.0312C13.9271 13.0729 13.0938 13.9062 12.0312 14.5312C10.9896 15.1562 9.8125 15.4792 8.5 15.5C6.8125 15.4792 5.32292 14.9375 4.03125 13.875C3.69792 13.5417 3.66667 13.1875 3.9375 12.8125C4.25 12.5 4.59375 12.4688 4.96875 12.7188C6.01042 13.5521 7.1875 13.9792 8.5 14C10.0625 13.9583 11.3542 13.4167 12.375 12.375C13.4167 11.3542 13.9583 10.0625 14 8.5C13.9583 6.9375 13.4167 5.64583 12.375 4.625C11.3542 3.58333 10.0625 3.04167 8.5 3C7.4375 3.02083 6.47917 3.29167 5.625 3.8125C4.77083 4.35417 4.10417 5.08333 3.625 6H6.75C7.20833 6.04167 7.45833 6.29167 7.5 6.75C7.45833 7.20833 7.20833 7.45833 6.75 7.5H1.75C1.29167 7.45833 1.04167 7.20833 1 6.75V1.75C1.04167 1.29167 1.29167 1.04167 1.75 1Z"
      />
    </symbol>`,
  "icon-minus-circle": `<symbol id="icon-minus-circle" viewBox="0 0 16 16">
      <path
        
        d="M11 7.25C11.4583 7.29167 11.7083 7.54167 11.75 8C11.7083 8.45833 11.4583 8.70833 11 8.75H5C4.54167 8.70833 4.29167 8.45833 4.25 8C4.29167 7.54167 4.54167 7.29167 5 7.25H11ZM8 0C9.5 0.0208333 10.8438 0.385417 12.0312 1.09375C13.2396 1.80208 14.1979 2.76042 14.9062 3.96875C15.6146 5.15625 15.9792 6.5 16 8C15.9792 9.5 15.6146 10.8438 14.9062 12.0312C14.1979 13.2396 13.2396 14.1979 12.0312 14.9062C10.8438 15.6146 9.5 15.9792 8 16C6.5 15.9792 5.15625 15.6146 3.96875 14.9062C2.76042 14.1979 1.80208 13.2396 1.09375 12.0312C0.385417 10.8438 0.0208333 9.5 0 8C0.0208333 6.5 0.385417 5.15625 1.09375 3.96875C1.80208 2.76042 2.76042 1.80208 3.96875 1.09375C5.15625 0.385417 6.5 0.0208333 8 0ZM8 14.5C9.83333 14.4583 11.3646 13.8229 12.5938 12.5938C13.8229 11.3646 14.4583 9.83333 14.5 8C14.4583 6.16667 13.8229 4.63542 12.5938 3.40625C11.3646 2.17708 9.83333 1.54167 8 1.5C6.16667 1.54167 4.63542 2.17708 3.40625 3.40625C2.17708 4.63542 1.54167 6.16667 1.5 8C1.54167 9.83333 2.17708 11.3646 3.40625 12.5938C4.63542 13.8229 6.16667 14.4583 8 14.5Z"
      />
    </symbol>`,
  "icon-plus-circle": `<symbol id="icon-plus-circle" viewBox="0 0 16 16">
      <path
        
        d="M11 7.25C11.4583 7.29167 11.7083 7.54167 11.75 8C11.7083 8.45833 11.4583 8.70833 11 8.75H8.75V11C8.70833 11.4583 8.45833 11.7083 8 11.75C7.54167 11.7083 7.29167 11.4583 7.25 11V8.75H5C4.54167 8.70833 4.29167 8.45833 4.25 8C4.29167 7.54167 4.54167 7.29167 5 7.25H7.25V5C7.25 4.79167 7.33333 4.61458 7.5 4.46875C7.64583 4.32292 7.82292 4.25 8.03125 4.25C8.46875 4.29167 8.70833 4.54167 8.75 5V7.25H11ZM8 0C9.5 0.0208333 10.8438 0.385417 12.0312 1.09375C13.2396 1.80208 14.1979 2.76042 14.9062 3.96875C15.6146 5.15625 15.9792 6.5 16 8C15.9792 9.5 15.6146 10.8438 14.9062 12.0312C14.1979 13.2396 13.2396 14.1979 12.0312 14.9062C10.8438 15.6146 9.5 15.9792 8 16C6.5 15.9792 5.15625 15.6146 3.96875 14.9062C2.76042 14.1979 1.80208 13.2396 1.09375 12.0312C0.385417 10.8438 0.0208333 9.5 0 8C0.0208333 6.5 0.385417 5.15625 1.09375 3.96875C1.80208 2.76042 2.76042 1.80208 3.96875 1.09375C5.15625 0.385417 6.5 0.0208333 8 0ZM8 14.5C9.83333 14.4583 11.3646 13.8229 12.5938 12.5938C13.8229 11.3646 14.4583 9.83333 14.5 8C14.4583 6.16667 13.8229 4.63542 12.5938 3.40625C11.3646 2.17708 9.83333 1.54167 8 1.5C6.16667 1.54167 4.63542 2.17708 3.40625 3.40625C2.17708 4.63542 1.54167 6.16667 1.5 8C1.54167 9.83333 2.17708 11.3646 3.40625 12.5938C4.63542 13.8229 6.16667 14.4583 8 14.5Z"
      />
    </symbol>`,
  "icon-stop-circle": `<symbol id="icon-stop-circle"
  viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      stroke-width="2"
      stroke-linecap="round"
      stroke-linejoin="round"
    >
      <circle cx="12" cy="12" r="10"></circle>
      <rect x="9" y="9" width="6" height="6"></rect>
    </symbol>`,
  "icon-slash-circle": `<symbol id="icon-slash-circle"
     viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      stroke-width="2"
      stroke-linecap="round"
      stroke-linejoin="round"
    >
      <circle cx="12" cy="12" r="10"></circle>
      <line x1="4.93" y1="4.93" x2="19.07" y2="19.07"></line>
    </symbol>`,
  "icon-message": `<symbol id="icon-message" viewBox="0 0 16 16">
      <path
        
        d="M8.00368 1C9.48284 1.02083 10.8266 1.3125 12.0349 1.875C13.2224 2.45833 14.1703 3.23958 14.8787 4.21875C15.587 5.19792 15.9516 6.29167 15.9724 7.5C15.9516 8.70833 15.587 9.80208 14.8787 10.7812C14.1703 11.7604 13.2224 12.5417 12.0349 13.125C10.8266 13.6875 9.48284 13.9792 8.00368 14C6.96201 14 5.99326 13.8542 5.09743 13.5625C4.61826 13.8958 4.01409 14.2188 3.28493 14.5312C2.55576 14.8229 1.71201 14.9792 0.753676 15C0.441176 14.9792 0.21201 14.8229 0.0661765 14.5312C-0.0588235 14.2396 -0.0067402 13.9688 0.222426 13.7188C0.24326 13.6979 0.420343 13.4688 0.753676 13.0312C1.08701 12.6146 1.38909 12.0833 1.65993 11.4375C0.597426 10.3333 0.0453431 9.02083 0.00367647 7.5C0.0245098 6.29167 0.389093 5.19792 1.09743 4.21875C1.80576 3.23958 2.76409 2.45833 3.97243 1.875C5.15993 1.3125 6.50368 1.02083 8.00368 1ZM8.00368 12.5C9.83701 12.4583 11.3683 11.9688 12.5974 11.0312C13.8266 10.0938 14.462 8.91667 14.5037 7.5C14.462 6.08333 13.8266 4.90625 12.5974 3.96875C11.3683 3.03125 9.83701 2.54167 8.00368 2.5C6.17034 2.54167 4.63909 3.03125 3.40993 3.96875C2.18076 4.90625 1.54534 6.08333 1.50368 7.5C1.52451 8.16667 1.65993 8.73958 1.90993 9.21875C2.18076 9.71875 2.46201 10.1146 2.75368 10.4062L3.37868 11.0938L3.06618 11.9688C2.87868 12.4271 2.67034 12.8542 2.44118 13.25C3.19118 12.9792 3.78493 12.6771 4.22243 12.3438L4.84743 11.9062L5.56618 12.125C6.35784 12.375 7.17034 12.5 8.00368 12.5Z"
      />
    </symbol>`,
  "icon-bell": `<symbol id="icon-bell" viewBox="0 0 16 16">
      <path
        
        d="M9.0125 1V1.5625C10.1792 1.77083 11.1271 2.30208 11.8562 3.15625C12.6062 4.01042 12.9917 5.04167 13.0125 6.25V7.28125C13.0333 8.73958 13.4917 10.0417 14.3875 11.1875L14.8562 11.7812C15.0437 12.0312 15.075 12.2917 14.95 12.5625C14.8042 12.8333 14.575 12.9792 14.2625 13H1.7625C1.45 12.9792 1.22083 12.8333 1.075 12.5625C0.95 12.2917 0.98125 12.0312 1.16875 11.7812L1.6375 11.1875C2.53333 10.0417 2.99167 8.73958 3.0125 7.28125V6.25C3.03333 5.04167 3.41875 4.01042 4.16875 3.15625C4.89792 2.30208 5.84583 1.77083 7.0125 1.5625V1C7.0125 0.708333 7.10625 0.46875 7.29375 0.28125C7.48125 0.09375 7.72083 0 8.0125 0C8.30417 0 8.54375 0.09375 8.73125 0.28125C8.91875 0.46875 9.0125 0.708333 9.0125 1ZM7.7625 3C6.84583 3.02083 6.075 3.33333 5.45 3.9375C4.84583 4.5625 4.53333 5.33333 4.5125 6.25V7.28125C4.5125 8.82292 4.09583 10.2292 3.2625 11.5H12.7625C11.9292 10.2292 11.5125 8.82292 11.5125 7.28125V6.25C11.4917 5.33333 11.1792 4.5625 10.575 3.9375C9.95 3.33333 9.17917 3.02083 8.2625 3H7.7625ZM10.0125 14C10.0125 14.5417 9.81458 15.0104 9.41875 15.4062C9.02292 15.8021 8.55417 16 8.0125 16C7.47083 16 7.00208 15.8021 6.60625 15.4062C6.21042 15.0104 6.0125 14.5417 6.0125 14H10.0125Z"
      />
    </symbol>`,
  "icon-tag": `<symbol id="icon-tag" viewBox="0 0 16 16">
      <path
        
        d="M14.3125 6.625C14.7708 7.10417 15 7.64583 15 8.25C15 8.875 14.7708 9.42708 14.3125 9.90625L9.90625 14.3125C9.42708 14.7708 8.875 15 8.25 15C7.64583 15 7.10417 14.7708 6.625 14.3125L1.6875 9.375C1.47917 9.16667 1.3125 8.91667 1.1875 8.625C1.0625 8.33333 1 8.04167 1 7.75V2.53125C1.02083 2.09375 1.16667 1.72917 1.4375 1.4375C1.72917 1.16667 2.09375 1.02083 2.53125 1H7.75C8.04167 1 8.33333 1.0625 8.625 1.1875C8.91667 1.3125 9.16667 1.47917 9.375 1.6875L14.3125 6.625ZM13.25 8.84375C13.4167 8.67708 13.5 8.47917 13.5 8.25C13.5 8.02083 13.4167 7.83333 13.25 7.6875L8.3125 2.75C8.14583 2.60417 7.95833 2.52083 7.75 2.5H2.53125L2.5 2.53125V7.75C2.52083 7.95833 2.60417 8.14583 2.75 8.3125L7.6875 13.25C8.0625 13.5833 8.44792 13.5833 8.84375 13.25L13.25 8.84375ZM5.21875 4.5C5.17708 4.04167 4.9375 3.79167 4.5 3.75C4.04167 3.79167 3.79167 4.04167 3.75 4.5C3.79167 4.95833 4.03125 5.20833 4.46875 5.25C4.92708 5.20833 5.17708 4.95833 5.21875 4.5Z"
      />
    </symbol>`,
  "icon-download-cloud": `<symbol id="icon-download-cloud" viewBox="0 0 20 16">
      <path
        
        d="M16.9688 6.71875C17.8646 6.98958 18.5938 7.48958 19.1562 8.21875C19.6979 8.92708 19.9792 9.77083 20 10.75C19.9792 11.9583 19.5625 12.9583 18.75 13.75C17.9583 14.5625 16.9583 14.9792 15.75 15H4.5C3.22917 14.9583 2.16667 14.5208 1.3125 13.6875C0.479167 12.8333 0.0416667 11.7708 0 10.5C0.0208333 9.5 0.302083 8.625 0.84375 7.875C1.38542 7.125 2.10417 6.59375 3 6.28125C3.02083 4.78125 3.53125 3.54167 4.53125 2.5625C5.51042 1.5625 6.75 1.04167 8.25 1C9.125 1 9.92708 1.19792 10.6562 1.59375C11.3854 1.98958 11.9896 2.51042 12.4688 3.15625C12.8021 3.05208 13.1458 3 13.5 3C14.5 3.02083 15.3229 3.36458 15.9688 4.03125C16.6354 4.67708 16.9792 5.5 17 6.5C17 6.54167 17 6.58333 17 6.625C16.9792 6.64583 16.9688 6.67708 16.9688 6.71875ZM15.75 13.5C16.5208 13.4792 17.1667 13.2083 17.6875 12.6875C18.2083 12.1667 18.4792 11.5208 18.5 10.75C18.5 10.1458 18.3229 9.60417 17.9688 9.125C17.6146 8.64583 17.1354 8.3125 16.5312 8.125L15.4062 7.78125L15.4688 6.625C15.4896 5.97917 15.2708 5.42708 14.8125 4.96875C14.3333 4.53125 13.6979 4.40625 12.9062 4.59375L11.9062 4.90625L11.2812 4.0625C10.5104 3.04167 9.5 2.52083 8.25 2.5C7.20833 2.52083 6.33333 2.875 5.625 3.5625C4.91667 4.25 4.54167 5.11458 4.5 6.15625C4.5 6.19792 4.5 6.23958 4.5 6.28125C4.5 6.32292 4.5 6.47917 4.5 6.75C4.5 6.89583 4.5 7.09375 4.5 7.34375L3.5 7.6875C2.89583 7.91667 2.41667 8.28125 2.0625 8.78125C1.6875 9.28125 1.5 9.85417 1.5 10.5C1.52083 11.3542 1.8125 12.0625 2.375 12.625C2.9375 13.1875 3.64583 13.4792 4.5 13.5H15.75ZM12.2188 8.46875C12.5729 8.17708 12.9271 8.17708 13.2812 8.46875C13.5729 8.82292 13.5729 9.17708 13.2812 9.53125L10.5312 12.2812C10.4688 12.3438 10.3854 12.3958 10.2812 12.4375C10.1979 12.4792 10.1042 12.5 10 12.5C9.91667 12.5 9.8125 12.4792 9.6875 12.4375C9.60417 12.3958 9.52083 12.3438 9.4375 12.2812L6.6875 9.53125C6.39583 9.17708 6.39583 8.82292 6.6875 8.46875C7.04167 8.17708 7.39583 8.17708 7.75 8.46875L9.25 9.9375V6C9.29167 5.54167 9.54167 5.29167 10 5.25C10.4583 5.29167 10.7083 5.54167 10.75 6V9.9375L12.2188 8.46875Z"
      />
    </symbol>`,
  "icon-upload-cloud": `<symbol id="icon-upload-cloud" viewBox="0 0 20 16">
      <path
        
        d="M16.9688 6.71875C17.8646 6.98958 18.5938 7.48958 19.1562 8.21875C19.6979 8.92708 19.9792 9.77083 20 10.75C19.9792 11.9583 19.5625 12.9583 18.75 13.75C17.9583 14.5625 16.9583 14.9792 15.75 15H4.5C3.22917 14.9583 2.16667 14.5208 1.3125 13.6875C0.479167 12.8333 0.0416667 11.7708 0 10.5C0.0208333 9.5 0.302083 8.625 0.84375 7.875C1.38542 7.125 2.10417 6.59375 3 6.28125C3.02083 4.78125 3.53125 3.54167 4.53125 2.5625C5.51042 1.5625 6.75 1.04167 8.25 1C9.125 1 9.92708 1.19792 10.6562 1.59375C11.3854 1.98958 11.9896 2.51042 12.4688 3.15625C12.8021 3.05208 13.1458 3 13.5 3C14.5 3.02083 15.3229 3.36458 15.9688 4.03125C16.6354 4.67708 16.9792 5.5 17 6.5C17 6.54167 17 6.58333 17 6.625C16.9792 6.64583 16.9688 6.67708 16.9688 6.71875ZM15.75 13.5C16.5208 13.4792 17.1667 13.2083 17.6875 12.6875C18.2083 12.1667 18.4792 11.5208 18.5 10.75C18.5 10.1458 18.3229 9.60417 17.9688 9.125C17.6146 8.64583 17.1354 8.3125 16.5312 8.125L15.4062 7.78125L15.4688 6.625C15.4896 5.97917 15.2708 5.42708 14.8125 4.96875C14.3333 4.53125 13.6979 4.40625 12.9062 4.59375L11.9062 4.90625L11.2812 4.0625C10.5104 3.04167 9.5 2.52083 8.25 2.5C7.20833 2.52083 6.33333 2.875 5.625 3.5625C4.91667 4.25 4.54167 5.11458 4.5 6.15625C4.5 6.19792 4.5 6.23958 4.5 6.28125C4.5 6.32292 4.5 6.47917 4.5 6.75C4.5 6.89583 4.5 7.09375 4.5 7.34375L3.5 7.6875C2.89583 7.91667 2.41667 8.28125 2.0625 8.78125C1.6875 9.28125 1.5 9.85417 1.5 10.5C1.52083 11.3542 1.8125 12.0625 2.375 12.625C2.9375 13.1875 3.64583 13.4792 4.5 13.5H15.75ZM10.5 5.46875L13.2812 8.21875C13.5729 8.57292 13.5729 8.92708 13.2812 9.28125C13.1354 9.42708 12.9583 9.5 12.75 9.5C12.5417 9.5 12.3646 9.42708 12.2188 9.28125L10.75 7.8125V11.75C10.7083 12.2083 10.4583 12.4583 10 12.5C9.54167 12.4583 9.29167 12.2083 9.25 11.75V7.8125L7.78125 9.28125C7.42708 9.57292 7.07292 9.57292 6.71875 9.28125C6.42708 8.92708 6.42708 8.57292 6.71875 8.21875L9.46875 5.46875C9.55208 5.40625 9.625 5.35417 9.6875 5.3125C9.875 5.22917 10.0625 5.22917 10.25 5.3125C10.3542 5.35417 10.4375 5.40625 10.5 5.46875Z"
      />
    </symbol>`,
  "icon-flag": `<symbol id="icon-flag" viewBox="0 0 16 16">
      <path
        
        d="M14.875 0.00347222C15.1875 0.00347222 15.4479 0.0868055 15.6562 0.253472C15.8854 0.420139 16 0.659722 16 0.972222V10.3785C15.9792 10.7951 15.7604 11.0972 15.3438 11.2847C14.0104 11.7847 12.8438 12.0243 11.8438 12.0035C10.7396 11.9618 9.70833 11.7951 8.75 11.5035C7.8125 11.2118 6.78125 11.0451 5.65625 11.0035C4.53125 10.9618 3.14583 11.2951 1.5 12.0035V15.2535C1.45833 15.7118 1.20833 15.9618 0.75 16.0035C0.291667 15.9618 0.0416667 15.7118 0 15.2535V0.753472C0.0416667 0.295139 0.291667 0.0451389 0.75 0.00347222C1.20833 0.0451389 1.45833 0.295139 1.5 0.753472V1.00347C3.3125 0.295139 4.73958 -0.0381944 5.78125 0.00347222C6.86458 0.0659722 7.78125 0.243056 8.53125 0.534722C9.23958 0.805556 10.0312 0.961806 10.9062 1.00347C11.7604 1.04514 12.8854 0.753472 14.2812 0.128472C14.4896 0.0451389 14.6875 0.00347222 14.875 0.00347222ZM14.5 10.0035V1.69097C13.1875 2.23264 11.9896 2.50347 10.9062 2.50347C9.80208 2.46181 8.86458 2.28472 8.09375 1.97222C7.38542 1.70139 6.61458 1.54514 5.78125 1.50347C4.78125 1.50347 3.54167 1.80556 2.0625 2.40972L1.5 2.62847V10.3785C2.95833 9.79514 4.34375 9.50347 5.65625 9.50347C6.96875 9.56597 8.125 9.74306 9.125 10.0347C10 10.3056 10.9062 10.4618 11.8438 10.5035C12.6771 10.5035 13.5625 10.3368 14.5 10.0035Z"
      />
    </symbol>`,
  "icon-triangle-exclamation": `<symbol id="icon-triangle-exclamation" viewBox="0 0 16 16">
      <path
        
        d="M7.7625 2.63438C7.8125 2.55 7.90312 2.5 8 2.5C8.09688 2.5 8.1875 2.55 8.2375 2.63438L14.4344 12.8125C14.4781 12.8844 14.5 12.9656 14.5 13.0469C14.5 13.2969 14.2969 13.5 14.0469 13.5H1.95312C1.70312 13.5 1.5 13.2969 1.5 13.0469C1.5 12.9625 1.52187 12.8813 1.56562 12.8125L7.7625 2.63438ZM6.48125 1.85312L0.284375 12.0312C0.096875 12.3375 0 12.6875 0 13.0469C0 14.125 0.875 15 1.95312 15H14.0469C15.125 15 16 14.125 16 13.0469C16 12.6875 15.9 12.3375 15.7156 12.0312L9.51875 1.85312C9.19688 1.325 8.62187 1 8 1C7.37813 1 6.80312 1.325 6.48125 1.85312ZM9 11.5C9 11.2348 8.89464 10.9804 8.70711 10.7929C8.51957 10.6054 8.26522 10.5 8 10.5C7.73478 10.5 7.48043 10.6054 7.29289 10.7929C7.10536 10.9804 7 11.2348 7 11.5C7 11.7652 7.10536 12.0196 7.29289 12.2071C7.48043 12.3946 7.73478 12.5 8 12.5C8.26522 12.5 8.51957 12.3946 8.70711 12.2071C8.89464 12.0196 9 11.7652 9 11.5ZM8.75 5.75C8.75 5.33437 8.41562 5 8 5C7.58437 5 7.25 5.33437 7.25 5.75V8.75C7.25 9.16562 7.58437 9.5 8 9.5C8.41562 9.5 8.75 9.16562 8.75 8.75V5.75Z"
      />
    </symbol>`,
  "icon-folder": `<symbol id="icon-folder" viewBox="0 0 16 16">
      <path
        
        d="M14 3C14.5625 3.02083 15.0312 3.21875 15.4062 3.59375C15.7812 3.96875 15.9792 4.4375 16 5V13C15.9792 13.5625 15.7812 14.0312 15.4062 14.4062C15.0312 14.7812 14.5625 14.9792 14 15H2C1.4375 14.9792 0.96875 14.7812 0.59375 14.4062C0.21875 14.0312 0.0208333 13.5625 0 13V3C0.0208333 2.4375 0.21875 1.96875 0.59375 1.59375C0.96875 1.21875 1.4375 1.02083 2 1H5.6875C6.22917 1 6.69792 1.19792 7.09375 1.59375L8.625 3H14ZM2 2.5C1.6875 2.52083 1.52083 2.6875 1.5 3V6H14.5V5C14.4792 4.6875 14.3125 4.52083 14 4.5H8L6.03125 2.65625C5.92708 2.55208 5.8125 2.5 5.6875 2.5H2ZM14 13.5C14.3125 13.4792 14.4792 13.3125 14.5 13V7.5H1.5V13C1.52083 13.3125 1.6875 13.4792 2 13.5H14Z"
      />
    </symbol>`,
  "icon-list": `<symbol id="icon-list" viewBox="0 0 16 16">
      <path
        
        d="M2.5 6.5C2.8125 6.52083 2.97917 6.6875 3 7V9C2.97917 9.3125 2.8125 9.47917 2.5 9.5H0.5C0.1875 9.47917 0.0208333 9.3125 0 9V7C0.0208333 6.6875 0.1875 6.52083 0.5 6.5H2.5ZM2.5 11.5C2.8125 11.5208 2.97917 11.6875 3 12V14C2.97917 14.3125 2.8125 14.4792 2.5 14.5H0.5C0.1875 14.4792 0.0208333 14.3125 0 14V12C0.0208333 11.6875 0.1875 11.5208 0.5 11.5H2.5ZM2.5 1.5C2.8125 1.52083 2.97917 1.6875 3 2V4C2.97917 4.3125 2.8125 4.47917 2.5 4.5H0.5C0.1875 4.47917 0.0208333 4.3125 0 4V2C0.0208333 1.6875 0.1875 1.52083 0.5 1.5H2.5ZM15.25 7.25C15.7083 7.29167 15.9583 7.54167 16 8C15.9583 8.45833 15.7083 8.70833 15.25 8.75H5.71875C5.28125 8.70833 5.04167 8.45833 5 8C5.04167 7.54167 5.28125 7.29167 5.71875 7.25H15.25ZM15.25 2.25C15.4583 2.25 15.6354 2.33333 15.7812 2.5C15.9271 2.64583 16 2.82292 16 3.03125C15.9583 3.46875 15.7083 3.70833 15.25 3.75H5.71875C5.53125 3.75 5.36458 3.66667 5.21875 3.5C5.07292 3.35417 5 3.17708 5 2.96875C5.04167 2.53125 5.28125 2.29167 5.71875 2.25H15.25ZM15.25 12.25C15.7083 12.2917 15.9583 12.5417 16 13C15.9583 13.4583 15.7083 13.7083 15.25 13.75H5.71875C5.28125 13.7083 5.04167 13.4583 5 13C5.04167 12.5417 5.28125 12.2917 5.71875 12.25H15.25Z"
      />
    </symbol>`,
  "icon-refresh": `<symbol id="icon-refresh" viewBox="0 0 16 16">
      <path
        
        d="M14.2188 9C14.6354 9.1875 14.7917 9.51042 14.6875 9.96875C14.2292 11.4688 13.3854 12.6771 12.1562 13.5938C10.9479 14.5104 9.55208 14.9792 7.96875 15C6.71875 14.9792 5.57292 14.6667 4.53125 14.0625C3.48958 13.4375 2.64583 12.6042 2 11.5625V14.75C1.95833 15.2083 1.70833 15.4583 1.25 15.5C0.791667 15.4583 0.541667 15.2083 0.5 14.75V9.75C0.541667 9.29167 0.791667 9.04167 1.25 9H6.25C6.6875 9.04167 6.92708 9.29167 6.96875 9.75C6.92708 10.2083 6.67708 10.4583 6.21875 10.5H3.09375C3.57292 11.4167 4.23958 12.1458 5.09375 12.6875C5.94792 13.2083 6.90625 13.4792 7.96875 13.5C9.21875 13.4792 10.3229 13.1146 11.2812 12.4062C12.2604 11.6771 12.9271 10.7083 13.2812 9.5C13.4479 9.08333 13.7604 8.91667 14.2188 9ZM14.75 0.5C15.2083 0.541667 15.4583 0.791667 15.5 1.25V6.25C15.4583 6.70833 15.2083 6.95833 14.75 7H9.75C9.29167 6.95833 9.04167 6.70833 9 6.25C9.04167 5.79167 9.29167 5.54167 9.75 5.5H12.9062C12.4062 4.58333 11.7292 3.85417 10.875 3.3125C10.0208 2.79167 9.0625 2.52083 8 2.5C6.75 2.52083 5.64583 2.88542 4.6875 3.59375C3.75 4.32292 3.09375 5.28125 2.71875 6.46875C2.55208 6.88542 2.23958 7.05208 1.78125 6.96875C1.36458 6.80208 1.19792 6.48958 1.28125 6.03125C1.73958 4.53125 2.58333 3.32292 3.8125 2.40625C5.02083 1.48958 6.41667 1.02083 8 1C9.27083 1.02083 10.4271 1.33333 11.4688 1.9375C12.5104 2.5625 13.3542 3.39583 14 4.4375V1.25C14.0417 0.791667 14.2917 0.541667 14.75 0.5Z"
      />
    </symbol>`,
  "icon-star": `<symbol id="icon-star" viewBox="0 0 18 16">
      <path
        
        d="M16.5 5.375C16.9167 5.45833 17.1771 5.67708 17.2812 6.03125C17.4062 6.40625 17.3229 6.76042 17.0312 7.09375L13.7187 10.2812L14.5 14.8438C14.5625 15.1771 14.4896 15.4479 14.2812 15.6562C14.0729 15.8854 13.8229 16 13.5312 16C13.3646 16 13.2083 15.9583 13.0625 15.875L8.96875 13.75L4.875 15.875C4.72917 15.9583 4.57292 16 4.40625 16C4.11458 16 3.86458 15.8854 3.65625 15.6562C3.44792 15.4479 3.375 15.1771 3.4375 14.8438L4.21875 10.25L0.906248 7.0625C0.614582 6.75 0.531248 6.40625 0.656248 6.03125C0.760415 5.67708 1.02083 5.45833 1.4375 5.375L6.03125 4.6875L8.0625 0.5625C8.29167 0.1875 8.58333 0 8.9375 0C9.35417 0 9.66667 0.1875 9.875 0.5625L11.9062 4.6875L16.5 5.375ZM12.1562 10.0312C12.1354 9.84375 12.1875 9.6875 12.3125 9.5625L15.2812 6.6875L11.1875 6.09375C11 6.07292 10.875 5.97917 10.8125 5.8125L8.96875 2.125L7.125 5.84375C7.0625 5.98958 6.9375 6.07292 6.75 6.09375L2.6875 6.6875L5.625 9.5625C5.72917 9.6875 5.78125 9.84375 5.78125 10.0312L5.0625 14.0938L8.75 12.1562C8.89583 12.0938 9.04167 12.0938 9.1875 12.1562L12.875 14.0938L12.1562 10.0312Z"
      />
    </symbol>`,
  "icon-star-filled": `<symbol id="icon-star-filled" viewBox="0 0 18 16">
      <path
        
        d="M9.88071 0.5625C9.7127 0.21875 9.35765 0 8.96772 0C8.5778 0 8.22591 0.21875 8.05473 0.5625L6.01634 4.69688L1.46406 5.35938C1.08365 5.41563 0.766634 5.67812 0.64934 6.0375C0.532045 6.39687 0.627149 6.79375 0.899779 7.05937L4.20304 10.2812L3.42319 14.8344C3.35979 15.2094 3.51829 15.5906 3.83214 15.8125C4.14598 16.0344 4.56126 16.0625 4.90363 15.8844L8.97089 13.7437L13.0381 15.8844C13.3805 16.0625 13.7958 16.0375 14.1096 15.8125C14.4235 15.5875 14.582 15.2094 14.5186 14.8344L13.7356 10.2812L17.0388 7.05937C17.3115 6.79375 17.4097 6.39687 17.2893 6.0375C17.1688 5.67812 16.855 5.41563 16.4746 5.35938L11.9191 4.69688L9.88071 0.5625Z"
      />
    </symbol>`,
  "icon-user": `<symbol id="icon-user" viewBox="0 0 16 16">
      <path
        
        d="M9.5 9.5C11.0625 9.54167 12.3542 10.0833 13.375 11.125C14.4167 12.1458 14.9583 13.4375 15 15C15 15.2917 14.9062 15.5312 14.7188 15.7188C14.5312 15.9062 14.2917 16 14 16H2C1.70833 16 1.46875 15.9062 1.28125 15.7188C1.09375 15.5312 1 15.2917 1 15C1.04167 13.4375 1.58333 12.1458 2.625 11.125C3.64583 10.0833 4.9375 9.54167 6.5 9.5H9.5ZM2.53125 14.5H13.4688C13.3229 13.5 12.8854 12.6667 12.1562 12C11.4271 11.3542 10.5417 11.0208 9.5 11H6.5C5.45833 11.0208 4.57292 11.3542 3.84375 12C3.11458 12.6667 2.67708 13.5 2.53125 14.5ZM8 8C6.875 7.97917 5.92708 7.59375 5.15625 6.84375C4.40625 6.07292 4.02083 5.125 4 4C4.02083 2.875 4.40625 1.92708 5.15625 1.15625C5.92708 0.40625 6.875 0.0208333 8 0C9.125 0.0208333 10.0729 0.40625 10.8438 1.15625C11.5938 1.92708 11.9792 2.875 12 4C11.9792 5.125 11.5938 6.07292 10.8438 6.84375C10.0729 7.59375 9.125 7.97917 8 8ZM8 1.5C7.29167 1.52083 6.69792 1.76042 6.21875 2.21875C5.76042 2.69792 5.52083 3.29167 5.5 4C5.52083 4.70833 5.76042 5.30208 6.21875 5.78125C6.69792 6.23958 7.29167 6.47917 8 6.5C8.70833 6.47917 9.30208 6.23958 9.78125 5.78125C10.2396 5.30208 10.4792 4.70833 10.5 4C10.4792 3.29167 10.2396 2.69792 9.78125 2.21875C9.30208 1.76042 8.70833 1.52083 8 1.5Z"
      />
    </symbol>`,
  "icon-users": `<symbol id="icon-users" viewBox="0 0 20 16">
      <path
        
        d="M7 8C5.875 7.97917 4.92708 7.59375 4.15625 6.84375C3.40625 6.07292 3.02083 5.125 3 4C3.02083 2.875 3.40625 1.92708 4.15625 1.15625C4.92708 0.40625 5.875 0.0208333 7 0C8.125 0.0208333 9.07292 0.40625 9.84375 1.15625C10.5938 1.92708 10.9792 2.875 11 4C10.9792 5.125 10.5938 6.07292 9.84375 6.84375C9.07292 7.59375 8.125 7.97917 7 8ZM7 1.5C6.29167 1.52083 5.69792 1.76042 5.21875 2.21875C4.76042 2.69792 4.52083 3.29167 4.5 4C4.52083 4.70833 4.76042 5.30208 5.21875 5.78125C5.69792 6.23958 6.29167 6.47917 7 6.5C7.70833 6.47917 8.30208 6.23958 8.78125 5.78125C9.23958 5.30208 9.47917 4.70833 9.5 4C9.47917 3.29167 9.23958 2.69792 8.78125 2.21875C8.30208 1.76042 7.70833 1.52083 7 1.5ZM8.59375 9.5C10.1146 9.54167 11.3854 10.0729 12.4062 11.0938C13.4271 12.1146 13.9583 13.3854 14 14.9062C14 15.2188 13.8958 15.4792 13.6875 15.6875C13.4792 15.8958 13.2188 16 12.9062 16H1.09375C0.78125 16 0.520833 15.8958 0.3125 15.6875C0.104167 15.4792 0 15.2188 0 14.9062C0.0416667 13.3854 0.572917 12.1146 1.59375 11.0938C2.61458 10.0729 3.88542 9.54167 5.40625 9.5H8.59375ZM1.53125 14.5H12.4688C12.3438 13.5 11.9167 12.6667 11.1875 12C10.4792 11.3542 9.61458 11.0208 8.59375 11H5.40625C4.38542 11.0208 3.51042 11.3542 2.78125 12C2.07292 12.6667 1.65625 13.5 1.53125 14.5ZM14.9688 10C16.4062 10.0417 17.5938 10.5312 18.5312 11.4688C19.4688 12.4062 19.9583 13.5729 20 14.9688C20 15.2604 19.9062 15.5 19.7188 15.6875C19.5312 15.8958 19.2917 16 19 16H14.6875C14.8958 15.6875 15 15.3229 15 14.9062C15 13.9271 14.7917 13.0104 14.375 12.1562C13.9583 11.3229 13.3854 10.6042 12.6562 10H14.9688ZM13.5 8C12.5 7.97917 11.6667 7.63542 11 6.96875C11.6458 6.11458 11.9792 5.125 12 4C11.9792 3.16667 11.7812 2.40625 11.4062 1.71875C12.0104 1.26042 12.7083 1.02083 13.5 1C14.5 1.02083 15.3229 1.36458 15.9688 2.03125C16.6354 2.67708 16.9792 3.5 17 4.5C16.9792 5.5 16.6354 6.32292 15.9688 6.96875C15.3229 7.63542 14.5 7.97917 13.5 8Z"
      />
    </symbol>`,
  "icon-user-plus": `<symbol id="icon-user-plus" viewBox="0 0 20 16">
      <path
        
        d="M7 8C5.875 7.97917 4.92708 7.59375 4.15625 6.84375C3.40625 6.07292 3.02083 5.125 3 4C3.02083 2.875 3.40625 1.92708 4.15625 1.15625C4.92708 0.40625 5.875 0.0208333 7 0C8.125 0.0208333 9.07292 0.40625 9.84375 1.15625C10.5938 1.92708 10.9792 2.875 11 4C10.9792 5.125 10.5938 6.07292 9.84375 6.84375C9.07292 7.59375 8.125 7.97917 7 8ZM7 1.5C6.29167 1.52083 5.69792 1.76042 5.21875 2.21875C4.76042 2.69792 4.52083 3.29167 4.5 4C4.52083 4.70833 4.76042 5.30208 5.21875 5.78125C5.69792 6.23958 6.29167 6.47917 7 6.5C7.70833 6.47917 8.30208 6.23958 8.78125 5.78125C9.23958 5.30208 9.47917 4.70833 9.5 4C9.47917 3.29167 9.23958 2.69792 8.78125 2.21875C8.30208 1.76042 7.70833 1.52083 7 1.5ZM8.59375 9.5C10.1146 9.54167 11.3854 10.0729 12.4062 11.0938C13.4271 12.1146 13.9583 13.3854 14 14.9062C14 15.2188 13.8958 15.4792 13.6875 15.6875C13.4792 15.8958 13.2188 16 12.9062 16H1.09375C0.78125 16 0.520833 15.8958 0.3125 15.6875C0.104167 15.4792 0 15.2188 0 14.9062C0.0416667 13.3854 0.572917 12.1146 1.59375 11.0938C2.61458 10.0729 3.88542 9.54167 5.40625 9.5H8.59375ZM1.53125 14.5H12.4688C12.3438 13.5 11.9167 12.6667 11.1875 12C10.4792 11.3542 9.61458 11.0208 8.59375 11H5.40625C4.38542 11.0208 3.51042 11.3542 2.78125 12C2.07292 12.6667 1.65625 13.5 1.53125 14.5ZM19.25 6.25C19.7083 6.29167 19.9583 6.54167 20 7C19.9583 7.45833 19.7083 7.70833 19.25 7.75H17.75V9.25C17.7083 9.70833 17.4583 9.95833 17 10C16.5417 9.95833 16.2917 9.70833 16.25 9.25V7.75H14.75C14.2917 7.70833 14.0417 7.45833 14 7C14.0417 6.54167 14.2917 6.29167 14.75 6.25H16.25V4.75C16.2917 4.29167 16.5417 4.04167 17 4C17.4583 4.04167 17.7083 4.29167 17.75 4.75V6.25H19.25Z"
      />
    </symbol>`,
  "icon-user-check": `<symbol id="icon-user-check" viewBox="0 0 20 16">
      <path
        
        d="M8.59375 9.5C10.1146 9.54167 11.3854 10.0729 12.4062 11.0938C13.4271 12.1146 13.9583 13.3854 14 14.9062C14 15.2188 13.8958 15.4792 13.6875 15.6875C13.4792 15.8958 13.2188 16 12.9062 16H1.09375C0.78125 16 0.520833 15.8958 0.3125 15.6875C0.104167 15.4792 0 15.2188 0 14.9062C0.0416667 13.3854 0.572917 12.1146 1.59375 11.0938C2.61458 10.0729 3.88542 9.54167 5.40625 9.5H8.59375ZM1.53125 14.5H12.4688C12.3438 13.5 11.9167 12.6667 11.1875 12C10.4792 11.3542 9.61458 11.0208 8.59375 11H5.40625C4.38542 11.0208 3.51042 11.3542 2.78125 12C2.07292 12.6667 1.65625 13.5 1.53125 14.5ZM7 8C5.875 7.97917 4.92708 7.59375 4.15625 6.84375C3.40625 6.07292 3.02083 5.125 3 4C3.02083 2.875 3.40625 1.92708 4.15625 1.15625C4.92708 0.40625 5.875 0.0208333 7 0C8.125 0.0208333 9.07292 0.40625 9.84375 1.15625C10.5938 1.92708 10.9792 2.875 11 4C10.9792 5.125 10.5938 6.07292 9.84375 6.84375C9.07292 7.59375 8.125 7.97917 7 8ZM7 1.5C6.29167 1.52083 5.69792 1.76042 5.21875 2.21875C4.76042 2.69792 4.52083 3.29167 4.5 4C4.52083 4.70833 4.76042 5.30208 5.21875 5.78125C5.69792 6.23958 6.29167 6.47917 7 6.5C7.70833 6.47917 8.30208 6.23958 8.78125 5.78125C9.23958 5.30208 9.47917 4.70833 9.5 4C9.47917 3.29167 9.23958 2.69792 8.78125 2.21875C8.30208 1.76042 7.70833 1.52083 7 1.5ZM19.75 4.1875C20.0625 4.54167 20.0833 4.89583 19.8125 5.25L16.5625 8.75C16.4167 8.91667 16.2292 9 16 9C15.7917 9 15.6146 8.92708 15.4688 8.78125L13.7188 7.03125C13.4271 6.67708 13.4271 6.32292 13.7188 5.96875C14.0729 5.67708 14.4271 5.67708 14.7812 5.96875L15.9688 7.15625L18.6875 4.25C19.0417 3.9375 19.3958 3.91667 19.75 4.1875Z"
      />
    </symbol>`,
  "icon-user-x": `<symbol id="icon-user-x" viewBox="0 0 20 16">
      <path
        
        d="M8.59375 9.5C10.1146 9.54167 11.3854 10.0729 12.4062 11.0938C13.4271 12.1146 13.9583 13.3854 14 14.9062C14 15.2188 13.8958 15.4792 13.6875 15.6875C13.4792 15.8958 13.2188 16 12.9062 16H1.09375C0.78125 16 0.520833 15.8958 0.3125 15.6875C0.104167 15.4792 0 15.2188 0 14.9062C0.0416667 13.3854 0.572917 12.1146 1.59375 11.0938C2.61458 10.0729 3.88542 9.54167 5.40625 9.5H8.59375ZM1.53125 14.5H12.4688C12.3438 13.5 11.9167 12.6667 11.1875 12C10.4792 11.3542 9.61458 11.0208 8.59375 11H5.40625C4.38542 11.0208 3.51042 11.3542 2.78125 12C2.07292 12.6667 1.65625 13.5 1.53125 14.5ZM7 8C5.875 7.97917 4.92708 7.59375 4.15625 6.84375C3.40625 6.07292 3.02083 5.125 3 4C3.02083 2.875 3.40625 1.92708 4.15625 1.15625C4.92708 0.40625 5.875 0.0208333 7 0C8.125 0.0208333 9.07292 0.40625 9.84375 1.15625C10.5938 1.92708 10.9792 2.875 11 4C10.9792 5.125 10.5938 6.07292 9.84375 6.84375C9.07292 7.59375 8.125 7.97917 7 8ZM7 1.5C6.29167 1.52083 5.69792 1.76042 5.21875 2.21875C4.76042 2.69792 4.52083 3.29167 4.5 4C4.52083 4.70833 4.76042 5.30208 5.21875 5.78125C5.69792 6.23958 6.29167 6.47917 7 6.5C7.70833 6.47917 8.30208 6.23958 8.78125 5.78125C9.23958 5.30208 9.47917 4.70833 9.5 4C9.47917 3.29167 9.23958 2.69792 8.78125 2.21875C8.30208 1.76042 7.70833 1.52083 7 1.5ZM18.0625 6.96875L19.5312 8.46875C19.8229 8.82292 19.8229 9.17708 19.5312 9.53125C19.1771 9.82292 18.8229 9.82292 18.4688 9.53125L17 8.0625L15.5312 9.53125C15.1771 9.82292 14.8229 9.82292 14.4688 9.53125C14.1771 9.17708 14.1771 8.82292 14.4688 8.46875L15.9375 7L14.4688 5.53125C14.1771 5.17708 14.1771 4.82292 14.4688 4.46875C14.8229 4.17708 15.1771 4.17708 15.5312 4.46875L17 5.9375L18.4688 4.4375C18.8229 4.14583 19.1771 4.14583 19.5312 4.4375C19.8229 4.79167 19.8229 5.14583 19.5312 5.5L18.0625 6.96875Z"
      />
    </symbol>`,
  "icon-image": `<symbol id="icon-image" viewBox="0 0 16 16">
      <path
        
        d="M4.75 3.75C5.16667 3.77083 5.52083 3.91667 5.8125 4.1875C6.08333 4.47917 6.22917 4.83333 6.25 5.25C6.22917 5.66667 6.08333 6.02083 5.8125 6.3125C5.52083 6.58333 5.16667 6.72917 4.75 6.75C4.33333 6.72917 3.97917 6.58333 3.6875 6.3125C3.41667 6.02083 3.27083 5.66667 3.25 5.25C3.27083 4.83333 3.41667 4.47917 3.6875 4.1875C3.97917 3.91667 4.33333 3.77083 4.75 3.75ZM13.9688 1C14.5521 1.02083 15.0312 1.21875 15.4062 1.59375C15.7604 1.96875 15.9479 2.4375 15.9688 3V13C15.9479 13.5625 15.75 14.0312 15.375 14.4062C15 14.7812 14.5312 14.9792 13.9688 15H1.96875C1.42708 14.9792 0.96875 14.7812 0.59375 14.4062C0.21875 14.0312 0.0208333 13.5625 0 13V3C0.0208333 2.4375 0.21875 1.96875 0.59375 1.59375C0.96875 1.21875 1.42708 1.02083 1.96875 1H13.9688ZM14.4688 12.7812H14.5V3C14.4792 2.6875 14.3125 2.52083 14 2.5H2C1.6875 2.52083 1.52083 2.6875 1.5 3V12.9688L3.875 10.0312C3.97917 9.90625 4.125 9.84375 4.3125 9.84375C4.52083 9.84375 4.67708 9.90625 4.78125 10.0312L5.9375 11.4688L9.28125 6.96875C9.38542 6.82292 9.54167 6.75 9.75 6.75C9.95833 6.75 10.1042 6.82292 10.1875 6.96875L14.4688 12.7812Z"
      />
    </symbol>`,
  "icon-inbox": `<symbol id="icon-inbox" viewBox="0 0 16 16">
      <path
        
        d="M15.875 9.5625C15.9583 9.875 16 10.1979 16 10.5312V13.0312C15.9792 13.5938 15.7812 14.0625 15.4062 14.4375C15.0312 14.8125 14.5625 15.0104 14 15.0312H2C1.4375 15.0104 0.96875 14.8125 0.59375 14.4375C0.21875 14.0625 0.0208333 13.5938 0 13.0312V10.5312C0 10.1979 0.0416667 9.875 0.125 9.5625L2.03125 1.75C2.17708 1.29167 2.5 1.04167 3 1H13C13.5 1.02083 13.8229 1.28125 13.9688 1.78125L15.875 9.5625ZM3.40625 2.53125L1.78125 9.03125H4.5C4.8125 9.05208 5.04167 9.1875 5.1875 9.4375L5.96875 11.0312H10.0312L10.8438 9.4375C10.9688 9.1875 11.1875 9.05208 11.5 9.03125H14.2188L12.625 2.53125H3.40625ZM14.5 13.0312V10.5312H11.9688L11.1562 12.125C11.0312 12.375 10.8125 12.5104 10.5 12.5312H5.5C5.1875 12.5104 4.96875 12.375 4.84375 12.125L4.03125 10.5312H1.5V13.0312C1.52083 13.3438 1.6875 13.5104 2 13.5312H14C14.3125 13.5104 14.4792 13.3438 14.5 13.0312Z"
      />
    </symbol>`,
  "icon-inbox-filled": `<symbol id="icon-inbox-filled" viewBox="0 0 16 16">
      <path
        
        d="M15.875 9.53125C15.9583 9.84375 16 10.1667 16 10.5V13C15.9792 13.5625 15.7812 14.0312 15.4062 14.4062C15.0312 14.7812 14.5625 14.9792 14 15H2C1.4375 14.9792 0.96875 14.7812 0.59375 14.4062C0.21875 14.0312 0.0208333 13.5625 0 13V10.5C0 10.1667 0.0416667 9.84375 0.125 9.53125L2.03125 1.75C2.17708 1.27083 2.5 1.02083 3 1H13C13.5 1.02083 13.8229 1.27083 13.9688 1.75L15.875 9.53125ZM3.40625 2.5L1.78125 9H4.5C4.8125 9.02083 5.04167 9.15625 5.1875 9.40625L5.96875 11H10.0312L10.8438 9.40625C10.9688 9.15625 11.1875 9.02083 11.5 9H14.2188L12.625 2.5H3.40625ZM14.5 13V10.5H11.9688L11.1562 12.0938C11.0312 12.3438 10.8125 12.4792 10.5 12.5H5.5C5.1875 12.4792 4.96875 12.3438 4.84375 12.0938L4.03125 10.5H1.5V13C1.52083 13.3125 1.6875 13.4792 2 13.5H14C14.3125 13.4792 14.4792 13.3125 14.5 13ZM5.75 5.5C5.29167 5.45833 5.04167 5.20833 5 4.75C5.04167 4.29167 5.29167 4.04167 5.75 4H10.25C10.7083 4.04167 10.9583 4.29167 11 4.75C10.9583 5.20833 10.7083 5.45833 10.25 5.5H5.75ZM11.25 8H4.75C4.29167 7.95833 4.04167 7.70833 4 7.25C4.04167 6.79167 4.29167 6.54167 4.75 6.5H11.25C11.7083 6.54167 11.9583 6.79167 12 7.25C11.9583 7.70833 11.7083 7.95833 11.25 8Z"
      />
    </symbol>`,
  "icon-clock": `<symbol id="icon-clock" viewBox="0 0 16 16">
      <path
        
        d="M7.25 3.75C7.29167 3.29167 7.54167 3.04167 8 3C8.45833 3.04167 8.70833 3.29167 8.75 3.75V7.59375L11.4062 9.375C11.7812 9.66667 11.8438 10.0104 11.5938 10.4062C11.3229 10.7812 10.9896 10.8438 10.5938 10.5938L7.59375 8.59375C7.36458 8.46875 7.25 8.26042 7.25 7.96875V3.75ZM8 0C9.5 0.0208333 10.8438 0.385417 12.0312 1.09375C13.2396 1.80208 14.1979 2.76042 14.9062 3.96875C15.6146 5.15625 15.9792 6.5 16 8C15.9792 9.5 15.6146 10.8438 14.9062 12.0312C14.1979 13.2396 13.2396 14.1979 12.0312 14.9062C10.8438 15.6146 9.5 15.9792 8 16C6.5 15.9792 5.15625 15.6146 3.96875 14.9062C2.76042 14.1979 1.80208 13.2396 1.09375 12.0312C0.385417 10.8438 0.0208333 9.5 0 8C0.0208333 6.5 0.385417 5.15625 1.09375 3.96875C1.80208 2.76042 2.76042 1.80208 3.96875 1.09375C5.15625 0.385417 6.5 0.0208333 8 0ZM1.5 8C1.54167 9.83333 2.17708 11.3646 3.40625 12.5938C4.63542 13.8229 6.16667 14.4583 8 14.5C9.83333 14.4583 11.3646 13.8229 12.5938 12.5938C13.8229 11.3646 14.4583 9.83333 14.5 8C14.4583 6.16667 13.8229 4.63542 12.5938 3.40625C11.3646 2.17708 9.83333 1.54167 8 1.5C6.16667 1.54167 4.63542 2.17708 3.40625 3.40625C2.17708 4.63542 1.54167 6.16667 1.5 8Z"
      />
    </symbol>`,
  "icon-eye-off": `<symbol id="icon-eye-off" viewBox="0 0 20 16">
      <path
        
        d="M19.7232 14.6562C20.0565 14.9896 20.0878 15.3333 19.817 15.6875C19.5045 16.0208 19.1503 16.0625 18.7545 15.8125L0.285714 1.34375C-0.047619 1.03125 -0.0892857 0.677083 0.160714 0.28125C0.327381 0.09375 0.525298 0 0.754464 0C0.921131 0 1.07738 0.0520833 1.22321 0.15625L4.66071 2.90625C6.24405 1.69792 8.0253 1.08333 10.0045 1.0625C11.942 1.08333 13.692 1.67708 15.2545 2.84375C16.817 3.98958 18.0357 5.54167 18.9107 7.5C18.9732 7.66667 19.0045 7.84375 19.0045 8.03125C19.0045 8.21875 18.9732 8.39583 18.9107 8.5625C18.2857 9.91667 17.4732 11.1042 16.4732 12.125L19.7232 14.6562ZM12.317 8.875C12.442 8.60417 12.5045 8.3125 12.5045 8C12.4836 7.29167 12.244 6.69792 11.7857 6.21875C11.3065 5.76042 10.7128 5.52083 10.0045 5.5C10.0045 5.5 9.99405 5.5 9.97321 5.5C9.95238 5.5 9.93155 5.5 9.91071 5.5C9.95238 5.66667 9.97321 5.83333 9.97321 6C9.95238 6.3125 9.88988 6.61458 9.78571 6.90625L12.317 8.875ZM13.5357 9.8125L15.2857 11.1562C16.1815 10.3021 16.9211 9.23958 17.5045 7.96875C16.7128 6.28125 15.6607 4.94792 14.3482 3.96875C13.0357 3.01042 11.5878 2.52083 10.0045 2.5C8.5253 2.52083 7.1503 2.95833 5.87946 3.8125L7.37946 5C8.10863 4.35417 8.98363 4.02083 10.0045 4C11.1295 4.02083 12.0774 4.41667 12.8482 5.1875C13.5982 5.9375 13.9836 6.875 14.0045 8C13.9836 8.66667 13.8274 9.27083 13.5357 9.8125ZM10.0045 12C8.87946 11.9792 7.93155 11.5938 7.16071 10.8438C6.41071 10.0729 6.0253 9.125 6.00446 8C6.00446 7.95833 6.00446 7.90625 6.00446 7.84375C6.0253 7.80208 6.03571 7.77083 6.03571 7.75L7.78571 9.125C8.13988 9.8125 8.70238 10.25 9.47321 10.4375L11.192 11.8125C10.817 11.9375 10.4211 12 10.0045 12ZM10.0045 13.5C10.942 13.5 11.817 13.3021 12.6295 12.9062L13.9732 13.9688C12.744 14.6354 11.4107 14.9688 9.97321 14.9688C8.03571 14.9479 6.28571 14.3542 4.72321 13.1875C3.16071 12.0417 1.95238 10.4896 1.09821 8.53125C1.01488 8.36458 0.973214 8.1875 0.973214 8C0.994048 7.8125 1.03571 7.63542 1.09821 7.46875C1.49405 6.57292 1.97321 5.75 2.53571 5L3.72321 5.96875C3.26488 6.59375 2.85863 7.28125 2.50446 8.03125C3.29613 9.71875 4.34821 11.0521 5.66071 12.0312C6.97321 12.9896 8.42113 13.4792 10.0045 13.5Z"
      />
    </symbol>`,
  "icon-eye": `<symbol id="icon-eye" viewBox="0 0 18 16">
      <path
        
        d="M17.9062 7.4375C17.9688 7.625 18 7.8125 18 8C18 8.16667 17.9688 8.35417 17.9062 8.5625C17.0312 10.5 15.8125 12.0521 14.25 13.2188C12.6875 14.3854 10.9375 14.9792 9 15C7.0625 14.9792 5.3125 14.3854 3.75 13.2188C2.1875 12.0521 0.96875 10.4896 0.09375 8.53125C0.03125 8.36458 0 8.1875 0 8C0 7.8125 0.03125 7.625 0.09375 7.4375C0.96875 5.5 2.1875 3.94792 3.75 2.78125C5.3125 1.61458 7.0625 1.02083 9 1C10.9375 1.02083 12.6875 1.61458 14.25 2.78125C15.8125 3.94792 17.0312 5.5 17.9062 7.4375ZM9 13.5C10.5833 13.4792 12.0312 12.9896 13.3438 12.0312C14.6354 11.0521 15.6875 9.69792 16.5 7.96875C15.7083 6.28125 14.6562 4.94792 13.3438 3.96875C12.0312 3.01042 10.5833 2.52083 9 2.5C7.41667 2.52083 5.96875 3.01042 4.65625 3.96875C3.34375 4.94792 2.29167 6.30208 1.5 8.03125C2.29167 9.71875 3.34375 11.0521 4.65625 12.0312C5.96875 12.9896 7.41667 13.4792 9 13.5ZM9 4C10.125 4.02083 11.0729 4.41667 11.8438 5.1875C12.5938 5.9375 12.9792 6.875 13 8C12.9792 9.125 12.5833 10.0729 11.8125 10.8438C11.0625 11.5938 10.125 11.9792 9 12C7.875 11.9792 6.92708 11.5938 6.15625 10.8438C5.40625 10.0729 5.02083 9.125 5 8C5.02083 6.875 5.40625 5.92708 6.15625 5.15625C6.92708 4.40625 7.875 4.02083 9 4ZM9 10.5C9.70833 10.4792 10.3021 10.2396 10.7812 9.78125C11.2396 9.30208 11.4792 8.70833 11.5 8C11.4792 7.29167 11.2396 6.69792 10.7812 6.21875C10.3021 5.76042 9.70833 5.52083 9 5.5C8.97917 5.5 8.96875 5.5 8.96875 5.5C8.94792 5.5 8.9375 5.5 8.9375 5.5C8.97917 5.66667 9 5.83333 9 6C8.97917 6.5625 8.78125 7.03125 8.40625 7.40625C8.03125 7.78125 7.5625 7.97917 7 8C6.83333 8 6.66667 7.97917 6.5 7.9375C6.5 7.9375 6.5 7.94792 6.5 7.96875C6.5 7.96875 6.5 7.97917 6.5 8C6.52083 8.70833 6.76042 9.30208 7.21875 9.78125C7.69792 10.2396 8.29167 10.4792 9 10.5Z"
      />
    </symbol>`,
  "icon-location-dot": `<symbol id="icon-location-dot" viewBox="0 0 16 16">
      <path
        
        d="M8 0C9.70833 0.0416667 11.125 0.625 12.25 1.75C13.375 2.875 13.9583 4.29167 14 6C14 6.64583 13.9167 7.22917 13.75 7.75C13.5833 8.29167 13.2604 8.92708 12.7812 9.65625C12.3021 10.4062 11.6146 11.4062 10.7188 12.6562C10.1354 13.4896 9.4375 14.5 8.625 15.6875C8.45833 15.8958 8.25 16 8 16C7.75 16 7.54167 15.8958 7.375 15.6875C6.58333 14.5208 5.88542 13.5208 5.28125 12.6875C4.38542 11.4167 3.69792 10.4062 3.21875 9.65625C2.73958 8.92708 2.41667 8.29167 2.25 7.75C2.08333 7.22917 2 6.64583 2 6C2.04167 4.29167 2.625 2.875 3.75 1.75C4.875 0.625 6.29167 0.0416667 8 0ZM8 13.9375C8.16667 13.6875 8.33333 13.4479 8.5 13.2188C8.85417 12.6979 9.17708 12.2292 9.46875 11.8125C10.3646 10.5417 11.0312 9.57292 11.4688 8.90625C11.9062 8.23958 12.1875 7.70833 12.3125 7.3125C12.4583 6.89583 12.5208 6.45833 12.5 6C12.4583 4.72917 12.0208 3.66667 11.1875 2.8125C10.3333 1.97917 9.27083 1.54167 8 1.5C6.72917 1.54167 5.66667 1.97917 4.8125 2.8125C3.97917 3.66667 3.54167 4.72917 3.5 6C3.47917 6.45833 3.54167 6.89583 3.6875 7.3125C3.8125 7.70833 4.09375 8.23958 4.53125 8.90625C4.96875 9.57292 5.63542 10.5417 6.53125 11.8125C6.96875 12.4375 7.45833 13.1458 8 13.9375ZM8 3.46875C8.70833 3.48958 9.30208 3.73958 9.78125 4.21875C10.2396 4.67708 10.4792 5.26042 10.5 5.96875C10.4792 6.67708 10.2396 7.27083 9.78125 7.75C9.30208 8.20833 8.70833 8.44792 8 8.46875C7.29167 8.44792 6.69792 8.20833 6.21875 7.75C5.76042 7.27083 5.52083 6.67708 5.5 5.96875C5.52083 5.26042 5.76042 4.67708 6.21875 4.21875C6.69792 3.73958 7.29167 3.48958 8 3.46875ZM8 7C8.29167 7 8.53125 6.90625 8.71875 6.71875C8.90625 6.53125 9 6.29167 9 6C9 5.70833 8.90625 5.46875 8.71875 5.28125C8.53125 5.09375 8.29167 5 8 5C7.70833 5 7.46875 5.09375 7.28125 5.28125C7.09375 5.46875 7 5.70833 7 6C7 6.29167 7.09375 6.53125 7.28125 6.71875C7.46875 6.90625 7.70833 7 8 7Z"
      />
    </symbol>`,
  "icon-lock-keyhole": `<symbol id="icon-lock-keyhole" viewBox="0 0 16 16">
      <path
        
        d="M13 6C13.5625 6.02083 14.0312 6.21875 14.4062 6.59375C14.7812 6.96875 14.9792 7.4375 15 8V13.9688C14.9792 14.5312 14.7812 15 14.4062 15.375C14.0312 15.75 13.5625 15.9479 13 15.9688H3C2.4375 15.9479 1.96875 15.75 1.59375 15.375C1.21875 15 1.02083 14.5312 1 13.9688V8C1.02083 7.4375 1.21875 6.96875 1.59375 6.59375C1.96875 6.21875 2.4375 6.02083 3 6H4V3.96875C4.02083 2.84375 4.41667 1.90625 5.1875 1.15625C5.9375 0.40625 6.875 0.0208333 8 0C9.125 0.0208333 10.0625 0.40625 10.8125 1.15625C11.5833 1.90625 11.9792 2.84375 12 3.96875V6H13ZM5.5 4V6H10.5V4C10.4792 3.29167 10.2396 2.69792 9.78125 2.21875C9.30208 1.76042 8.70833 1.52083 8 1.5C7.29167 1.52083 6.69792 1.76042 6.21875 2.21875C5.76042 2.69792 5.52083 3.29167 5.5 4ZM13.5 14V8C13.4792 7.6875 13.3125 7.52083 13 7.5H3C2.6875 7.52083 2.52083 7.6875 2.5 8V14C2.52083 14.3125 2.6875 14.4792 3 14.5H13C13.3125 14.4792 13.4792 14.3125 13.5 14ZM8 9.5C8.45833 9.54167 8.70833 9.79167 8.75 10.25V11.75C8.70833 12.2083 8.45833 12.4479 8 12.4688C7.54167 12.4271 7.29167 12.1875 7.25 11.75V10.25C7.29167 9.79167 7.54167 9.54167 8 9.5Z"
      />
    </symbol>`,
  "icon-lock-keyhole-open": `<symbol id="icon-lock-keyhole-open" viewBox="0 0 18 16">
      <path
        
        d="M13.5 0C14.625 0.0208333 15.5625 0.416667 16.3125 1.1875C17.0833 1.9375 17.4792 2.875 17.5 4V6.25C17.4583 6.70833 17.2083 6.95833 16.75 7C16.2917 6.95833 16.0417 6.70833 16 6.25V4C15.9792 3.29167 15.7396 2.69792 15.2812 2.21875C14.8021 1.76042 14.2083 1.52083 13.5 1.5C12.7917 1.52083 12.1979 1.76042 11.7188 2.21875C11.2604 2.69792 11.0208 3.29167 11 4V6H12C12.5625 6.02083 13.0312 6.21875 13.4062 6.59375C13.7812 6.96875 13.9792 7.4375 14 8V14C13.9792 14.5625 13.7812 15.0312 13.4062 15.4062C13.0312 15.7812 12.5625 15.9792 12 16H2C1.4375 15.9792 0.96875 15.7812 0.59375 15.4062C0.21875 15.0312 0.0208333 14.5625 0 14V8C0.0208333 7.4375 0.21875 6.96875 0.59375 6.59375C0.96875 6.21875 1.4375 6.02083 2 6H9.5V4C9.52083 2.875 9.91667 1.9375 10.6875 1.1875C11.4375 0.416667 12.375 0.0208333 13.5 0ZM12 7.5H2C1.6875 7.52083 1.52083 7.6875 1.5 8V14C1.52083 14.3125 1.6875 14.4792 2 14.5H12C12.3125 14.4792 12.4792 14.3125 12.5 14V8C12.4792 7.6875 12.3125 7.52083 12 7.5ZM7 12.5C6.54167 12.4583 6.29167 12.2083 6.25 11.75V10.25C6.29167 9.79167 6.54167 9.54167 7 9.5C7.45833 9.54167 7.70833 9.79167 7.75 10.25V11.75C7.70833 12.2083 7.45833 12.4583 7 12.5Z"
      />
    </symbol>`,
  "icon-calendar": `<symbol id="icon-calendar" viewBox="0 0 16 16">
      <path
        
        d="M5.75 2H10.25V0.75C10.2917 0.291667 10.5417 0.0416667 11 0C11.4583 0.0416667 11.7083 0.291667 11.75 0.75V2H13C13.5625 2.02083 14.0312 2.21875 14.4062 2.59375C14.7812 2.96875 14.9792 3.4375 15 4V14C14.9792 14.5625 14.7812 15.0312 14.4062 15.4062C14.0312 15.7812 13.5625 15.9792 13 16H3C2.4375 15.9792 1.96875 15.7812 1.59375 15.4062C1.21875 15.0312 1.02083 14.5625 1 14V4C1.02083 3.4375 1.21875 2.96875 1.59375 2.59375C1.96875 2.21875 2.4375 2.02083 3 2H4.25V0.75C4.29167 0.291667 4.54167 0.0416667 5 0C5.45833 0.0416667 5.70833 0.291667 5.75 0.75V2ZM2.5 14C2.52083 14.3125 2.6875 14.4792 3 14.5H13C13.3125 14.4792 13.4792 14.3125 13.5 14V6H2.5V14Z"
      />
    </symbol>`,
  "icon-expand-arrows": `<symbol id="icon-expand-arrows" viewBox="0 0 16 16">
      <path
        
        d="M15.5312 0.0625C15.7188 0.145833 15.8542 0.28125 15.9375 0.46875C15.9792 0.552083 16 0.645833 16 0.75V5.21875C15.9583 5.69792 15.7083 5.95833 15.25 6C14.7917 5.95833 14.5417 5.70833 14.5 5.25V2.5625L10.2812 6.78125C9.92708 7.07292 9.57292 7.07292 9.21875 6.78125C8.92708 6.42708 8.92708 6.07292 9.21875 5.71875L13.4375 1.5H10.75C10.2917 1.45833 10.0417 1.20833 10 0.75C10.0417 0.291667 10.3021 0.0416667 10.7812 0H15.25C15.3542 0 15.4479 0.0208333 15.5312 0.0625ZM0.46875 15.9375C0.28125 15.8542 0.145833 15.7188 0.0625 15.5312C0.0208333 15.4479 0 15.3542 0 15.25V10.75C0.0416667 10.2917 0.291667 10.0417 0.75 10C1.20833 10.0417 1.45833 10.2917 1.5 10.75V13.4375L5.71875 9.21875C6.07292 8.92708 6.42708 8.92708 6.78125 9.21875C7.07292 9.57292 7.07292 9.92708 6.78125 10.2812L2.5625 14.5H5.25C5.70833 14.5417 5.95833 14.7917 6 15.25C5.95833 15.7083 5.69792 15.9583 5.21875 16H0.75C0.645833 16 0.552083 15.9792 0.46875 15.9375Z"
      />
    </symbol>`,
  "icon-collapse-arrows": `<symbol id="icon-collapse-arrows" viewBox="0 0 16 16">
      <path
        
        d="M8.96875 7.4375C8.76042 7.35417 8.625 7.21875 8.5625 7.03125C8.52083 6.94792 8.5 6.85417 8.5 6.75V2.25C8.54167 1.79167 8.79167 1.54167 9.25 1.5C9.70833 1.54167 9.95833 1.79167 10 2.25V4.9375L14.2188 0.71875C14.5729 0.427083 14.9271 0.427083 15.2812 0.71875C15.5729 1.07292 15.5729 1.42708 15.2812 1.78125L11.0625 6H13.75C14.2083 6.04167 14.4583 6.29167 14.5 6.75C14.4583 7.20833 14.2083 7.45833 13.75 7.5H9.25C9.14583 7.5 9.05208 7.47917 8.96875 7.4375ZM7.03125 8.5625C7.21875 8.625 7.35417 8.76042 7.4375 8.96875C7.47917 9.05208 7.5 9.14583 7.5 9.25V13.75C7.45833 14.2083 7.20833 14.4583 6.75 14.5C6.29167 14.4583 6.04167 14.2083 6 13.75V11.0625L1.78125 15.2812C1.42708 15.5729 1.07292 15.5729 0.71875 15.2812C0.427083 14.9271 0.427083 14.5729 0.71875 14.2188L4.9375 10H2.25C1.79167 9.95833 1.54167 9.70833 1.5 9.25C1.54167 8.79167 1.79167 8.54167 2.25 8.5H6.75C6.85417 8.5 6.94792 8.52083 7.03125 8.5625Z"
      />
    </symbol>`,
  "icon-arrow-down-a-z": `<symbol id="icon-arrow-down-a-z" viewBox="0 0 16 16">
      <path
        
        d="M14.4699 13.5C14.9282 13.5417 15.1574 13.7917 15.1574 14.25C15.1365 14.7083 14.8969 14.9583 14.4386 15H10.9699C10.699 14.9792 10.4803 14.8438 10.3136 14.5938C10.2094 14.3021 10.2407 14.0312 10.4074 13.7812L12.9699 10.5H11.0011C10.5636 10.4583 10.324 10.2083 10.2824 9.75C10.324 9.29167 10.5636 9.04167 11.0011 9H14.4699C14.8032 9.02083 15.0428 9.15625 15.1886 9.40625C15.3136 9.69792 15.2824 9.96875 15.0949 10.2188L12.5324 13.5H14.4699ZM15.6886 5.90625C15.8344 6.34375 15.7199 6.67708 15.3449 6.90625C15.2199 6.96875 15.1053 7 15.0011 7C14.7094 7 14.4803 6.86458 14.3136 6.59375L14.1574 6.25H11.3449L11.2199 6.59375C10.9907 6.96875 10.6574 7.07292 10.2199 6.90625C9.82403 6.67708 9.70945 6.34375 9.87612 5.90625L12.0949 1.40625C12.2615 1.15625 12.4907 1.03125 12.7824 1.03125C13.074 1.03125 13.2928 1.15625 13.4386 1.40625L15.6886 5.90625ZM12.0949 4.75H13.4074L12.7511 3.4375L12.0949 4.75ZM7.18862 10.4688C7.33445 10.3229 7.51153 10.25 7.71987 10.25C7.90737 10.25 8.06362 10.3229 8.18862 10.4688C8.50112 10.8021 8.52195 11.1562 8.25112 11.5312L5.28237 14.7812C5.1157 14.9271 4.9282 15 4.71987 15C4.51153 15 4.32403 14.9271 4.15737 14.7812L1.18862 11.5312C0.917783 11.1562 0.938616 10.8021 1.25112 10.4688C1.39695 10.3229 1.56362 10.25 1.75112 10.25C1.95945 10.25 2.14695 10.3333 2.31362 10.5L4.00112 12.3438V1.75C4.04278 1.29167 4.29278 1.04167 4.75112 1C5.20945 1.04167 5.45945 1.29167 5.50112 1.75V12.3438L7.18862 10.4688Z"
      />
    </symbol>`,
  "icon-arrow-up-arrow-down": `<symbol id="icon-arrow-up-arrow-down" viewBox="0 0 16 16">
      <path
        
        d="M8.25112 5.53125C7.89695 5.82292 7.54278 5.8125 7.18862 5.5L5.50112 3.65625V14.25C5.45945 14.7083 5.20945 14.9583 4.75112 15C4.29278 14.9583 4.04278 14.7083 4.00112 14.25V3.65625L2.31362 5.5C2.14695 5.66667 1.95945 5.75 1.75112 5.75C1.56362 5.75 1.39695 5.67708 1.25112 5.53125C0.938616 5.19792 0.917783 4.84375 1.18862 4.46875L4.18862 1.21875C4.35528 1.07292 4.54278 1 4.75112 1C4.95945 1 5.14695 1.07292 5.31362 1.21875L8.31362 4.46875C8.58445 4.84375 8.56362 5.19792 8.25112 5.53125ZM14.2511 10.4688C14.5636 10.8021 14.5636 11.1562 14.2511 11.5312L11.2824 14.7812C11.1157 14.9271 10.9282 15 10.7199 15C10.5115 15 10.324 14.9271 10.1574 14.7812L7.18862 11.5312C6.91778 11.1562 6.93862 10.8021 7.25112 10.4688C7.39695 10.3229 7.56362 10.25 7.75112 10.25C7.95945 10.25 8.14695 10.3333 8.31362 10.5L10.0011 12.3438V1.75C10.0428 1.29167 10.2928 1.04167 10.7511 1C11.2094 1.04167 11.4594 1.29167 11.5011 1.75V12.3438L13.1886 10.5C13.5428 10.1875 13.8969 10.1771 14.2511 10.4688Z"
      />
    </symbol>`,
  "icon-arrow-right-from-bracket": `<symbol id="icon-arrow-right-from-bracket" viewBox="0 0 16 16">
      <path
        
        d="M6 14.25C5.95833 13.7917 5.70833 13.5417 5.25 13.5H3C2.58333 13.4792 2.22917 13.3333 1.9375 13.0625C1.66667 12.7708 1.52083 12.4167 1.5 12V4C1.52083 3.58333 1.66667 3.22917 1.9375 2.9375C2.22917 2.66667 2.58333 2.52083 3 2.5H5.25C5.70833 2.45833 5.95833 2.20833 6 1.75C5.95833 1.29167 5.70833 1.04167 5.25 1H3C2.14583 1.02083 1.4375 1.3125 0.875 1.875C0.3125 2.4375 0.0208333 3.14583 0 4V12C0.0208333 12.8542 0.3125 13.5625 0.875 14.125C1.4375 14.6875 2.14583 14.9792 3 15H5.25C5.70833 14.9583 5.95833 14.7083 6 14.25ZM15.8125 7.5C16.0833 7.83333 16.0625 8.16667 15.75 8.5L11.7812 12.75C11.6146 12.9167 11.4271 13 11.2188 13C11.0521 13 10.8854 12.9271 10.7188 12.7812C10.4062 12.4479 10.3958 12.1042 10.6875 11.75L13.5 8.75H5.71875C5.28125 8.70833 5.04167 8.45833 5 8C5.04167 7.54167 5.28125 7.29167 5.71875 7.25H13.5L10.7188 4.25C10.4479 3.89583 10.4583 3.55208 10.75 3.21875C11.125 2.92708 11.4792 2.9375 11.8125 3.25L15.8125 7.5Z"
      />
    </symbol>`,
  "icon-arrow-down-z-a": `<symbol id="icon-arrow-down-z-a" viewBox="0 0 16 16">
      <path
        
        d="M10.9699 2.5C10.5532 2.45833 10.324 2.20833 10.2824 1.75C10.324 1.29167 10.5636 1.04167 11.0011 1H14.4699C14.8032 1.02083 15.0428 1.15625 15.1886 1.40625C15.3136 1.69792 15.2824 1.96875 15.0949 2.21875L12.5324 5.5H14.4699C14.9074 5.54167 15.1469 5.79167 15.1886 6.25C15.1678 6.70833 14.9282 6.95833 14.4699 7H11.0011C10.6886 6.97917 10.4594 6.83333 10.3136 6.5625C10.2094 6.29167 10.2407 6.03125 10.4074 5.78125L12.9386 2.5H10.9699ZM15.6886 13.9062C15.8344 14.3438 15.7407 14.6771 15.4074 14.9062C15.2824 14.9688 15.1678 15 15.0636 15C14.7719 15 14.5428 14.8646 14.3761 14.5938L14.2199 14.25H11.4074L11.2199 14.5938C10.9907 14.9688 10.6574 15.0729 10.2199 14.9062C9.82403 14.6771 9.70945 14.3438 9.87612 13.9062L12.0949 9.40625C12.2615 9.15625 12.4907 9.03125 12.7824 9.03125C13.074 9.03125 13.2928 9.15625 13.4386 9.40625L15.6886 13.9062ZM12.0949 12.7188H13.4074L12.7511 11.4062L12.0949 12.7188ZM7.18862 10.4688C7.33445 10.3229 7.51153 10.25 7.71987 10.25C7.90737 10.25 8.06362 10.3229 8.18862 10.4688C8.50112 10.8021 8.52195 11.1562 8.25112 11.5312L5.28237 14.7812C5.1157 14.9271 4.9282 15 4.71987 15C4.51153 15 4.32403 14.9271 4.15737 14.7812L1.18862 11.5312C0.917783 11.1562 0.938616 10.8021 1.25112 10.4688C1.39695 10.3229 1.56362 10.25 1.75112 10.25C1.95945 10.25 2.14695 10.3333 2.31362 10.5L4.00112 12.3438V1.75C4.04278 1.29167 4.29278 1.04167 4.75112 1C5.20945 1.04167 5.45945 1.29167 5.50112 1.75V12.3438L7.18862 10.4688Z"
      />
    </symbol>`,
  "icon-arrow-up-a-z": `<symbol id="icon-arrow-up-a-z" viewBox="0 0 512 512">
      <path
        d="M478.3 456.8l-79.99-159.1c-5.438-10.81-23.19-10.81-28.62 0l-79.99 159.1c-3.953 7.902-.75 17.5 7.156 21.46c7.906 4 17.51 .7187 21.47-7.152l11.58-23.15h108.2l11.58 23.15c3.094 6.152 12.08 11.88 21.47 7.152C479.1 474.3 482.3 464.7 478.3 456.8zM345.9 415.9L384 339.7l38.11 76.21H345.9zM320 63.1h94.7l-107.2 133.1c-3.842 4.812-4.576 11.38-1.92 16.94c2.67 5.531 8.261 9.078 14.42 9.078h127.1c8.844 0 15.1-7.172 15.1-16.02s-7.154-16-15.1-16h-94.7l107.2-133.1c3.842-4.812 4.576-11.37 1.92-16.93C459.7 35.53 454.2 32 447.1 32h-127.1c-8.844 0-15.1 7.156-15.1 16C304 56.84 311.2 63.1 320 63.1zM139.3 36.69c-6.25-6.25-16.38-6.25-22.62 0l-96 96c-6.25 6.25-6.25 16.38 0 22.62s16.38 6.25 22.62 0L112 86.63V464c0 8.844 7.157 16 16 16S144 472.8 144 464V86.63l68.69 68.69C215.8 158.4 219.9 160 224 160s8.188-1.562 11.31-4.688c6.25-6.25 6.25-16.38 0-22.62L139.3 36.69z"
      />
    </symbol>`,
  "icon-arrow-down-1-9": `<symbol id="icon-arrow-down-1-9" viewBox="0 0 16 16">
      <path
        
        d="M11.7511 5.49279H12.2511V3.05529L12.1261 3.14904C11.7094 3.33654 11.3657 3.24279 11.0949 2.86779C10.9074 2.47196 11.0011 2.13862 11.3761 1.86779L12.6261 1.11779C12.8761 0.971955 13.1261 0.961538 13.3761 1.08654C13.6261 1.23237 13.7511 1.45112 13.7511 1.74279V5.49279H14.2511C14.7094 5.53445 14.9594 5.78445 15.0011 6.24279C14.9594 6.70112 14.7094 6.95112 14.2511 6.99279H11.7199C11.2824 6.95112 11.0428 6.70112 11.0011 6.24279C11.0428 5.78445 11.2928 5.53445 11.7511 5.49279ZM13.0011 8.02404C13.7719 8.04487 14.4178 8.3157 14.9386 8.83654C15.4594 9.35737 15.7303 10.0032 15.7511 10.774C15.7719 11.2324 15.6678 11.649 15.4386 12.024C15.2094 12.399 14.7615 12.972 14.0949 13.7428C13.8032 14.097 13.4699 14.5136 13.0949 14.9928C12.9282 15.1803 12.7303 15.274 12.5011 15.274C12.3344 15.274 12.1782 15.222 12.0324 15.1178C11.699 14.7845 11.6574 14.4303 11.9074 14.0553L12.4074 13.4615C11.7824 13.3157 11.2719 12.9928 10.8761 12.4928C10.4803 12.0136 10.2719 11.4407 10.2511 10.774C10.2719 10.0032 10.5428 9.35737 11.0636 8.83654C11.5844 8.3157 12.2303 8.04487 13.0011 8.02404ZM13.9074 11.6178C14.1365 11.3886 14.2511 11.1074 14.2511 10.774C14.2511 10.4199 14.1261 10.1282 13.8761 9.89904C13.6469 9.64904 13.3553 9.52404 13.0011 9.52404C12.6469 9.52404 12.3553 9.64904 12.1261 9.89904C11.8761 10.1282 11.7511 10.4199 11.7511 10.774C11.7511 11.1282 11.8761 11.4199 12.1261 11.649C12.3553 11.899 12.6469 12.024 13.0011 12.024C13.3553 12.024 13.6469 11.9095 13.8761 11.6803L13.9074 11.6178ZM7.18862 10.4928C7.33445 10.347 7.51153 10.274 7.71987 10.274C7.90737 10.274 8.06362 10.347 8.18862 10.4928C8.50112 10.8261 8.52195 11.1803 8.25112 11.5553L5.28237 14.8053C5.1157 14.9511 4.9282 15.024 4.71987 15.024C4.51153 15.024 4.32403 14.9511 4.15737 14.8053L1.18862 11.5553C0.917783 11.1803 0.938616 10.8261 1.25112 10.4928C1.39695 10.347 1.56362 10.274 1.75112 10.274C1.95945 10.274 2.14695 10.3574 2.31362 10.524L4.00112 12.3678V1.77404C4.04278 1.31571 4.29278 1.06571 4.75112 1.02404C5.20945 1.06571 5.45945 1.31571 5.50112 1.77404V12.3678L7.18862 10.4928Z"
      />
    </symbol>`,
  "icon-arrow-down-9-1": `<symbol id="icon-arrow-down-9-1" viewBox="0 0 16 16">
      <path
        
        d="M7.18862 10.4688C7.33445 10.3229 7.51153 10.25 7.71987 10.25C7.90737 10.25 8.06362 10.3229 8.18862 10.4688C8.50112 10.8021 8.52195 11.1562 8.25112 11.5312L5.28237 14.7812C5.1157 14.9271 4.9282 15 4.71987 15C4.51153 15 4.32403 14.9271 4.15737 14.7812L1.18862 11.5312C0.917783 11.1562 0.938616 10.8021 1.25112 10.4688C1.39695 10.3229 1.56362 10.25 1.75112 10.25C1.95945 10.25 2.14695 10.3333 2.31362 10.5L4.00112 12.3438V1.75C4.04278 1.29167 4.29278 1.04167 4.75112 1C5.20945 1.04167 5.45945 1.29167 5.50112 1.75V12.3438L7.18862 10.4688ZM14.2511 13.5C14.7094 13.5417 14.9594 13.7917 15.0011 14.25C14.9594 14.7083 14.7094 14.9583 14.2511 15H11.7511C11.2928 14.9583 11.0428 14.7083 11.0011 14.25C11.0428 13.7917 11.2928 13.5417 11.7511 13.5H12.2511V11.0625L12.1261 11.1562C11.7094 11.3438 11.3657 11.25 11.0949 10.875C10.9074 10.4583 11.0011 10.1146 11.3761 9.84375L12.6261 9.09375C12.8761 8.96875 13.1261 8.96875 13.3761 9.09375C13.6261 9.23958 13.7511 9.45833 13.7511 9.75V13.5H14.2511ZM12.3761 6.4375C11.7511 6.29167 11.2407 5.96875 10.8449 5.46875C10.449 4.98958 10.2511 4.41667 10.2511 3.75C10.2719 2.97917 10.5428 2.33333 11.0636 1.8125C11.5844 1.29167 12.2303 1.02083 13.0011 1C13.7719 1.02083 14.4178 1.29167 14.9386 1.8125C15.4594 2.33333 15.7303 2.97917 15.7511 3.75C15.7719 4.20833 15.6678 4.625 15.4386 5C15.2094 5.375 14.7615 5.94792 14.0949 6.71875C13.8032 7.07292 13.4699 7.48958 13.0949 7.96875C12.9282 8.15625 12.7303 8.25 12.5011 8.25C12.3344 8.25 12.1678 8.19792 12.0011 8.09375C11.6678 7.76042 11.6365 7.40625 11.9074 7.03125L12.3761 6.4375ZM13.0011 2.5C12.6469 2.5 12.3553 2.625 12.1261 2.875C11.8761 3.10417 11.7511 3.39583 11.7511 3.75C11.7511 4.10417 11.8761 4.39583 12.1261 4.625C12.3553 4.875 12.6469 5 13.0011 5C13.3553 5 13.6469 4.88542 13.8761 4.65625L13.9074 4.59375C14.1365 4.36458 14.2511 4.08333 14.2511 3.75C14.2511 3.39583 14.1261 3.10417 13.8761 2.875C13.6469 2.625 13.3553 2.5 13.0011 2.5Z"
      />
    </symbol>`,
  "icon-arrow-turn-down-left": `<symbol id="icon-arrow-turn-down-left" viewBox="0 0 16 16">
      <path
        
        d="M4.21875 14.5L0.21875 10.5C0.0729167 10.375 0 10.2083 0 10C0 9.79167 0.0729167 9.61458 0.21875 9.46875L4.21875 5.46875C4.57292 5.17708 4.92708 5.17708 5.28125 5.46875C5.57292 5.82292 5.57292 6.17708 5.28125 6.53125L2.5625 9.25H14.5V2.75C14.5417 2.29167 14.7917 2.04167 15.25 2C15.7083 2.04167 15.9583 2.29167 16 2.75V10C15.9583 10.4583 15.7083 10.7083 15.25 10.75H2.5625L5.28125 13.4688C5.57292 13.8229 5.57292 14.1771 5.28125 14.5312C4.92708 14.8229 4.57292 14.8125 4.21875 14.5Z"
      />
    </symbol>`,
  "icon-circle-info": `<symbol id="icon-circle-info" viewBox="0 0 16 16">
      <path
        
        d="M8 0C9.5 0.0208333 10.8438 0.385417 12.0312 1.09375C13.2396 1.80208 14.1979 2.76042 14.9062 3.96875C15.6146 5.15625 15.9792 6.5 16 8C15.9792 9.5 15.6146 10.8438 14.9062 12.0312C14.1979 13.2396 13.2396 14.1979 12.0312 14.9062C10.8438 15.6146 9.5 15.9792 8 16C6.5 15.9792 5.15625 15.6146 3.96875 14.9062C2.76042 14.1979 1.80208 13.2396 1.09375 12.0312C0.385417 10.8438 0.0208333 9.5 0 8C0.0208333 6.5 0.385417 5.15625 1.09375 3.96875C1.80208 2.76042 2.76042 1.80208 3.96875 1.09375C5.15625 0.385417 6.5 0.0208333 8 0ZM8 14.5C9.83333 14.4583 11.3646 13.8229 12.5938 12.5938C13.8229 11.3646 14.4583 9.83333 14.5 8C14.4583 6.16667 13.8229 4.63542 12.5938 3.40625C11.3646 2.17708 9.83333 1.54167 8 1.5C6.16667 1.54167 4.63542 2.17708 3.40625 3.40625C2.17708 4.63542 1.54167 6.16667 1.5 8C1.54167 9.83333 2.17708 11.3646 3.40625 12.5938C4.63542 13.8229 6.16667 14.4583 8 14.5ZM9.25 10.5C9.70833 10.5417 9.95833 10.7917 10 11.25C9.95833 11.7083 9.70833 11.9583 9.25 12H6.75C6.29167 11.9583 6.04167 11.7083 6 11.25C6.04167 10.7917 6.29167 10.5417 6.75 10.5H7.25V8.5H7C6.54167 8.45833 6.29167 8.20833 6.25 7.75C6.29167 7.29167 6.54167 7.04167 7 7H8C8.45833 7.04167 8.70833 7.29167 8.75 7.75V10.5H9.25ZM8 6C7.70833 6 7.46875 5.90625 7.28125 5.71875C7.09375 5.53125 7 5.29167 7 5C7 4.70833 7.09375 4.46875 7.28125 4.28125C7.46875 4.09375 7.70833 4 8 4C8.29167 4 8.53125 4.09375 8.71875 4.28125C8.90625 4.46875 9 4.70833 9 5C9 5.29167 8.90625 5.53125 8.71875 5.71875C8.53125 5.90625 8.29167 6 8 6Z"
      />
    </symbol>`,
  "icon-circle-user": `<symbol id="icon-circle-user" viewBox="0 0 16 16">
      <path
        
        d="M8 3.5C8.77083 3.52083 9.41667 3.79167 9.9375 4.3125C10.4583 4.83333 10.7292 5.47917 10.75 6.25C10.7292 7.02083 10.4583 7.66667 9.9375 8.1875C9.41667 8.70833 8.77083 8.97917 8 9C7.22917 8.97917 6.58333 8.70833 6.0625 8.1875C5.54167 7.66667 5.27083 7.02083 5.25 6.25C5.27083 5.47917 5.54167 4.83333 6.0625 4.3125C6.58333 3.79167 7.22917 3.52083 8 3.5ZM8 7.5C8.35417 7.5 8.64583 7.375 8.875 7.125C9.125 6.89583 9.25 6.60417 9.25 6.25C9.25 5.89583 9.125 5.60417 8.875 5.375C8.64583 5.125 8.35417 5 8 5C7.64583 5 7.35417 5.125 7.125 5.375C6.875 5.60417 6.75 5.89583 6.75 6.25C6.75 6.60417 6.875 6.89583 7.125 7.125C7.35417 7.375 7.64583 7.5 8 7.5ZM8 0C9.5 0.0208333 10.8438 0.385417 12.0312 1.09375C13.2396 1.80208 14.1979 2.76042 14.9062 3.96875C15.6146 5.15625 15.9792 6.5 16 8C15.9792 9.5 15.6146 10.8438 14.9062 12.0312C14.1979 13.2396 13.2396 14.1979 12.0312 14.9062C10.8438 15.6146 9.5 15.9792 8 16C6.5 15.9792 5.15625 15.6146 3.96875 14.9062C2.76042 14.1979 1.80208 13.2396 1.09375 12.0312C0.385417 10.8438 0.0208333 9.5 0 8C0.0208333 6.5 0.385417 5.15625 1.09375 3.96875C1.80208 2.76042 2.76042 1.80208 3.96875 1.09375C5.15625 0.385417 6.5 0.0208333 8 0ZM8 14.5C9.47917 14.4792 10.7812 14.0417 11.9062 13.1875C11.6146 12.6667 11.2292 12.2604 10.75 11.9688C10.2708 11.6562 9.72917 11.5 9.125 11.5H6.875C6.27083 11.5 5.72917 11.6562 5.25 11.9688C4.77083 12.2604 4.39583 12.6667 4.125 13.1875C5.22917 14.0417 6.52083 14.4792 8 14.5ZM13 12.1562C13.9583 10.9896 14.4583 9.60417 14.5 8C14.4583 6.16667 13.8229 4.63542 12.5938 3.40625C11.3646 2.17708 9.83333 1.54167 8 1.5C6.16667 1.54167 4.63542 2.17708 3.40625 3.40625C2.17708 4.63542 1.54167 6.16667 1.5 8C1.54167 9.60417 2.04167 10.9792 3 12.125C3.4375 11.4583 3.98958 10.9375 4.65625 10.5625C5.32292 10.1875 6.0625 10 6.875 10H9.125C9.9375 10 10.6771 10.1875 11.3438 10.5625C12.0312 10.9583 12.5833 11.4896 13 12.1562Z"
      />
    </symbol>`,
  "icon-circle-check": `<symbol id="icon-circle-check" viewBox="0 0 16 16">
      <path
        
        d="M10.4688 5.46875C10.8229 5.17708 11.1771 5.17708 11.5312 5.46875C11.8229 5.82292 11.8229 6.17708 11.5312 6.53125L7.53125 10.5312C7.38542 10.6771 7.20833 10.75 7 10.75C6.8125 10.75 6.625 10.6771 6.4375 10.5312L4.4375 8.53125C4.14583 8.17708 4.14583 7.82292 4.4375 7.46875C4.79167 7.17708 5.14583 7.17708 5.5 7.46875L7 8.9375L10.4688 5.46875ZM8 0C9.5 0.0208333 10.8438 0.385417 12.0312 1.09375C13.2396 1.80208 14.1979 2.76042 14.9062 3.96875C15.6146 5.15625 15.9792 6.5 16 8C15.9792 9.5 15.6146 10.8438 14.9062 12.0312C14.1979 13.2396 13.2396 14.1979 12.0312 14.9062C10.8438 15.6146 9.5 15.9792 8 16C6.5 15.9792 5.15625 15.6146 3.96875 14.9062C2.76042 14.1979 1.80208 13.2396 1.09375 12.0312C0.385417 10.8438 0.0208333 9.5 0 8C0.0208333 6.5 0.385417 5.15625 1.09375 3.96875C1.80208 2.76042 2.76042 1.80208 3.96875 1.09375C5.15625 0.385417 6.5 0.0208333 8 0ZM8 14.5C9.83333 14.4583 11.3646 13.8229 12.5938 12.5938C13.8229 11.3646 14.4583 9.83333 14.5 8C14.4583 6.16667 13.8229 4.63542 12.5938 3.40625C11.3646 2.17708 9.83333 1.54167 8 1.5C6.16667 1.54167 4.63542 2.17708 3.40625 3.40625C2.17708 4.63542 1.54167 6.16667 1.5 8C1.54167 9.83333 2.17708 11.3646 3.40625 12.5938C4.63542 13.8229 6.16667 14.4583 8 14.5Z"
      />
    </symbol>`,
  "icon-expand-wide": `<symbol id="icon-expand-wide" viewBox="0 0 16 16">
      <path
        
        d="M4.25 12.5C4.70833 12.5417 4.95833 12.7917 5 13.25C4.95833 13.7083 4.70833 13.9583 4.25 14H0.75C0.291667 13.9583 0.0416667 13.7083 0 13.25V9.75C0.0416667 9.29167 0.291667 9.04167 0.75 9C1.20833 9.04167 1.45833 9.29167 1.5 9.75V12.5H4.25ZM4.25 2C4.70833 2.04167 4.95833 2.29167 5 2.75C4.95833 3.20833 4.70833 3.45833 4.25 3.5H1.5V6.25C1.45833 6.70833 1.20833 6.95833 0.75 7C0.291667 6.95833 0.0416667 6.70833 0 6.25V2.75C0.0416667 2.29167 0.291667 2.04167 0.75 2H4.25ZM15.25 2C15.7083 2.04167 15.9583 2.29167 16 2.75V6.25C15.9583 6.70833 15.7083 6.95833 15.25 7C14.7917 6.95833 14.5417 6.70833 14.5 6.25V3.5H11.75C11.2917 3.45833 11.0417 3.20833 11 2.75C11.0417 2.29167 11.2917 2.04167 11.75 2H15.25ZM15.25 9C15.7083 9.04167 15.9583 9.29167 16 9.75V13.25C15.9583 13.7083 15.7083 13.9583 15.25 14H11.75C11.2917 13.9583 11.0417 13.7083 11 13.25C11.0417 12.7917 11.2917 12.5417 11.75 12.5H14.5V9.75C14.5417 9.29167 14.7917 9.04167 15.25 9Z"
      />
    </symbol>`,
  "icon-arrow-up-1-9": `<symbol id="icon-arrow-up-1-9" viewBox="0 0 512 512">
      <path
        d="M384 256c-44.13 0-80 35.88-80 80S339.9 416 384 416c16.73 0 32.25-5.199 45.11-14.01C421.3 428.5 396.1 448 368 448c-8.844 0-16 7.156-16 16s7.156 16 16 16c52.94 0 96-43.06 96-96v-48C464 291.9 428.1 256 384 256zM384 384c-26.47 0-48-21.53-48-48S357.5 288 384 288s48 21.53 48 48S410.5 384 384 384zM336 224l96-.0039c8.844 0 16-7.152 16-15.1S440.8 192 432 192h-32V48C400 39.16 392.8 32 384 32h-32c-8.844 0-16 7.156-16 16S343.2 64 352 64h16v128h-32C327.2 192 320 199.2 320 208S327.2 224 336 224zM139.3 36.69c-6.25-6.25-16.38-6.25-22.62 0l-96 96c-6.25 6.25-6.25 16.38 0 22.62s16.38 6.25 22.62 0L112 86.63V464c0 8.844 7.157 15.1 16 15.1S144 472.8 144 464V86.63l68.69 68.69C215.8 158.4 219.9 160 224 160s8.188-1.562 11.31-4.688c6.25-6.25 6.25-16.38 0-22.62L139.3 36.69z"
      />
    </symbol>`,
  "icon-caret-right": `<symbol id="icon-caret-right" viewBox="0 0 16 16">
      <path
        
        d="M7.21875 3.29167L11.2188 7.29167C11.4062 7.52083 11.5 7.75 11.5 7.97917C11.5 8.22917 11.4062 8.46875 11.2188 8.69792L7.21875 12.6667C6.88542 12.9583 6.52083 13.0312 6.125 12.8854C5.72917 12.7188 5.52083 12.4167 5.5 11.9792V4.01042C5.52083 3.57292 5.72917 3.26042 6.125 3.07292C6.52083 2.92708 6.88542 3 7.21875 3.29167Z"
      />
    </symbol>`,
  "icon-caret-up": `<symbol id="icon-caret-up" viewBox="0 0 16 16">
      <path
        
        d="M3.29167 9.28125L7.26042 5.28125C7.48958 5.09375 7.73958 5 8.01042 5C8.28125 5 8.52083 5.09375 8.72917 5.28125L12.6979 9.28125C12.9896 9.61458 13.0625 9.97917 12.9167 10.375C12.75 10.7708 12.4375 10.9792 11.9792 11H4.01042C3.57292 10.9792 3.26042 10.7708 3.07292 10.375C2.92708 9.97917 3 9.61458 3.29167 9.28125Z"
      />
    </symbol>`,
  "icon-caret-left": `<symbol id="icon-caret-left" viewBox="0 0 16 16">
      <path
        
        d="M8.78125 12.7292L4.78125 8.76042C4.59375 8.53125 4.5 8.27083 4.5 7.97917C4.5 7.70833 4.59375 7.46875 4.78125 7.26042L8.78125 3.29167C9.11458 3 9.47917 2.92708 9.875 3.07292C10.2708 3.26042 10.4792 3.57292 10.5 4.01042V11.9792C10.4792 12.4167 10.2708 12.7292 9.875 12.9167C9.47917 13.0625 9.11458 13 8.78125 12.7292Z"
      />
    </symbol>`,
  "icon-caret-down": `<symbol id="icon-caret-down" viewBox="0 0 16 16">
      <path
        
        d="M12.7259 7.21875L8.7571 11.2188C8.52794 11.4062 8.27794 11.5 8.0071 11.5C7.73627 11.5 7.49669 11.4062 7.28835 11.2188L3.3196 7.21875C3.0071 6.88542 2.92377 6.52083 3.0696 6.125C3.2571 5.72917 3.5696 5.52083 4.0071 5.5H11.9759C12.4134 5.52083 12.7259 5.72917 12.9134 6.125C13.0592 6.52083 12.9967 6.88542 12.7259 7.21875Z"
      />
    </symbol>`,
  "icon-previous": `<symbol id="icon-previous" viewBox="0 0 16 16">
      <path
        
        d="M13.4688 2.75C13.5104 2.29167 13.7604 2.04167 14.2188 2C14.6979 2.04167 14.9583 2.29167 15 2.75V13.25C14.9583 13.7083 14.6979 13.9583 14.2188 14C13.7604 13.9583 13.5104 13.7083 13.4688 13.25V2.75ZM6.5 11.4688C6.79167 11.8021 6.80208 12.1458 6.53125 12.5C6.19792 12.8125 5.84375 12.8229 5.46875 12.5312L1.21875 8.53125C1.07292 8.38542 1 8.20833 1 8C1 7.79167 1.07292 7.61458 1.21875 7.46875L5.46875 3.46875C5.84375 3.17708 6.19792 3.1875 6.53125 3.5C6.67708 3.64583 6.75 3.8125 6.75 4C6.75 4.20833 6.66667 4.38542 6.5 4.53125L3.625 7.25H11.25C11.7083 7.29167 11.9583 7.54167 12 8C11.9583 8.45833 11.7083 8.70833 11.25 8.75H3.625L6.5 11.4688Z"
      />
    </symbol>`,
  "icon-next": `<symbol id="icon-next" viewBox="0 0 16 16">
      <path
        
        d="M2.5 13.25C2.45833 13.7083 2.20833 13.9583 1.75 14C1.29167 13.9583 1.04167 13.7083 1 13.25V2.75C1.04167 2.29167 1.29167 2.04167 1.75 2C2.20833 2.04167 2.45833 2.29167 2.5 2.75V13.25ZM9.5 4.5625C9.1875 4.20833 9.17708 3.85417 9.46875 3.5C9.80208 3.1875 10.1562 3.17708 10.5312 3.46875L14.7812 7.46875C14.9271 7.61458 15 7.79167 15 8C15 8.20833 14.9271 8.38542 14.7812 8.53125L10.5312 12.5312C10.1562 12.8229 9.80208 12.8125 9.46875 12.5C9.32292 12.3542 9.25 12.1875 9.25 12C9.25 11.7917 9.33333 11.6146 9.5 11.4688L12.375 8.75H4.75C4.29167 8.70833 4.04167 8.45833 4 8C4.04167 7.54167 4.29167 7.29167 4.75 7.25H12.375L9.5 4.5625Z"
      />
    </symbol>`,
  "icon-last": `<symbol id="icon-last" viewBox="0 0 16 16">
      <path
        
        d="M13.4688 2.75C13.4688 2.54167 13.5417 2.36458 13.6875 2.21875C13.8333 2.07292 14.0104 2 14.2188 2C14.6979 2.04167 14.9583 2.29167 15 2.75V13.25C14.9583 13.7083 14.6979 13.9583 14.2188 14C13.7604 13.9583 13.5104 13.7083 13.4688 13.25V2.75ZM6.5 4.5625C6.16667 4.20833 6.15625 3.85417 6.46875 3.5C6.80208 3.1875 7.15625 3.17708 7.53125 3.46875L11.7812 7.46875C11.9271 7.61458 12 7.79167 12 8C12 8.20833 11.9271 8.38542 11.7812 8.53125L7.53125 12.5312C7.15625 12.8229 6.80208 12.8125 6.46875 12.5C6.32292 12.3542 6.25 12.1875 6.25 12C6.25 11.7917 6.33333 11.6146 6.5 11.4688L9.375 8.75H1.75C1.29167 8.70833 1.04167 8.45833 1 8C1.04167 7.54167 1.29167 7.29167 1.75 7.25H9.375L6.5 4.5625Z"
      />
    </symbol>`,
  "icon-first": `<symbol id="icon-first" viewBox="0 0 16 16">
      <path
        
        d="M2.5 13.25C2.45833 13.7083 2.20833 13.9583 1.75 14C1.29167 13.9583 1.04167 13.7083 1 13.25V2.75C1.04167 2.29167 1.29167 2.04167 1.75 2C2.20833 2.04167 2.45833 2.29167 2.5 2.75V13.25ZM9.5 11.4688C9.8125 11.8021 9.82292 12.1562 9.53125 12.5312C9.19792 12.8438 8.84375 12.8542 8.46875 12.5625L4.21875 8.5625C4.07292 8.41667 4 8.23958 4 8.03125C4 7.82292 4.07292 7.63542 4.21875 7.46875L8.46875 3.46875C8.84375 3.19792 9.19792 3.20833 9.53125 3.5C9.67708 3.66667 9.75 3.84375 9.75 4.03125C9.75 4.23958 9.66667 4.41667 9.5 4.5625L6.625 7.28125H14.25C14.7083 7.30208 14.9583 7.54167 15 8C14.9583 8.45833 14.7083 8.70833 14.25 8.75H6.625L9.5 11.4688Z"
      />
    </symbol>`,
  "icon-arrows-up-down": `<symbol id="icon-arrows-up-down" viewBox="0 0 16 16">
      <path
        
        d="M7.75 16C7.54167 16 7.35417 15.9167 7.1875 15.75L4.1875 12.5C4.0625 12.3542 4 12.1875 4 12C4 11.7917 4.08333 11.6042 4.25 11.4375C4.60417 11.1667 4.95833 11.1875 5.3125 11.5L7 13.3438V2.6875L5.34375 4.53125C4.98958 4.84375 4.63542 4.86458 4.28125 4.59375C4.11458 4.42708 4.03125 4.22917 4.03125 4C4.03125 3.8125 4.09375 3.64583 4.21875 3.5L7.21875 0.25C7.38542 0.0833333 7.57292 0 7.78125 0C7.98958 0 8.17708 0.0833333 8.34375 0.25L11.3438 3.5C11.6146 3.85417 11.5938 4.20833 11.2812 4.5625C10.9271 4.83333 10.5729 4.8125 10.2188 4.5L8.53125 2.65625V13.3438L10.2188 11.5C10.5729 11.1875 10.9271 11.1771 11.2812 11.4688C11.5938 11.8021 11.6146 12.1458 11.3438 12.5L8.34375 15.75C8.19792 15.9375 8 16.0208 7.75 16Z"
      />
    </symbol>`,
  "icon-arrows-up-down-left-right": `<symbol id="icon-arrows-up-down-left-right" viewBox="0 0 16 16">
      <path
        
        d="M16 7.96875C16 8.19792 15.9167 8.38542 15.75 8.53125L13 11.0312C12.8542 11.1771 12.6875 11.25 12.5 11.25C12.0417 11.2083 11.7917 10.9583 11.75 10.5C11.75 10.2917 11.8333 10.1042 12 9.9375L13.3125 8.75H8.75V13.3125L9.9375 12C10.1042 11.8333 10.2917 11.75 10.5 11.75C10.9583 11.7917 11.2083 12.0417 11.25 12.5C11.25 12.6875 11.1875 12.8542 11.0625 13L8.5625 15.75C8.41667 15.9167 8.22917 16 8 16C7.77083 16 7.58333 15.9167 7.4375 15.75L4.9375 13C4.8125 12.8542 4.75 12.6875 4.75 12.5C4.79167 12.0417 5.03125 11.7917 5.46875 11.75C5.67708 11.75 5.86458 11.8333 6.03125 12L7.25 13.3125V8.75H2.6875L4 9.9375C4.16667 10.1042 4.25 10.2917 4.25 10.5C4.20833 10.9583 3.95833 11.2083 3.5 11.25C3.3125 11.25 3.14583 11.1875 3 11.0625L0.25 8.5625C0.0833333 8.41667 0 8.21875 0 7.96875C0 7.73958 0.0833333 7.55208 0.25 7.40625L3 4.90625C3.14583 4.80208 3.3125 4.75 3.5 4.75C3.95833 4.79167 4.20833 5.04167 4.25 5.5C4.25 5.70833 4.16667 5.89583 4 6.0625L2.6875 7.25H7.25V2.6875L6.0625 4C5.89583 4.16667 5.69792 4.25 5.46875 4.25C5.03125 4.20833 4.79167 3.95833 4.75 3.5C4.75 3.3125 4.8125 3.14583 4.9375 3L7.4375 0.21875C7.60417 0.0729167 7.79167 0 8 0C8.20833 0 8.39583 0.0833333 8.5625 0.25L11.0625 3C11.1875 3.14583 11.25 3.3125 11.25 3.5C11.2083 3.95833 10.9583 4.20833 10.5 4.25C10.2917 4.25 10.1042 4.16667 9.9375 4L8.75 2.6875V7.25H13.3125L12 6.0625C11.8333 5.89583 11.75 5.70833 11.75 5.5C11.7917 5.04167 12.0417 4.79167 12.5 4.75C12.6875 4.75 12.8542 4.8125 13 4.9375L15.75 7.4375C15.9167 7.60417 16 7.78125 16 7.96875Z"
      />
    </symbol>`,
  "icon-chart-column": `<symbol id="icon-chart-column" viewBox="0 0 16 16">
      <path
        
        d="M15.25 13.5C15.7083 13.5417 15.9583 13.7917 16 14.25C15.9583 14.7083 15.7083 14.9583 15.25 15H1C0.708333 15 0.46875 14.9062 0.28125 14.7188C0.09375 14.5312 0 14.2917 0 14V1.75C0.0416667 1.29167 0.291667 1.04167 0.75 1C1.20833 1.04167 1.45833 1.29167 1.5 1.75V13.5H15.25ZM5.25 11C4.79167 10.9583 4.54167 10.7083 4.5 10.25V8.75C4.54167 8.29167 4.79167 8.04167 5.25 8C5.70833 8.04167 5.95833 8.29167 6 8.75V10.25C5.95833 10.7083 5.70833 10.9583 5.25 11ZM8.25 11C7.79167 10.9583 7.54167 10.7083 7.5 10.25V4.75C7.54167 4.29167 7.79167 4.04167 8.25 4C8.70833 4.04167 8.95833 4.29167 9 4.75V10.25C8.95833 10.7083 8.70833 10.9583 8.25 11ZM11.25 11C10.7917 10.9583 10.5417 10.7083 10.5 10.25V6.75C10.5417 6.29167 10.7917 6.04167 11.25 6C11.7083 6.04167 11.9583 6.29167 12 6.75V10.25C11.9583 10.7083 11.7083 10.9583 11.25 11ZM14.25 11C13.7917 10.9583 13.5417 10.7083 13.5 10.25V3.75C13.5417 3.29167 13.7917 3.04167 14.25 3C14.7083 3.04167 14.9583 3.29167 15 3.75V10.25C14.9583 10.7083 14.7083 10.9583 14.25 11Z"
      />
    </symbol>`,
  "icon-ban": `<symbol id="icon-ban" viewBox="0 0 16 16">
      <path
        
        d="M8 0C9.5 0.0208333 10.8438 0.385417 12.0312 1.09375C13.2396 1.80208 14.1979 2.76042 14.9062 3.96875C15.6146 5.15625 15.9792 6.5 16 8C15.9792 9.5 15.6146 10.8438 14.9062 12.0312C14.1979 13.2396 13.2396 14.1979 12.0312 14.9062C10.8438 15.6146 9.5 15.9792 8 16C6.5 15.9792 5.15625 15.6146 3.96875 14.9062C2.76042 14.1979 1.80208 13.2396 1.09375 12.0312C0.385417 10.8438 0.0208333 9.5 0 8C0.0208333 6.5 0.385417 5.15625 1.09375 3.96875C1.80208 2.76042 2.76042 1.80208 3.96875 1.09375C5.15625 0.385417 6.5 0.0208333 8 0ZM1.5 8C1.54167 9.83333 2.17708 11.3646 3.40625 12.5938C4.63542 13.8229 6.16667 14.4583 8 14.5C9.54167 14.4583 10.8854 14 12.0312 13.125L2.90625 4C1.98958 5.10417 1.52083 6.4375 1.5 8ZM13.0938 12C14.0104 10.8958 14.4792 9.5625 14.5 8C14.4583 6.16667 13.8229 4.63542 12.5938 3.40625C11.3646 2.17708 9.83333 1.54167 8 1.5C6.45833 1.52083 5.11458 1.98958 3.96875 2.90625L13.0938 12Z"
      />
    </symbol>`,
  "icon-radio-unselected": `<symbol id="icon-radio-unselected" class="circle-regular" viewBox="0 0 512 512">
      <path
        
        d="M512 256C512 397.4 397.4 512 256 512C114.6 512 0 397.4 0 256C0 114.6 114.6 0 256 0C397.4 0 512 114.6 512 256zM256 48C141.1 48 48 141.1 48 256C48 370.9 141.1 464 256 464C370.9 464 464 370.9 464 256C464 141.1 370.9 48 256 48z"
      />
    </symbol>`,
  "icon-radio-selected": `<symbol id="icon-radio-selected" class="circle-dot-regular" viewBox="0 0 512 512">
      <path
        
        d="M160 256C160 202.1 202.1 160 256 160C309 160 352 202.1 352 256C352 309 309 352 256 352C202.1 352 160 309 160 256zM512 256C512 397.4 397.4 512 256 512C114.6 512 0 397.4 0 256C0 114.6 114.6 0 256 0C397.4 0 512 114.6 512 256zM256 48C141.1 48 48 141.1 48 256C48 370.9 141.1 464 256 464C370.9 464 464 370.9 464 256C464 141.1 370.9 48 256 48z"
      />
    </symbol>`,
  "icon-file-excel": `<symbol id="icon-file-excel" viewBox="0 0 384 512">
      <path
        
        d="M365.3 93.38l-74.63-74.64C278.6 6.742 262.3 0 245.4 0H64C28.65 0 0 28.65 0 64l.0065 384c0 35.34 28.65 64 64 64H320c35.2 0 64-28.8 64-64V138.6C384 121.7 377.3 105.4 365.3 93.38zM336 448c0 8.836-7.164 16-16 16H64.02c-8.838 0-16-7.164-16-16L48 64.13c0-8.836 7.164-16 16-16h160L224 128c0 17.67 14.33 32 32 32h79.1V448zM229.1 233.3L192 280.9L154.9 233.3C146.8 222.8 131.8 220.9 121.3 229.1C110.8 237.2 108.9 252.3 117.1 262.8L161.6 320l-44.53 57.25c-8.156 10.47-6.25 25.56 4.188 33.69C125.7 414.3 130.8 416 135.1 416c7.156 0 14.25-3.188 18.97-9.25L192 359.1l37.06 47.65C233.8 412.8 240.9 416 248 416c5.125 0 10.31-1.656 14.72-5.062c10.44-8.125 12.34-23.22 4.188-33.69L222.4 320l44.53-57.25c8.156-10.47 6.25-25.56-4.188-33.69C252.2 220.9 237.2 222.8 229.1 233.3z"
      />
    </symbol>`,
  "icon-file-csv": `<symbol id="icon-file-csv" viewBox="0 0 16 16">
      <g clip-path="url(#clip0_2865_64906)">
        <path
          
          d="M2 14.5H3V16H2C0.896875 16 0 15.1031 0 14V2C0 0.896875 0.896875 0 2 0H7.17188C7.70312 0 8.2125 0.209375 8.5875 0.584375L11.4156 3.4125C11.7906 3.7875 12 4.29688 12 4.82812V9H10.5V5H8C7.44688 5 7 4.55312 7 4V1.5H2C1.725 1.5 1.5 1.725 1.5 2V14C1.5 14.275 1.725 14.5 2 14.5ZM6.25 11H6.75C7.44063 11 8 11.5594 8 12.25V12.5C8 12.775 7.775 13 7.5 13C7.225 13 7 12.775 7 12.5V12.25C7 12.1125 6.8875 12 6.75 12H6.25C6.1125 12 6 12.1125 6 12.25V14.75C6 14.8875 6.1125 15 6.25 15H6.75C6.8875 15 7 14.8875 7 14.75V14.5C7 14.225 7.225 14 7.5 14C7.775 14 8 14.225 8 14.5V14.75C8 15.4406 7.44063 16 6.75 16H6.25C5.55937 16 5 15.4406 5 14.75V12.25C5 11.5594 5.55937 11 6.25 11ZM10.4094 11H11.5C11.775 11 12 11.225 12 11.5C12 11.775 11.775 12 11.5 12H10.4094C10.1844 12 10 12.1844 10 12.4094C10 12.5719 10.0938 12.7188 10.2437 12.7844L11.4125 13.3031C11.9219 13.5281 12.25 14.0344 12.25 14.5906C12.25 15.3687 11.6187 16 10.8406 16H9.5C9.225 16 9 15.775 9 15.5C9 15.225 9.225 15 9.5 15H10.8406C11.0656 15 11.25 14.8156 11.25 14.5906C11.25 14.4281 11.1562 14.2812 11.0063 14.2156L9.8375 13.6969C9.32812 13.4719 9 12.9656 9 12.4094C9 11.6313 9.63125 11 10.4094 11ZM13.5 11C13.775 11 14 11.225 14 11.5V12.4875C14 13.2063 14.1719 13.9125 14.5 14.55C14.8281 13.9156 15 13.2094 15 12.4875V11.5C15 11.225 15.225 11 15.5 11C15.775 11 16 11.225 16 11.5V12.4875C16 13.5719 15.6781 14.6344 15.075 15.5375L14.9156 15.7781C14.8219 15.9187 14.6656 16 14.5 16C14.3344 16 14.1781 15.9156 14.0844 15.7781L13.925 15.5375C13.3219 14.6344 13 13.5719 13 12.4875V11.5C13 11.225 13.225 11 13.5 11Z"
        />
      </g>
      <defs>
        <clipPath id="clip0_2865_64906">
          <rect width="16" height="16" fill="white" />
        </clipPath>
      </defs>
    </symbol>`,
  "icon-file-png": `<symbol id="icon-file-png" viewBox="0 0 16 16">
      <g clip-path="url(#clip0_2865_64907)">
        <path
          
          d="M2 14.5H3.5V16H2C0.896875 16 0 15.1031 0 14V2C0 0.896875 0.896875 0 2 0H7.17188C7.70312 0 8.2125 0.209375 8.5875 0.584375L11.4156 3.4125C11.7906 3.7875 12 4.29688 12 4.82812V9.5H10.5V5H8C7.44688 5 7 4.55312 7 4V1.5H2C1.725 1.5 1.5 1.725 1.5 2V14C1.5 14.275 1.725 14.5 2 14.5ZM9.94687 11.275L11 13.3813V11.5C11 11.225 11.225 11 11.5 11C11.775 11 12 11.225 12 11.5V15.5C12 15.7312 11.8406 15.9344 11.6156 15.9875C11.3906 16.0406 11.1562 15.9313 11.0531 15.725L10 13.6187V15.5C10 15.775 9.775 16 9.5 16C9.225 16 9 15.775 9 15.5V11.5C9 11.2688 9.15937 11.0656 9.38437 11.0125C9.60938 10.9594 9.84375 11.0687 9.94687 11.275ZM5.5 11H6.5C7.46562 11 8.25 11.7844 8.25 12.75C8.25 13.7156 7.46562 14.5 6.5 14.5H6V15.5C6 15.775 5.775 16 5.5 16C5.225 16 5 15.775 5 15.5V14V11.5C5 11.225 5.225 11 5.5 11ZM6.5 13.5C6.91563 13.5 7.25 13.1656 7.25 12.75C7.25 12.3344 6.91563 12 6.5 12H6V13.5H6.5ZM13 12.25C13 11.5594 13.5594 11 14.25 11H14.75C15.4406 11 16 11.5594 16 12.25V12.5C16 12.775 15.775 13 15.5 13C15.225 13 15 12.775 15 12.5V12.25C15 12.1125 14.8875 12 14.75 12H14.25C14.1125 12 14 12.1125 14 12.25V14.75C14 14.8875 14.1125 15 14.25 15H14.75C14.8875 15 15 14.8875 15 14.75V14.5C14.725 14.5 14.5 14.275 14.5 14C14.5 13.725 14.725 13.5 15 13.5H15.5C15.775 13.5 16 13.725 16 14V14.75C16 15.4406 15.4406 16 14.75 16H14.25C13.5594 16 13 15.4406 13 14.75V12.25Z"
        />
      </g>
      <defs>
        <clipPath id="clip0_2865_64907">
          <rect width="16" height="16" fill="white" />
        </clipPath>
      </defs>
    </symbol>`,
  "icon-file-xls": `<symbol id="icon-file-xls" viewBox="0 0 16 16">
      <g clip-path="url(#clip0_2865_64908)">
        <path
          
          d="M4 14.5H2C1.725 14.5 1.5 14.275 1.5 14V2C1.5 1.725 1.725 1.5 2 1.5H7V4C7 4.55312 7.44688 5 8 5H10.5V9H12V4.82812C12 4.29688 11.7906 3.7875 11.4156 3.4125L8.58438 0.584375C8.20938 0.209375 7.70312 0 7.17188 0H2C0.896875 0 0 0.896875 0 2V14C0 15.1031 0.896875 16 2 16H4V14.5ZM7 11.5C7 11.225 6.775 11 6.5 11C6.225 11 6 11.225 6 11.5C6 11.925 6.125 12.3406 6.3625 12.6938L6.9 13.5L6.3625 14.3062C6.125 14.6594 6 15.075 6 15.5C6 15.775 6.225 16 6.5 16C6.775 16 7 15.775 7 15.5C7 15.2719 7.06875 15.05 7.19375 14.8625L7.5 14.4031L7.80625 14.8625C7.93125 15.0531 8 15.275 8 15.5C8 15.775 8.225 16 8.5 16C8.775 16 9 15.775 9 15.5C9 15.075 8.875 14.6594 8.6375 14.3062L8.1 13.5L8.6375 12.6938C8.875 12.3406 9 11.925 9 11.5C9 11.225 8.775 11 8.5 11C8.225 11 8 11.225 8 11.5C8 11.7281 7.93125 11.95 7.80625 12.1375L7.5 12.6L7.19375 12.1406C7.06875 11.95 7 11.7281 7 11.5031V11.5ZM10 15.5C10 15.775 10.225 16 10.5 16H12C12.275 16 12.5 15.775 12.5 15.5C12.5 15.225 12.275 15 12 15H11V11.5C11 11.225 10.775 11 10.5 11C10.225 11 10 11.225 10 11.5V15.5ZM12.75 12.4281C12.75 12.9688 13.0563 13.4625 13.5375 13.7031L14.5125 14.1906C14.6562 14.2625 14.75 14.4094 14.75 14.5719C14.75 14.8062 14.5594 15 14.3219 15H13.5C13.225 15 13 15.225 13 15.5C13 15.775 13.225 16 13.5 16H14.3219C15.1094 16 15.75 15.3625 15.75 14.5719C15.75 14.0312 15.4437 13.5375 14.9625 13.2969L13.9875 12.8094C13.8438 12.7375 13.75 12.5906 13.75 12.4281C13.75 12.1938 13.9406 12 14.1781 12H15C15.275 12 15.5 11.775 15.5 11.5C15.5 11.225 15.275 11 15 11H14.1781C13.3906 11 12.75 11.6375 12.75 12.4281Z"
        />
      </g>
      <defs>
        <clipPath id="clip0_2865_64908">
          <rect width="16" height="16" fill="white" />
        </clipPath>
      </defs>
    </symbol>`,
  "icon-file-pdf": `<symbol id="icon-file-pdf" viewBox="0 0 16 16">
      <g clip-path="url(#clip0_2865_64905)">
        <path
          
          d="M2 14.5H3.5V16H2C0.896875 16 0 15.1031 0 14V2C0 0.896875 0.896875 0 2 0H7.17188C7.70312 0 8.2125 0.209375 8.5875 0.584375L11.4156 3.4125C11.7906 3.7875 12 4.29688 12 4.82812V9.5H10.5V5H8C7.44688 5 7 4.55312 7 4V1.5H2C1.725 1.5 1.5 1.725 1.5 2V14C1.5 14.275 1.725 14.5 2 14.5ZM5.5 11H6.5C7.46562 11 8.25 11.7844 8.25 12.75C8.25 13.7156 7.46562 14.5 6.5 14.5H6V15.5C6 15.775 5.775 16 5.5 16C5.225 16 5 15.775 5 15.5V14V11.5C5 11.225 5.225 11 5.5 11ZM6.5 13.5C6.91563 13.5 7.25 13.1656 7.25 12.75C7.25 12.3344 6.91563 12 6.5 12H6V13.5H6.5ZM9.5 11H10.5C11.3281 11 12 11.6719 12 12.5V14.5C12 15.3281 11.3281 16 10.5 16H9.5C9.225 16 9 15.775 9 15.5V11.5C9 11.225 9.225 11 9.5 11ZM10.5 15C10.775 15 11 14.775 11 14.5V12.5C11 12.225 10.775 12 10.5 12H10V15H10.5ZM13 11.5C13 11.225 13.225 11 13.5 11H15C15.275 11 15.5 11.225 15.5 11.5C15.5 11.775 15.275 12 15 12H14V13H15C15.275 13 15.5 13.225 15.5 13.5C15.5 13.775 15.275 14 15 14H14V15.5C14 15.775 13.775 16 13.5 16C13.225 16 13 15.775 13 15.5V13.5V11.5Z"
        />
      </g>
      <defs>
        <clipPath id="clip0_2865_64905">
          <rect width="16" height="16" fill="white" />
        </clipPath>
      </defs>
    </symbol>`,
  "icon-file-ppt": `<symbol id="icon-file-ppt" viewBox="0 0 16 16">
      <g clip-path="url(#clip0_2865_64904)">
        <path
          
          d="M2 14.5H3V16H2C0.896875 16 0 15.1031 0 14V2C0 0.896875 0.896875 0 2 0H7.17188C7.70312 0 8.2125 0.209375 8.5875 0.584375L11.4156 3.4125C11.7906 3.7875 12 4.29688 12 4.82812V9H10.5V5H8C7.44688 5 7 4.55312 7 4V1.5H2C1.725 1.5 1.5 1.725 1.5 2V14C1.5 14.275 1.725 14.5 2 14.5ZM9.5 11H10.5C11.4656 11 12.25 11.7844 12.25 12.75C12.25 13.7156 11.4656 14.5 10.5 14.5H10V15.5C10 15.775 9.775 16 9.5 16C9.225 16 9 15.775 9 15.5V14V11.5C9 11.225 9.225 11 9.5 11ZM10.5 13.5C10.9156 13.5 11.25 13.1656 11.25 12.75C11.25 12.3344 10.9156 12 10.5 12H10V13.5H10.5ZM5.5 11H6.5C7.46562 11 8.25 11.7844 8.25 12.75C8.25 13.7156 7.46562 14.5 6.5 14.5H6V15.5C6 15.775 5.775 16 5.5 16C5.225 16 5 15.775 5 15.5V14V11.5C5 11.225 5.225 11 5.5 11ZM6.5 13.5C6.91563 13.5 7.25 13.1656 7.25 12.75C7.25 12.3344 6.91563 12 6.5 12H6V13.5H6.5ZM13 11.5C13 11.225 13.225 11 13.5 11H14.5H15.5C15.775 11 16 11.225 16 11.5C16 11.775 15.775 12 15.5 12H15V15.5C15 15.775 14.775 16 14.5 16C14.225 16 14 15.775 14 15.5V12H13.5C13.225 12 13 11.775 13 11.5Z"
        />
      </g>
      <defs>
        <clipPath id="clip0_2865_64904">
          <rect width="16" height="16" fill="white" />
        </clipPath>
      </defs>
    </symbol>`,
  "icon-file-doc": `<symbol id="icon-file-doc" viewBox="0 0 16 16">
      <g clip-path="url(#clip0_2865_64903)">
        <path
          
          d="M2 14.5H3V16H2C0.896875 16 0 15.1031 0 14V2C0 0.896875 0.896875 0 2 0H7.17188C7.70312 0 8.2125 0.209375 8.5875 0.584375L11.4156 3.4125C11.7906 3.7875 12 4.29688 12 4.82812V9H10.5V5H8C7.44688 5 7 4.55312 7 4V1.5H2C1.725 1.5 1.5 1.725 1.5 2V14C1.5 14.275 1.725 14.5 2 14.5ZM5.5 11H6.5C7.32812 11 8 11.6719 8 12.5V14.5C8 15.3281 7.32812 16 6.5 16H5.5C5.225 16 5 15.775 5 15.5V11.5C5 11.225 5.225 11 5.5 11ZM6 15H6.5C6.775 15 7 14.775 7 14.5V12.5C7 12.225 6.775 12 6.5 12H6V15ZM14.25 11H14.75C15.4406 11 16 11.5594 16 12.25V12.5C16 12.775 15.775 13 15.5 13C15.225 13 15 12.775 15 12.5V12.25C15 12.1125 14.8875 12 14.75 12H14.25C14.1125 12 14 12.1125 14 12.25V14.75C14 14.8875 14.1125 15 14.25 15H14.75C14.8875 15 15 14.8875 15 14.75V14.5C15 14.225 15.225 14 15.5 14C15.775 14 16 14.225 16 14.5V14.75C16 15.4406 15.4406 16 14.75 16H14.25C13.5594 16 13 15.4406 13 14.75V12.25C13 11.5594 13.5594 11 14.25 11ZM9 12.25C9 11.5594 9.55937 11 10.25 11H10.75C11.4406 11 12 11.5594 12 12.25V14.75C12 15.4406 11.4406 16 10.75 16H10.25C9.55937 16 9 15.4406 9 14.75V12.25ZM10.25 12C10.1125 12 10 12.1125 10 12.25V14.75C10 14.8875 10.1125 15 10.25 15H10.75C10.8875 15 11 14.8875 11 14.75V12.25C11 12.1125 10.8875 12 10.75 12H10.25Z"
        />
      </g>
      <defs>
        <clipPath id="clip0_2865_64903">
          <rect width="16" height="16" fill="white" />
        </clipPath>
      </defs>
    </symbol>`,
  "icon-eye-dropper": `<symbol id="icon-eye-dropper" class="eye-dropper-half-regular" viewBox="0 0 512 512">
      <path
        
        d="M191 160.1C181.7 151.6 181.7 136.4 191 127C200.4 117.7 215.6 117.7 224.1 127L232.1 135L338.2 29.82C357.3 10.73 383.2 0 410.2 0C466.4 0 512 45.59 512 101.8C512 128.8 501.3 154.7 482.2 173.8L376.1 279L384.1 287C394.3 296.4 394.3 311.6 384.1 320.1C375.6 330.3 360.4 330.3 351 320.1L191 160.1zM343 245.1L448.2 139.9C458.3 129.8 464 116.1 464 101.8C464 72.1 439.9 48 410.2 48C395.9 48 382.2 53.67 372.1 63.76L266.9 168.1L343 245.1zM217.4 232.6L129.9 320H254.1L279.4 294.6L313.4 328.6L183 458.9C169.5 472.4 151.2 480 132.1 480H79.27L37.31 507.1C27.79 514.3 15.12 513.1 7.03 504.1C-1.06 496.9-2.315 484.2 4.031 474.7L32 432.7V379.9C32 360.8 39.59 342.5 53.09 328.1L183.4 198.6L217.4 232.6z"
      />
    </symbol>`,
  "icon-columns": `<symbol id="icon-columns" viewBox="0 0 16 16">
      <path
        
        d="M6.25 4.25C6.70833 4.29167 6.95833 4.54167 7 5C6.95833 5.45833 6.70833 5.70833 6.25 5.75H0.71875C0.53125 5.75 0.364583 5.66667 0.21875 5.5C0.0729167 5.35417 0 5.17708 0 4.96875C0.0416667 4.53125 0.28125 4.29167 0.71875 4.25H6.25ZM6.25 8.25C6.70833 8.29167 6.95833 8.54167 7 9C6.95833 9.45833 6.70833 9.70833 6.25 9.75H0.71875C0.28125 9.70833 0.0416667 9.45833 0 9C0.0416667 8.54167 0.28125 8.29167 0.71875 8.25H6.25ZM6.25 0.25C6.70833 0.291667 6.95833 0.541667 7 1C6.95833 1.45833 6.70833 1.70833 6.25 1.75H0.71875C0.53125 1.75 0.364583 1.66667 0.21875 1.5C0.0729167 1.35417 0 1.17708 0 0.96875C0.0416667 0.53125 0.28125 0.291667 0.71875 0.25H6.25ZM6.25 12.25C6.70833 12.2917 6.95833 12.5417 7 13C6.95833 13.4583 6.70833 13.7083 6.25 13.75H0.71875C0.28125 13.7083 0.0416667 13.4583 0 13C0.0416667 12.5417 0.28125 12.2917 0.71875 12.25H6.25ZM15.25 0.25C15.4583 0.25 15.6354 0.333333 15.7812 0.5C15.9271 0.645833 16 0.822917 16 1.03125C15.9583 1.46875 15.7083 1.70833 15.25 1.75H9.71875C9.53125 1.75 9.36458 1.66667 9.21875 1.5C9.07292 1.35417 9 1.17708 9 0.96875C9.04167 0.53125 9.29167 0.291667 9.75 0.25H15.25ZM15.25 4.25C15.4583 4.25 15.6354 4.33333 15.7812 4.5C15.9271 4.64583 16 4.82292 16 5.03125C15.9583 5.46875 15.7083 5.70833 15.25 5.75H9.71875C9.53125 5.75 9.36458 5.66667 9.21875 5.5C9.07292 5.35417 9 5.17708 9 4.96875C9.04167 4.53125 9.29167 4.29167 9.75 4.25H15.25ZM15.25 12.25C15.7083 12.2917 15.9583 12.5417 16 13C15.9583 13.4583 15.7083 13.7083 15.25 13.75H9.71875C9.28125 13.7083 9.04167 13.4583 9 13C9.04167 12.5417 9.29167 12.2917 9.75 12.25H15.25ZM15.25 8.25C15.7083 8.29167 15.9583 8.54167 16 9C15.9583 9.45833 15.7083 9.70833 15.25 9.75H9.71875C9.28125 9.70833 9.04167 9.45833 9 9C9.04167 8.54167 9.29167 8.29167 9.75 8.25H15.25Z"
      />
    </symbol>`,
  "icon-grip": `<symbol id="icon-grip" viewBox="0 0 16 16">
      <path
        
        d="M4 3C4.02083 2.58333 4.16667 2.22917 4.4375 1.9375C4.72917 1.66667 5.08333 1.52083 5.5 1.5C5.91667 1.52083 6.27083 1.66667 6.5625 1.9375C6.83333 2.22917 6.97917 2.58333 7 3C6.97917 3.41667 6.83333 3.77083 6.5625 4.0625C6.27083 4.33333 5.91667 4.47917 5.5 4.5C5.08333 4.47917 4.72917 4.33333 4.4375 4.0625C4.16667 3.77083 4.02083 3.41667 4 3ZM4 8C4.02083 7.58333 4.16667 7.22917 4.4375 6.9375C4.72917 6.66667 5.08333 6.52083 5.5 6.5C5.91667 6.52083 6.27083 6.66667 6.5625 6.9375C6.83333 7.22917 6.97917 7.58333 7 8C6.97917 8.41667 6.83333 8.77083 6.5625 9.0625C6.27083 9.33333 5.91667 9.47917 5.5 9.5C5.08333 9.47917 4.72917 9.33333 4.4375 9.0625C4.16667 8.77083 4.02083 8.41667 4 8ZM7 13C6.97917 13.4167 6.83333 13.7708 6.5625 14.0625C6.27083 14.3333 5.91667 14.4792 5.5 14.5C5.08333 14.4792 4.72917 14.3333 4.4375 14.0625C4.16667 13.7708 4.02083 13.4167 4 13C4.02083 12.5833 4.16667 12.2292 4.4375 11.9375C4.72917 11.6667 5.08333 11.5208 5.5 11.5C5.91667 11.5208 6.27083 11.6667 6.5625 11.9375C6.83333 12.2292 6.97917 12.5833 7 13ZM9 3C9.02083 2.58333 9.16667 2.22917 9.4375 1.9375C9.72917 1.66667 10.0833 1.52083 10.5 1.5C10.9167 1.52083 11.2708 1.66667 11.5625 1.9375C11.8333 2.22917 11.9792 2.58333 12 3C11.9792 3.41667 11.8333 3.77083 11.5625 4.0625C11.2708 4.33333 10.9167 4.47917 10.5 4.5C10.0833 4.47917 9.72917 4.33333 9.4375 4.0625C9.16667 3.77083 9.02083 3.41667 9 3ZM12 8C11.9792 8.41667 11.8333 8.77083 11.5625 9.0625C11.2708 9.33333 10.9167 9.47917 10.5 9.5C10.0833 9.47917 9.72917 9.33333 9.4375 9.0625C9.16667 8.77083 9.02083 8.41667 9 8C9.02083 7.58333 9.16667 7.22917 9.4375 6.9375C9.72917 6.66667 10.0833 6.52083 10.5 6.5C10.9167 6.52083 11.2708 6.66667 11.5625 6.9375C11.8333 7.22917 11.9792 7.58333 12 8ZM9 13C9.02083 12.5833 9.16667 12.2292 9.4375 11.9375C9.72917 11.6667 10.0833 11.5208 10.5 11.5C10.9167 11.5208 11.2708 11.6667 11.5625 11.9375C11.8333 12.2292 11.9792 12.5833 12 13C11.9792 13.4167 11.8333 13.7708 11.5625 14.0625C11.2708 14.3333 10.9167 14.4792 10.5 14.5C10.0833 14.4792 9.72917 14.3333 9.4375 14.0625C9.16667 13.7708 9.02083 13.4167 9 13Z"
      />
    </symbol>`,
  "icon-thumbtack": `<symbol id="icon-thumbtack" viewBox="0 0 384 512">
      <path
        
        d="M168 352H32C22.15 352 12.84 347.5 6.778 339.7C.7133 331.9-1.434 321.8 .9555 312.2L7.202 287.3C17.51 246 42.58 211.5 75.93 188.9L86.77 48H56C51.56 48 47.41 46.8 43.84 44.7C36.76 40.53 32 32.82 32 24C32 10.75 42.75 0 56 0H328C341.3 0 352 10.75 352 24C352 32.82 347.2 40.53 340.2 44.7C336.6 46.8 332.4 48 328 48H297.2L308.1 188.9C341.4 211.5 366.5 246 376.8 287.3L383 312.2C385.4 321.8 383.3 331.9 377.2 339.7C371.2 347.5 361.9 352 352 352H216V488C216 501.3 205.3 512 191.1 512C178.7 512 167.1 501.3 167.1 488L168 352zM122 215.7L102.9 228.7C79.01 244.8 61.13 269.4 53.77 298.9L52.49 304H168V216C168 202.7 178.7 192 192 192C205.3 192 216 202.7 216 216V304H331.5L330.2 298.9C322.9 269.4 304.1 244.8 281.1 228.7L261.1 215.7L249.1 48H134.9L122 215.7z"
      />
    </symbol>`,
  "icon-table-pivot": `<symbol id="icon-table-pivot" viewBox="0 0 16 16">
      <path
        
        d="M4 1V5H0V3C0.0208333 2.4375 0.21875 1.96875 0.59375 1.59375C0.96875 1.21875 1.4375 1.02083 2 1H4ZM8.5625 9.0625C8.64583 9 8.73958 8.97917 8.84375 9C8.92708 9.04167 8.97917 9.11458 9 9.21875V10H10.75C10.8958 9.97917 10.9792 9.89583 11 9.75V8H10.25C10.1458 8 10.0729 7.94792 10.0312 7.84375C9.98958 7.76042 10 7.66667 10.0625 7.5625L11.3125 6.3125C11.4375 6.22917 11.5625 6.22917 11.6875 6.3125L12.9375 7.5625C13 7.64583 13.0208 7.73958 13 7.84375C12.9583 7.94792 12.875 8 12.75 8H12V9.75C12 10.1042 11.875 10.3958 11.625 10.625C11.3958 10.875 11.1042 11 10.75 11H9V11.7188C8.9375 11.9896 8.79167 12.0625 8.5625 11.9375L7.3125 10.6875C7.22917 10.5625 7.22917 10.4375 7.3125 10.3125L8.5625 9.0625ZM14 1C14.5625 1.02083 15.0312 1.21875 15.4062 1.59375C15.7812 1.96875 15.9792 2.4375 16 3V13C15.9792 13.5625 15.7812 14.0312 15.4062 14.4062C15.0312 14.7812 14.5625 14.9792 14 15H2C1.4375 14.9792 0.96875 14.7812 0.59375 14.4062C0.21875 14.0312 0.0208333 13.5625 0 13V6H3.5V13.5H14C14.3125 13.4792 14.4792 13.3125 14.5 13V4.5H5V1H14Z"
      />
    </symbol>`,
  "icon-checkbox-unchecked": `<symbol id="icon-checkbox-unchecked" class="square-regular" viewBox="0 0 448 512">
      <path
        
        d="M384 32C419.3 32 448 60.65 448 96V416C448 451.3 419.3 480 384 480H64C28.65 480 0 451.3 0 416V96C0 60.65 28.65 32 64 32H384zM384 80H64C55.16 80 48 87.16 48 96V416C48 424.8 55.16 432 64 432H384C392.8 432 400 424.8 400 416V96C400 87.16 392.8 80 384 80z"
      />
    </symbol>`,
  "icon-square-plus": `<symbol id="icon-square-plus" viewBox="0 0 448 512">
      <path
        
        d="M200 344V280H136C122.7 280 112 269.3 112 256C112 242.7 122.7 232 136 232H200V168C200 154.7 210.7 144 224 144C237.3 144 248 154.7 248 168V232H312C325.3 232 336 242.7 336 256C336 269.3 325.3 280 312 280H248V344C248 357.3 237.3 368 224 368C210.7 368 200 357.3 200 344zM0 96C0 60.65 28.65 32 64 32H384C419.3 32 448 60.65 448 96V416C448 451.3 419.3 480 384 480H64C28.65 480 0 451.3 0 416V96zM48 96V416C48 424.8 55.16 432 64 432H384C392.8 432 400 424.8 400 416V96C400 87.16 392.8 80 384 80H64C55.16 80 48 87.16 48 96z"
      />
    </symbol>`,
  "icon-checkbox-indeterminate": `<symbol id="icon-checkbox-indeterminate" class="square-minus-regular" viewBox="0 0 448 512">
      <path
        
        d="M312 232C325.3 232 336 242.7 336 256C336 269.3 325.3 280 312 280H136C122.7 280 112 269.3 112 256C112 242.7 122.7 232 136 232H312zM0 96C0 60.65 28.65 32 64 32H384C419.3 32 448 60.65 448 96V416C448 451.3 419.3 480 384 480H64C28.65 480 0 451.3 0 416V96zM48 96V416C48 424.8 55.16 432 64 432H384C392.8 432 400 424.8 400 416V96C400 87.16 392.8 80 384 80H64C55.16 80 48 87.16 48 96z"
      />
    </symbol>`,
  "icon-checkbox-checked": `<symbol id="icon-checkbox-checked" class="square-check-regular" viewBox="0 0 448 512">
      <path
        
        d="M211.8 339.8C200.9 350.7 183.1 350.7 172.2 339.8L108.2 275.8C97.27 264.9 97.27 247.1 108.2 236.2C119.1 225.3 136.9 225.3 147.8 236.2L192 280.4L300.2 172.2C311.1 161.3 328.9 161.3 339.8 172.2C350.7 183.1 350.7 200.9 339.8 211.8L211.8 339.8zM0 96C0 60.65 28.65 32 64 32H384C419.3 32 448 60.65 448 96V416C448 451.3 419.3 480 384 480H64C28.65 480 0 451.3 0 416V96zM48 96V416C48 424.8 55.16 432 64 432H384C392.8 432 400 424.8 400 416V96C400 87.16 392.8 80 384 80H64C55.16 80 48 87.16 48 96z"
      />
    </symbol>`,
  "icon-sigma": `<symbol id="icon-sigma" viewBox="0 0 384 512">
      <path
        
        d="M335.1 136l.0005-56H83.59l165 158.7C253.3 243.2 255.1 249.5 255.1 256s-2.656 12.78-7.375 17.31L83.59 432h252.4l-.0005-56c0-13.25 10.75-24 24-24C373.2 352 384 362.8 384 376v80c0 13.25-10.75 24-24 24H23.99c-9.782 0-18.59-5.938-22.25-15.03s-1.438-19.47 5.625-26.28L197.4 256L7.364 73.31C.3015 66.5-1.917 56.13 1.739 47.03S14.21 32 23.99 32h336C373.2 32 384 42.75 384 56v80C384 149.3 373.2 160 359.1 160C346.7 160 335.1 149.3 335.1 136z"
      />
    </symbol>`,
  "icon-list-tree": `<symbol id="icon-list-tree" viewBox="0 0 16 16">
      <path
        
        d="M5.75 3.75C5.29167 3.70833 5.04167 3.45833 5 3C5.04167 2.54167 5.29167 2.29167 5.75 2.25H15.25C15.7083 2.29167 15.9583 2.54167 16 3C15.9583 3.45833 15.7083 3.70833 15.25 3.75H5.75ZM6.5 6.5C6.8125 6.52083 6.97917 6.6875 7 7V9C6.97917 9.3125 6.8125 9.47917 6.5 9.5H4.5C4.1875 9.47917 4.02083 9.3125 4 9V8.75H2.25V12C2.27083 12.1458 2.35417 12.2292 2.5 12.25H4V12C4.02083 11.6875 4.1875 11.5208 4.5 11.5H6.5C6.8125 11.5208 6.97917 11.6875 7 12V14C6.97917 14.3125 6.8125 14.4792 6.5 14.5H4.5C4.1875 14.4792 4.02083 14.3125 4 14V13.75H2.5C2 13.7292 1.58333 13.5625 1.25 13.25C0.9375 12.9167 0.770833 12.5 0.75 12V4.5H0.5C0.1875 4.47917 0.0208333 4.3125 0 4V2C0.0208333 1.6875 0.1875 1.52083 0.5 1.5H2.5C2.8125 1.52083 2.97917 1.6875 3 2V4C2.97917 4.3125 2.8125 4.47917 2.5 4.5H2.25V7.25H4V7C4.02083 6.6875 4.1875 6.52083 4.5 6.5H6.5ZM15.25 12.25C15.7083 12.2917 15.9583 12.5417 16 13C15.9583 13.4583 15.7083 13.7083 15.25 13.75H9.75C9.29167 13.7083 9.04167 13.4583 9 13C9.04167 12.5417 9.29167 12.2917 9.75 12.25H15.25ZM15.25 7.25C15.7083 7.29167 15.9583 7.54167 16 8C15.9583 8.45833 15.7083 8.70833 15.25 8.75H9.75C9.29167 8.70833 9.04167 8.45833 9 8C9.04167 7.54167 9.29167 7.29167 9.75 7.25H15.25Z"
      />
    </symbol>`,
  "icon-link-slash": `<symbol id="icon-link-slash" viewBox="0 0 20 16">
      <path
        
        d="M6.62946 13.5938L8.22321 12.0312C8.59821 12.3854 9.01488 12.6771 9.47321 12.9062L7.69196 14.6875C6.75446 15.5625 5.69196 16 4.50446 16C3.29613 16 2.23363 15.5625 1.31696 14.6875C0.441964 13.7708 0.00446429 12.7083 0.00446429 11.5C0.00446429 10.3125 0.441964 9.25 1.31696 8.3125L3.72321 5.9375L4.91071 6.84375L2.37946 9.34375C1.79613 9.96875 1.50446 10.6771 1.50446 11.4688C1.50446 12.2812 1.79613 12.9896 2.37946 13.5938C3.00446 14.1771 3.7128 14.4688 4.50446 14.4688C5.29613 14.4688 6.00446 14.1771 6.62946 13.5938ZM15.2232 11.1562L19.692 14.625C20.0253 14.9375 20.067 15.2917 19.817 15.6875C19.5045 16.0208 19.1503 16.0625 18.7545 15.8125L0.285714 1.34375C-0.047619 1.03125 -0.0892857 0.677083 0.160714 0.28125C0.327381 0.09375 0.525298 0 0.754464 0C0.921131 0 1.07738 0.0520833 1.22321 0.15625L6.06696 3.9375C6.67113 3.625 7.32738 3.46875 8.03571 3.46875C9.26488 3.48958 10.3274 3.92708 11.2232 4.78125C12.0774 5.67708 12.5149 6.73958 12.5357 7.96875C12.5357 8.30208 12.494 8.625 12.4107 8.9375L14.0357 10.2188C14.0357 10.1979 14.0461 10.1875 14.067 10.1875C14.067 10.1667 14.0774 10.1562 14.0982 10.1562L17.6295 6.625C18.2128 6 18.5045 5.29167 18.5045 4.5C18.5045 3.70833 18.2128 3 17.6295 2.375C17.0045 1.79167 16.2961 1.5 15.5045 1.5C14.7128 1.5 14.0045 1.79167 13.3795 2.375L11.7857 3.96875C11.4107 3.61458 10.994 3.32292 10.5357 3.09375L12.317 1.3125C13.2545 0.4375 14.317 0 15.5045 0C16.7128 0 17.7753 0.4375 18.692 1.3125C19.567 2.22917 20.0045 3.29167 20.0045 4.5C20.0045 5.6875 19.567 6.75 18.692 7.6875L15.2232 11.1562ZM7.47321 5.0625L11.0357 7.84375C10.994 7.07292 10.7024 6.40625 10.1607 5.84375C9.80655 5.48958 9.38988 5.25 8.91071 5.125C8.43155 5 7.95238 4.97917 7.47321 5.0625ZM8.78571 11.2188C8.13988 10.5729 7.72321 9.8125 7.53571 8.9375L12.1295 12.5312C12.1086 12.5312 12.0774 12.5312 12.0357 12.5312C12.0149 12.5312 11.994 12.5312 11.9732 12.5312C10.744 12.5104 9.68155 12.0729 8.78571 11.2188Z"
      />
    </symbol>`,
  "icon-link": `<symbol id="icon-link" viewBox="0 0 20 16">
      <path
        
        d="M18.6875 1.31321C19.5417 2.22988 19.9792 3.29238 20 4.50071C19.9792 5.68821 19.5417 6.75071 18.6875 7.68821L15.1562 11.2195C14.2604 12.0736 13.1979 12.5111 11.9688 12.532C10.7396 12.5111 9.67708 12.0736 8.78125 11.2195C7.92708 10.3236 7.48958 9.26113 7.46875 8.03196C7.46875 7.30279 7.63542 6.62571 7.96875 6.00071C7.98958 6.00071 8 6.00071 8 6.00071C8.02083 6.00071 8.03125 6.00071 8.03125 6.00071C8.57292 6.00071 9.03125 6.16738 9.40625 6.50071C9.11458 6.95904 8.96875 7.46946 8.96875 8.03196C8.96875 8.86529 9.26042 9.57363 9.84375 10.157C10.4479 10.7195 11.1562 11.0007 11.9688 11.0007C12.7812 11.0007 13.4896 10.7195 14.0938 10.157L17.625 6.62571C18.2083 6.00071 18.5 5.29238 18.5 4.50071C18.5 3.70904 18.2083 3.00071 17.625 2.37571C17 1.79238 16.2917 1.50071 15.5 1.50071C14.7083 1.50071 14 1.79238 13.375 2.37571L11.7812 3.96946C11.4062 3.61529 10.9896 3.32363 10.5312 3.09446L12.3438 1.31321C13.2812 0.417377 14.3646 -0.0201231 15.5938 0.000710227C16.7604 0.0215436 17.7917 0.459044 18.6875 1.31321ZM6.625 13.5945L8.21875 12.032C8.59375 12.3861 9.01042 12.6778 9.46875 12.907L7.6875 14.6882C6.6875 15.6257 5.54167 16.0632 4.25 16.0007C3.14583 15.9382 2.16667 15.5007 1.3125 14.6882C0.4375 13.7715 0 12.709 0 11.5007C0 10.3132 0.4375 9.25071 1.3125 8.31321L4.84375 4.75071C5.73958 3.89654 6.80208 3.45904 8.03125 3.43821C9.26042 3.45904 10.3229 3.89654 11.2188 4.75071C12.0729 5.64654 12.5104 6.70904 12.5312 7.93821C12.5312 8.66738 12.3646 9.34446 12.0312 9.96946C12.0104 9.96946 12 9.96946 12 9.96946C11.9792 9.96946 11.9688 9.96946 11.9688 9.96946C11.4271 9.96946 10.9688 9.80279 10.5938 9.46946C10.8854 9.01113 11.0312 8.50071 11.0312 7.93821C11.0312 7.12571 10.7396 6.41738 10.1562 5.81321C9.55208 5.25071 8.84375 4.96946 8.03125 4.96946C7.21875 4.96946 6.51042 5.25071 5.90625 5.81321L2.375 9.34446C1.79167 9.96946 1.5 10.6778 1.5 11.4695C1.5 12.282 1.79167 12.9903 2.375 13.5945C3 14.1778 3.70833 14.4695 4.5 14.4695C5.29167 14.4695 6 14.1778 6.625 13.5945Z"
      />
    </symbol>`,
  "icon-table-list": `<symbol id="icon-table-list" viewBox="0 0 16 16">
      <path
        
        d="M14 1C14.5625 1.02083 15.0312 1.21875 15.4062 1.59375C15.7812 1.96875 15.9792 2.4375 16 3V13C15.9792 13.5625 15.7812 14.0312 15.4062 14.4062C15.0312 14.7812 14.5625 14.9792 14 15H2C1.4375 14.9792 0.96875 14.7812 0.59375 14.4062C0.21875 14.0312 0.0208333 13.5625 0 13V3C0.0208333 2.4375 0.21875 1.96875 0.59375 1.59375C0.96875 1.21875 1.4375 1.02083 2 1H14ZM14.5 3C14.4792 2.6875 14.3125 2.52083 14 2.5H5.75V5.25H14.5V3ZM5.75 6.75V9.25H14.5V6.75H5.75ZM4.25 9.25V6.75H1.5V9.25H4.25ZM2 2.5C1.6875 2.52083 1.52083 2.6875 1.5 3V5.25H4.25V2.5H2ZM1.5 13C1.52083 13.3125 1.6875 13.4792 2 13.5H4.25V10.75H1.5V13ZM14 13.5C14.3125 13.4792 14.4792 13.3125 14.5 13V10.75H5.75V13.5H14Z"
      />
    </symbol>`,
  "icon-arrow-left-standard": `<symbol id="icon-arrow-left-standard" class="arrow-left-regular" viewBox="0 0 448 512">
      <path
        
        d="M447.1 256c0 13.25-10.76 24.01-24.01 24.01H83.9l132.7 126.6c9.625 9.156 9.969 24.41 .8125 33.94c-9.156 9.594-24.34 9.938-33.94 .8125l-176-168C2.695 268.9 .0078 262.6 .0078 256S2.695 243.2 7.445 238.6l176-168C193 61.51 208.2 61.85 217.4 71.45c9.156 9.5 8.812 24.75-.8125 33.94l-132.7 126.6h340.1C437.2 232 447.1 242.8 447.1 256z"
      />
    </symbol>`,
  "icon-arrow-right-standard": `<symbol id="icon-arrow-right-standard" class="arrow-right-regular" viewBox="0 0 448 512">
      <path
        
        d="M264.6 70.63l176 168c4.75 4.531 7.438 10.81 7.438 17.38s-2.688 12.84-7.438 17.38l-176 168c-9.594 9.125-24.78 8.781-33.94-.8125c-9.156-9.5-8.812-24.75 .8125-33.94l132.7-126.6H24.01c-13.25 0-24.01-10.76-24.01-24.01s10.76-23.99 24.01-23.99h340.1l-132.7-126.6C221.8 96.23 221.5 80.98 230.6 71.45C239.8 61.85 254.1 61.51 264.6 70.63z"
      />
    </symbol>`,
  "icon-arrow-down-standard": `<symbol id="icon-arrow-down-standard" class="arrow-down-regular" viewBox="0 0 384 512">
      <path
        
        d="M377.4 296.6l-168 176C204.8 477.3 198.6 480 192 480s-12.84-2.688-17.38-7.438l-168-176C-2.5 286.1-2.156 271.8 7.438 262.6c9.5-9.156 24.75-8.812 33.94 .8125L168 396.1V56.02c0-13.25 10.75-24.01 23.1-24.01S216 42.77 216 56.02v340.1l126.6-132.7c9.156-9.625 24.41-9.969 33.94-.8125C386.2 271.8 386.5 286.1 377.4 296.6z"
      />
    </symbol>`,
  "icon-arrow-up-standard": `<symbol id="icon-arrow-up-standard" class="arrow-up-regular" viewBox="0 0 384 512">
      <path
        
        d="M6.625 215.5l168-176C179.2 34.7 185.4 32.02 192 32.02s12.84 2.688 17.38 7.438l168 176c9.125 9.594 8.781 24.78-.8125 33.94c-9.5 9.156-24.75 8.812-33.94-.8125L216 115.9V456c0 13.25-10.75 23.1-23.1 23.1S168 469.3 168 456V115.9l-126.6 132.7C32.22 258.2 16.97 258.5 7.438 249.4C-2.156 240.2-2.5 225 6.625 215.5z"
      />
    </symbol>`,
  "icon-arrow-right-arrow-left": `<symbol id="icon-arrow-right-arrow-left" viewBox="0 0 17 16">
      <path
        
        d="M15.25 10.75C15.7083 10.7917 15.9583 11.0417 16 11.5C15.9583 11.9583 15.7083 12.2083 15.25 12.25H2.46875L4.8125 14.75C5.08333 15.1042 5.0625 15.4583 4.75 15.8125C4.60417 15.9375 4.4375 16 4.25 16C4.04167 16 3.86458 15.9167 3.71875 15.75L0.21875 12C-0.0520833 11.6667 -0.0520833 11.3333 0.21875 11L3.71875 7.25C4.05208 6.9375 4.39583 6.92708 4.75 7.21875C5.0625 7.55208 5.08333 7.89583 4.8125 8.25L2.46875 10.75H15.25ZM0.75 5.25C0.291667 5.20833 0.0416667 4.95833 0 4.5C0.0416667 4.04167 0.291667 3.79167 0.75 3.75H13.5312L11.1875 1.25C10.9167 0.895833 10.9375 0.541667 11.25 0.1875C11.3958 0.0625 11.5625 0 11.75 0C11.9583 0 12.1458 0.0833333 12.3125 0.25L15.8125 4C16.0833 4.33333 16.0833 4.66667 15.8125 5L12.3125 8.75C11.9583 9.0625 11.6042 9.08333 11.25 8.8125C10.9375 8.45833 10.9271 8.10417 11.2188 7.75L13.5312 5.25H0.75Z"
      />
    </symbol>`,
  "icon-turn-down-left": `<symbol id="icon-turn-down-left" viewBox="0 0 512 512">
      <path
        
        d="M119.7 409.6l-112-104c-10.23-9.5-10.23-25.69 0-35.19l112-104c6.984-6.484 17.17-8.219 25.92-4.406s14.41 12.45 14.41 22L159.1 264h304V56c0-13.25 10.75-24 24-24s24 10.75 24 24V288c0 13.25-10.75 24-24 24h-328l.0015 80c0 9.547-5.656 18.19-14.41 22S126.7 416.1 119.7 409.6z"
      />
    </symbol>`,
  "icon-grid-dividers": `<symbol id="icon-grid-dividers" viewBox="0 0 16 16">
      <path
        
        d="M0.75 1.5C0.291667 1.45833 0.0416667 1.20833 0 0.75C0.0416667 0.291667 0.291667 0.0416667 0.75 0H15.25C15.7083 0.0416667 15.9583 0.291667 16 0.75C15.9583 1.20833 15.7083 1.45833 15.25 1.5H0.75ZM12 3H14C14.2917 3 14.5312 3.09375 14.7188 3.28125C14.9062 3.46875 15 3.70833 15 4V6C15 6.29167 14.9062 6.53125 14.7188 6.71875C14.5312 6.90625 14.2917 7 14 7H12C11.7083 7 11.4688 6.90625 11.2812 6.71875C11.0938 6.53125 11 6.29167 11 6V4C11 3.70833 11.0938 3.46875 11.2812 3.28125C11.4688 3.09375 11.7083 3 12 3ZM13.5 5.5V4.5H12.5V5.5H13.5ZM7 3H9C9.29167 3 9.53125 3.09375 9.71875 3.28125C9.90625 3.46875 10 3.70833 10 4V6C10 6.29167 9.90625 6.53125 9.71875 6.71875C9.53125 6.90625 9.29167 7 9 7H7C6.70833 7 6.46875 6.90625 6.28125 6.71875C6.09375 6.53125 6 6.29167 6 6V4C6 3.70833 6.09375 3.46875 6.28125 3.28125C6.46875 3.09375 6.70833 3 7 3ZM8.5 5.5V4.5H7.5V5.5H8.5ZM2 3H4C4.29167 3 4.53125 3.09375 4.71875 3.28125C4.90625 3.46875 5 3.70833 5 4V6C5 6.29167 4.90625 6.53125 4.71875 6.71875C4.53125 6.90625 4.29167 7 4 7H2C1.70833 7 1.46875 6.90625 1.28125 6.71875C1.09375 6.53125 1 6.29167 1 6V4C1 3.70833 1.09375 3.46875 1.28125 3.28125C1.46875 3.09375 1.70833 3 2 3ZM3.5 5.5V4.5H2.5V5.5H3.5ZM15.25 9C15.7083 9.04167 15.9583 9.29167 16 9.75C15.9583 10.2083 15.7083 10.4583 15.25 10.5H0.75C0.291667 10.4583 0.0416667 10.2083 0 9.75C0.0416667 9.29167 0.291667 9.04167 0.75 9H15.25ZM9 12C9.29167 12 9.53125 12.0938 9.71875 12.2812C9.90625 12.4688 10 12.7083 10 13V15C10 15.2917 9.90625 15.5312 9.71875 15.7188C9.53125 15.9062 9.29167 16 9 16H7C6.70833 16 6.46875 15.9062 6.28125 15.7188C6.09375 15.5312 6 15.2917 6 15V13C6 12.7083 6.09375 12.4688 6.28125 12.2812C6.46875 12.0938 6.70833 12 7 12H9ZM8.5 14.5V13.5H7.5V14.5H8.5ZM14 12C14.2917 12 14.5312 12.0938 14.7188 12.2812C14.9062 12.4688 15 12.7083 15 13V15C15 15.2917 14.9062 15.5312 14.7188 15.7188C14.5312 15.9062 14.2917 16 14 16H12C11.7083 16 11.4688 15.9062 11.2812 15.7188C11.0938 15.5312 11 15.2917 11 15V13C11 12.7083 11.0938 12.4688 11.2812 12.2812C11.4688 12.0938 11.7083 12 12 12H14ZM13.5 14.5V13.5H12.5V14.5H13.5ZM4 12C4.29167 12 4.53125 12.0938 4.71875 12.2812C4.90625 12.4688 5 12.7083 5 13V15C5 15.2917 4.90625 15.5312 4.71875 15.7188C4.53125 15.9062 4.29167 16 4 16H2C1.70833 16 1.46875 15.9062 1.28125 15.7188C1.09375 15.5312 1 15.2917 1 15V13C1 12.7083 1.09375 12.4688 1.28125 12.2812C1.46875 12.0938 1.70833 12 2 12H4ZM3.5 14.5V13.5H2.5V14.5H3.5Z"
      />
    </symbol>`,
  "icon-plane-engines": `<symbol id="icon-plane-engines" viewBox="0 0 18 16">
      <path
        
        d="M11.9062 5.5H14.4688C14.9062 5.5 15.3958 5.60417 15.9375 5.8125C16.4792 6.02083 16.9479 6.3125 17.3438 6.6875C17.7604 7.0625 17.9792 7.5 18 8C17.9792 8.52083 17.7604 8.96875 17.3438 9.34375C16.9479 9.69792 16.4792 9.97917 15.9375 10.1875C15.3958 10.3958 14.9167 10.5 14.5 10.5H11.9375L10.9375 12.0938C11.2917 12.2812 11.4792 12.5833 11.5 13C11.5 13.2917 11.4062 13.5312 11.2188 13.7188C11.0312 13.9062 10.7917 14 10.5 14H9.75L8.8125 15.5C8.625 15.8333 8.33333 16 7.9375 16H5.9375C5.60417 16 5.33333 15.875 5.125 15.625C4.91667 15.3333 4.86458 15.0312 4.96875 14.7188L6.3125 10.5H4.78125L3.5625 12.125C3.35417 12.375 3.09375 12.5 2.78125 12.5H1C0.6875 12.5 0.427083 12.375 0.21875 12.125C0.03125 11.875 -0.0208333 11.5833 0.0625 11.25L0.71875 8.96875C0.28125 8.80208 0.0416667 8.47917 0 8C0.0208333 7.52083 0.260417 7.19792 0.71875 7.03125L0.03125 4.75C-0.03125 4.45833 0.03125 4.17708 0.21875 3.90625C0.427083 3.65625 0.6875 3.52083 1 3.5H2.78125C3.09375 3.52083 3.35417 3.65625 3.5625 3.90625L4.78125 5.5H6.3125L4.96875 1.28125C4.86458 0.96875 4.91667 0.677083 5.125 0.40625C5.33333 0.15625 5.60417 0.0208333 5.9375 0H7.9375C8.33333 0.0208333 8.61458 0.1875 8.78125 0.5L9.71875 2H10.5C10.7917 2 11.0312 2.09375 11.2188 2.28125C11.4062 2.46875 11.5 2.70833 11.5 3C11.4792 3.41667 11.2812 3.71875 10.9062 3.90625L11.9062 5.5ZM11.0938 9H14.4688C14.9271 8.97917 15.3646 8.85417 15.7812 8.625C16.1979 8.39583 16.4271 8.1875 16.4688 8C16.4062 7.8125 16.1667 7.60417 15.75 7.375C15.3333 7.14583 14.9062 7.02083 14.4688 7H11.0938L7.65625 1.5H6.625L8.3125 7H4.03125L2.53125 5H1.6875L2.5625 8L1.6875 11H2.53125L4.03125 9H8.3125L6.625 14.5H7.65625L11.0938 9Z"
      />
    </symbol>`,
  "icon-satellite-dish": `<symbol id="icon-satellite-dish" viewBox="0 0 16 16">
      <path
        
        d="M6.3125 10.7812L9.28125 13.75C9.44792 13.9167 9.52083 14.1146 9.5 14.3438C9.47917 14.5729 9.375 14.75 9.1875 14.875C8.16667 15.625 7.03125 16 5.78125 16C4.13542 15.9583 2.77083 15.3958 1.6875 14.3125C0.604167 13.2292 0.0416667 11.8646 0 10.2188C0 8.96875 0.375 7.83333 1.125 6.8125C1.25 6.625 1.42708 6.52083 1.65625 6.5C1.88542 6.5 2.08333 6.57292 2.25 6.71875L5.25 9.71875L6.71875 8.21875C7.07292 7.92708 7.42708 7.92708 7.78125 8.21875C8.07292 8.57292 8.07292 8.92708 7.78125 9.28125L6.3125 10.7812ZM5.78125 14.5C6.40625 14.5 6.98958 14.375 7.53125 14.125L1.875 8.46875C1.625 9.01042 1.5 9.59375 1.5 10.2188C1.52083 11.4271 1.9375 12.4375 2.75 13.25C3.5625 14.0625 4.57292 14.4792 5.78125 14.5ZM6.75 0C8.47917 0.0208333 10.0312 0.4375 11.4062 1.25C12.8021 2.08333 13.9167 3.19792 14.75 4.59375C15.5625 5.96875 15.9792 7.52083 16 9.25C15.9583 9.70833 15.7083 9.95833 15.25 10C14.7917 9.95833 14.5417 9.70833 14.5 9.25C14.4792 7.8125 14.125 6.51042 13.4375 5.34375C12.75 4.17708 11.8229 3.25 10.6562 2.5625C9.48958 1.875 8.1875 1.52083 6.75 1.5C6.29167 1.45833 6.04167 1.20833 6 0.75C6.04167 0.291667 6.29167 0.0416667 6.75 0ZM6.75 3.25C8.4375 3.29167 9.85417 3.875 11 5C12.125 6.14583 12.7083 7.5625 12.75 9.25C12.7083 9.70833 12.4583 9.95833 12 10C11.5417 9.95833 11.2917 9.70833 11.25 9.25C11.2083 7.97917 10.7708 6.91667 9.9375 6.0625C9.08333 5.22917 8.02083 4.79167 6.75 4.75C6.29167 4.70833 6.04167 4.45833 6 4C6.04167 3.54167 6.29167 3.29167 6.75 3.25Z"
      />
    </symbol>`,
  "icon-grid": `<symbol id="icon-grid" viewBox="0 0 16 16">
      <path
        
        d="M4 1C4.29167 1 4.53125 1.09375 4.71875 1.28125C4.90625 1.46875 5 1.70833 5 2V4C5 4.29167 4.90625 4.53125 4.71875 4.71875C4.53125 4.90625 4.29167 5 4 5H2C1.70833 5 1.46875 4.90625 1.28125 4.71875C1.09375 4.53125 1 4.29167 1 4V2C1 1.70833 1.09375 1.46875 1.28125 1.28125C1.46875 1.09375 1.70833 1 2 1H4ZM9 1C9.29167 1 9.53125 1.09375 9.71875 1.28125C9.90625 1.46875 10 1.70833 10 2V4C10 4.29167 9.90625 4.53125 9.71875 4.71875C9.53125 4.90625 9.29167 5 9 5H7C6.70833 5 6.46875 4.90625 6.28125 4.71875C6.09375 4.53125 6 4.29167 6 4V2C6 1.70833 6.09375 1.46875 6.28125 1.28125C6.46875 1.09375 6.70833 1 7 1H9ZM14 1C14.2917 1 14.5312 1.09375 14.7188 1.28125C14.9062 1.46875 15 1.70833 15 2V4C15 4.29167 14.9062 4.53125 14.7188 4.71875C14.5312 4.90625 14.2917 5 14 5H12C11.7083 5 11.4688 4.90625 11.2812 4.71875C11.0938 4.53125 11 4.29167 11 4V2C11 1.70833 11.0938 1.46875 11.2812 1.28125C11.4688 1.09375 11.7083 1 12 1H14ZM4 11C4.29167 11 4.53125 11.0938 4.71875 11.2812C4.90625 11.4688 5 11.7083 5 12V14C5 14.2917 4.90625 14.5312 4.71875 14.7188C4.53125 14.9062 4.29167 15 4 15H2C1.70833 15 1.46875 14.9062 1.28125 14.7188C1.09375 14.5312 1 14.2917 1 14V12C1 11.7083 1.09375 11.4688 1.28125 11.2812C1.46875 11.0938 1.70833 11 2 11H4ZM9 11C9.29167 11 9.53125 11.0938 9.71875 11.2812C9.90625 11.4688 10 11.7083 10 12V14C10 14.2917 9.90625 14.5312 9.71875 14.7188C9.53125 14.9062 9.29167 15 9 15H7C6.70833 15 6.46875 14.9062 6.28125 14.7188C6.09375 14.5312 6 14.2917 6 14V12C6 11.7083 6.09375 11.4688 6.28125 11.2812C6.46875 11.0938 6.70833 11 7 11H9ZM14 11C14.2917 11 14.5312 11.0938 14.7188 11.2812C14.9062 11.4688 15 11.7083 15 12V14C15 14.2917 14.9062 14.5312 14.7188 14.7188C14.5312 14.9062 14.2917 15 14 15H12C11.7083 15 11.4688 14.9062 11.2812 14.7188C11.0938 14.5312 11 14.2917 11 14V12C11 11.7083 11.0938 11.4688 11.2812 11.2812C11.4688 11.0938 11.7083 11 12 11H14ZM4 6C4.29167 6 4.53125 6.09375 4.71875 6.28125C4.90625 6.46875 5 6.70833 5 7V9C5 9.29167 4.90625 9.53125 4.71875 9.71875C4.53125 9.90625 4.29167 10 4 10H2C1.70833 10 1.46875 9.90625 1.28125 9.71875C1.09375 9.53125 1 9.29167 1 9V7C1 6.70833 1.09375 6.46875 1.28125 6.28125C1.46875 6.09375 1.70833 6 2 6H4ZM9 6C9.29167 6 9.53125 6.09375 9.71875 6.28125C9.90625 6.46875 10 6.70833 10 7V9C10 9.29167 9.90625 9.53125 9.71875 9.71875C9.53125 9.90625 9.29167 10 9 10H7C6.70833 10 6.46875 9.90625 6.28125 9.71875C6.09375 9.53125 6 9.29167 6 9V7C6 6.70833 6.09375 6.46875 6.28125 6.28125C6.46875 6.09375 6.70833 6 7 6H9ZM14 6C14.2917 6 14.5312 6.09375 14.7188 6.28125C14.9062 6.46875 15 6.70833 15 7V9C15 9.29167 14.9062 9.53125 14.7188 9.71875C14.5312 9.90625 14.2917 10 14 10H12C11.7083 10 11.4688 9.90625 11.2812 9.71875C11.0938 9.53125 11 9.29167 11 9V7C11 6.70833 11.0938 6.46875 11.2812 6.28125C11.4688 6.09375 11.7083 6 12 6H14Z"
      />
    </symbol>`,
  "icon-square": `<symbol id="icon-square" viewBox="0 0 16 16">
      <path
        
        d="M13.7143 1.71429C14.0286 1.71429 14.2857 1.97143 14.2857 2.28571V13.7143C14.2857 14.0286 14.0286 14.2857 13.7143 14.2857H2.28571C1.97143 14.2857 1.71429 14.0286 1.71429 13.7143V2.28571C1.71429 1.97143 1.97143 1.71429 2.28571 1.71429H13.7143ZM2.28571 0C1.025 0 0 1.025 0 2.28571V13.7143C0 14.975 1.025 16 2.28571 16H13.7143C14.975 16 16 14.975 16 13.7143V2.28571C16 1.025 14.975 0 13.7143 0H2.28571Z"
      />
    </symbol>`,
  "icon-square-check": `<symbol id="icon-square-check" viewBox="0 0 16 16">
      <path
        
        d="M2.28571 0C1.025 0 0 1.025 0 2.28571V13.7143C0 14.975 1.025 16 2.28571 16H13.7143C14.975 16 16 14.975 16 13.7143V2.28571C16 1.025 14.975 0 13.7143 0H2.28571ZM12.0357 6.32143L7.46429 10.8929C7.12857 11.2286 6.58571 11.2286 6.25357 10.8929L3.96786 8.60714C3.63214 8.27143 3.63214 7.72857 3.96786 7.39643C4.30357 7.06429 4.84643 7.06071 5.17857 7.39643L6.85714 9.075L10.8214 5.10714C11.1571 4.77143 11.7 4.77143 12.0321 5.10714C12.3643 5.44286 12.3679 5.98571 12.0321 6.31786L12.0357 6.32143Z"
      />
    </symbol>`,
  "icon-square-minus": `<symbol id="icon-square-minus" viewBox="0 0 16 16">
      <path
        
        d="M2.28571 0C1.025 0 0 1.025 0 2.28571V13.7143C0 14.975 1.025 16 2.28571 16H13.7143C14.975 16 16 14.975 16 13.7143V2.28571C16 1.025 14.975 0 13.7143 0H2.28571ZM5.42857 7.14286H10.5714C11.0464 7.14286 11.4286 7.525 11.4286 8C11.4286 8.475 11.0464 8.85714 10.5714 8.85714H5.42857C4.95357 8.85714 4.57143 8.475 4.57143 8C4.57143 7.525 4.95357 7.14286 5.42857 7.14286Z"
      />
    </symbol>`,
  "icon-circle": `<symbol id="icon-circle" viewBox="0 0 16 16">
      <path
        
        d="M14.5 8C14.5 6.27609 13.8152 4.62279 12.5962 3.40381C11.3772 2.18482 9.72391 1.5 8 1.5C6.27609 1.5 4.62279 2.18482 3.40381 3.40381C2.18482 4.62279 1.5 6.27609 1.5 8C1.5 9.72391 2.18482 11.3772 3.40381 12.5962C4.62279 13.8152 6.27609 14.5 8 14.5C9.72391 14.5 11.3772 13.8152 12.5962 12.5962C13.8152 11.3772 14.5 9.72391 14.5 8ZM0 8C0 5.87827 0.842855 3.84344 2.34315 2.34315C3.84344 0.842855 5.87827 0 8 0C10.1217 0 12.1566 0.842855 13.6569 2.34315C15.1571 3.84344 16 5.87827 16 8C16 10.1217 15.1571 12.1566 13.6569 13.6569C12.1566 15.1571 10.1217 16 8 16C5.87827 16 3.84344 15.1571 2.34315 13.6569C0.842855 12.1566 0 10.1217 0 8Z"
      />
    </symbol>`,
  "icon-circle-dot": `<symbol id="icon-circle-dot" viewBox="0 0 16 16">
      <path
        
        d="M14.5 8C14.5 6.27609 13.8152 4.62279 12.5962 3.40381C11.3772 2.18482 9.72391 1.5 8 1.5C6.27609 1.5 4.62279 2.18482 3.40381 3.40381C2.18482 4.62279 1.5 6.27609 1.5 8C1.5 9.72391 2.18482 11.3772 3.40381 12.5962C4.62279 13.8152 6.27609 14.5 8 14.5C9.72391 14.5 11.3772 13.8152 12.5962 12.5962C13.8152 11.3772 14.5 9.72391 14.5 8ZM0 8C0 5.87827 0.842855 3.84344 2.34315 2.34315C3.84344 0.842855 5.87827 0 8 0C10.1217 0 12.1566 0.842855 13.6569 2.34315C15.1571 3.84344 16 5.87827 16 8C16 10.1217 15.1571 12.1566 13.6569 13.6569C12.1566 15.1571 10.1217 16 8 16C5.87827 16 3.84344 15.1571 2.34315 13.6569C0.842855 12.1566 0 10.1217 0 8ZM8 5C8.79565 5 9.55871 5.31607 10.1213 5.87868C10.6839 6.44129 11 7.20435 11 8C11 8.79565 10.6839 9.55871 10.1213 10.1213C9.55871 10.6839 8.79565 11 8 11C7.20435 11 6.44129 10.6839 5.87868 10.1213C5.31607 9.55871 5 8.79565 5 8C5 7.20435 5.31607 6.44129 5.87868 5.87868C6.44129 5.31607 7.20435 5 8 5Z"
      />
    </symbol>`,
  "icon-circle-small": `<symbol id="icon-circle-small" viewBox="0 0 16 16">
      <path
        
        d="M5 8C5 7.20435 5.31607 6.44129 5.87868 5.87868C6.44129 5.31607 7.20435 5 8 5C8.79565 5 9.55871 5.31607 10.1213 5.87868C10.6839 6.44129 11 7.20435 11 8C11 8.79565 10.6839 9.55871 10.1213 10.1213C9.55871 10.6839 8.79565 11 8 11C7.20435 11 6.44129 10.6839 5.87868 10.1213C5.31607 9.55871 5 8.79565 5 8Z"
        fill="black"
      />
    </symbol>`,
  "icon-heart": `<symbol id="icon-heart" viewBox="0 0 16 16">
      <path
        
        d="M7.05625 13.6315L6.97813 13.5596L1.50312 8.4752C0.54375 7.58458 0 6.33458 0 5.0252V4.92208C0 2.72208 1.5625 0.834577 3.725 0.422077C4.95625 0.184577 6.21562 0.468952 7.21875 1.1752C7.5 1.3752 7.7625 1.60645 8 1.87208C8.13125 1.72208 8.27188 1.58458 8.42188 1.45645C8.5375 1.35645 8.65625 1.2627 8.78125 1.1752C9.78438 0.468952 11.0437 0.184577 12.275 0.418952C14.4375 0.831452 16 2.72208 16 4.92208V5.0252C16 6.33458 15.4563 7.58458 14.4969 8.4752L9.02188 13.5596L8.94375 13.6315C8.6875 13.869 8.35 14.0033 8 14.0033C7.65 14.0033 7.3125 13.8721 7.05625 13.6315ZM7.47188 3.53145C7.45938 3.52208 7.45 3.50958 7.44063 3.49708L6.88438 2.87208L6.88125 2.86895C6.15937 2.05958 5.06875 1.69083 4.00625 1.89395C2.55 2.17208 1.5 3.44083 1.5 4.92208V5.0252C1.5 5.91583 1.87188 6.76895 2.525 7.3752L8 12.4596L13.475 7.3752C14.1281 6.76895 14.5 5.91583 14.5 5.0252V4.92208C14.5 3.44395 13.45 2.17208 11.9969 1.89395C10.9344 1.69083 9.84062 2.0627 9.12187 2.86895C9.12187 2.86895 9.12187 2.86895 9.11875 2.87208C9.11562 2.8752 9.11875 2.87208 9.11563 2.8752L8.55937 3.5002C8.55 3.5127 8.5375 3.52208 8.52812 3.53458C8.3875 3.6752 8.19687 3.75333 8 3.75333C7.80312 3.75333 7.6125 3.6752 7.47188 3.53458V3.53145Z"
      />
    </symbol>`,
  "icon-highlighter-line": `<symbol id="icon-highlighter-line" viewBox="0 0 18 16">
      <path
        
        d="M7.15625 7.15625L13.875 2.20625L14.7906 3.12188L9.84375 9.84375L7.15625 7.15625ZM4 10L3.20625 10.7937C2.81562 11.1844 2.81562 11.8188 3.20625 12.2094L4.79062 13.7937C5.18125 14.1844 5.81562 14.1844 6.20625 13.7937L7 13H9.24062C9.71875 13 10.1656 12.775 10.4469 12.3906L16.7375 3.85625C16.9094 3.625 17 3.34375 17 3.05625C17 2.7 16.8594 2.35625 16.6063 2.10313L14.8937 0.39375C14.6406 0.140625 14.3 0 13.9437 0C13.6562 0 13.375 0.090625 13.1437 0.2625L4.60937 6.55C4.225 6.83125 4 7.28125 4 7.75625V10ZM2.19062 12.6031L0.221874 14.5719C0.0812492 14.7125 0.00312424 14.9031 0.00312424 15.1031V15.25C0.00312424 15.6656 0.337499 16 0.753124 16H2.89687C3.09687 16 3.2875 15.9219 3.42812 15.7812L4.39687 14.8125L2.19062 12.6031ZM7 14.5C6.58437 14.5 6.25 14.8344 6.25 15.25C6.25 15.6656 6.58437 16 7 16H17.25C17.6656 16 18 15.6656 18 15.25C18 14.8344 17.6656 14.5 17.25 14.5H7Z"
      />
    </symbol>`,
  "icon-comment-check": `<symbol id="icon-comment-check" viewBox="0 0 16 16">
      <path
        
        d="M5.25317 12.0281C4.7847 11.8594 4.26313 11.9312 3.86024 12.2281C3.60414 12.4156 3.16377 12.6906 2.62971 12.9375C2.80461 12.4781 2.9389 11.9594 2.98263 11.3938C3.01386 10.9906 2.87956 10.5906 2.61409 10.2844C1.88639 9.4625 1.49912 8.5 1.49912 7.5C1.49912 5.01562 4.10072 2.5 7.99532 2.5C11.8899 2.5 14.4915 5.01562 14.4915 7.5C14.4915 9.98438 11.8899 12.5 7.99532 12.5C7.00839 12.5 6.08081 12.3281 5.25317 12.0281ZM0.821394 13.2437C0.771423 13.3281 0.718329 13.4125 0.662112 13.4969L0.652743 13.5125C0.602772 13.5844 0.552801 13.6562 0.50283 13.7281C0.393519 13.875 0.274839 14.0187 0.149912 14.15C0.00624635 14.2937 -0.0343549 14.5063 0.0437244 14.6938C0.121804 14.8813 0.302948 15.0031 0.505954 15.0031C0.665235 15.0031 0.824517 14.9937 0.983799 14.9781L1.00566 14.975C1.14308 14.9594 1.2805 14.9406 1.41792 14.9156C1.4429 14.9125 1.46789 14.9062 1.49288 14.9C2.0488 14.7906 2.58286 14.6031 3.05758 14.3969C3.77279 14.0844 4.38181 13.7125 4.75346 13.4406C5.74663 13.8 6.84599 14 8.00468 14C12.4208 14 16 11.0906 16 7.5C16 3.90937 12.4115 1 7.99532 1C3.57915 1 0 3.90937 0 7.5C0 8.90938 0.552801 10.2125 1.48975 11.2781C1.43041 12.0437 1.13371 12.725 0.821394 13.2437ZM11.5245 6.03125C11.8181 5.7375 11.8181 5.2625 11.5245 4.97188C11.2309 4.68125 10.7562 4.67813 10.4657 4.97188L6.99902 8.44063L5.53113 6.97188C5.23756 6.67813 4.76283 6.67813 4.47238 6.97188C4.18192 7.26562 4.1788 7.74062 4.47238 8.03125L6.47121 10.0312C6.76479 10.325 7.23951 10.325 7.52996 10.0312L11.5245 6.03125Z"
      />
    </symbol>`,
  "icon-sidebar": `<symbol id="icon-sidebar" viewBox="0 0 16 16">
      <path
        
        fill-rule="evenodd"
        clip-rule="evenodd"
        d="M7 13.5V2.5H14C14.275 2.5 14.5 2.725 14.5 3V13C14.5 13.275 14.275 13.5 14 13.5H7ZM2 1C0.896875 1 0 1.89688 0 3V13C0 14.1031 0.896875 15 2 15H14C15.1031 15 16 14.1031 16 13V3C16 1.89688 15.1031 1 14 1H2ZM2.75 4.5C2.33437 4.5 2 4.16563 2 3.75C2 3.33437 2.33437 3 2.75 3H4.25C4.66563 3 5 3.33437 5 3.75C5 4.16563 4.66563 4.5 4.25 4.5H2.75ZM2 6.75C2 6.33437 2.33437 6 2.75 6H4.25C4.66563 6 5 6.33437 5 6.75C5 7.16563 4.66563 7.5 4.25 7.5H2.75C2.33437 7.5 2 7.16563 2 6.75ZM2.75 10.5C2.33437 10.5 2 10.1656 2 9.75C2 9.33438 2.33437 9 2.75 9H4.25C4.66563 9 5 9.33438 5 9.75C5 10.1656 4.66563 10.5 4.25 10.5H2.75ZM12.9577 8.49736C13.1302 8.4856 13.4217 8.46573 13.4217 8C13.4217 7.53532 13.1251 7.51449 12.9575 7.50272C12.9448 7.50182 12.9328 7.50098 12.9217 7.5H9.9217L10.5 6.5C10.6044 6.38889 10.5317 6.19792 10.4273 6.07292C10.308 5.97569 10.1812 5.97569 10.047 6.07292L8.0783 7.82292C8.0261 7.87153 8 7.93056 8 8C8 8.06944 8.0261 8.12847 8.0783 8.17708L10.047 9.92708C10.1812 10.0243 10.308 10.0243 10.4273 9.92708C10.5317 9.80208 10.6044 9.61111 10.5 9.5L10 8.5H12.9217C12.9329 8.49905 12.945 8.49823 12.9577 8.49736Z"
      />
    </symbol>`,
  "icon-sidebar-flip": `<symbol id="icon-sidebar-flip" viewBox="0 0 16 16">
      <path
        
        fill-rule="evenodd"
        clip-rule="evenodd"
        d="M2 13.5H9V2.5H2C1.725 2.5 1.5 2.725 1.5 3V13C1.5 13.275 1.725 13.5 2 13.5ZM14 1C15.1031 1 16 1.89688 16 3V13C16 14.1031 15.1031 15 14 15H2C0.896875 15 0 14.1031 0 13V3C0 1.89688 0.896875 1 2 1H14ZM13.25 4.5C13.6656 4.5 14 4.16563 14 3.75C14 3.33437 13.6656 3 13.25 3H11.75C11.3344 3 11 3.33437 11 3.75C11 4.16563 11.3344 4.5 11.75 4.5H13.25ZM14 6.75C14 6.33437 13.6656 6 13.25 6H11.75C11.3344 6 11 6.33437 11 6.75C11 7.16563 11.3344 7.5 11.75 7.5H13.25C13.6656 7.5 14 7.16563 14 6.75ZM13.25 10.5C13.6656 10.5 14 10.1656 14 9.75C14 9.33438 13.6656 9 13.25 9H11.75C11.3344 9 11 9.33438 11 9.75C11 10.1656 11.3344 10.5 11.75 10.5H13.25ZM3.04232 8.49736C2.86978 8.4856 2.57831 8.46573 2.57831 8C2.57831 7.53532 2.8749 7.51449 3.04251 7.50272C3.05525 7.50182 3.06724 7.50098 3.07831 7.5H6.0783L5.5 6.5C5.3956 6.38889 5.46831 6.19792 5.57271 6.07292C5.69202 5.97569 5.81879 5.97569 5.95302 6.07292L7.9217 7.82292C7.9739 7.87153 8 7.93056 8 8C8 8.06944 7.9739 8.12847 7.9217 8.17708L5.95302 9.92708C5.81879 10.0243 5.69202 10.0243 5.57271 9.92708C5.46831 9.80208 5.3956 9.61111 5.5 9.5L6 8.5H3.07831C3.06707 8.49905 3.05501 8.49823 3.04232 8.49736Z"
      />
    </symbol>`,
  "icon-photo-film": `<symbol id="icon-photo-film" viewBox="0 0 640 512">
      <path
        
        d="M256 48c-8.8 0-16 7.2-16 16l0 224c0 8.7 6.9 15.8 15.6 16l69.1-94.2c4.5-6.2 11.7-9.8 19.4-9.8s14.8 3.6 19.4 9.8L380 232.4l56-85.6c4.4-6.8 12-10.9 20.1-10.9s15.7 4.1 20.1 10.9L578.7 303.8c7.6-1.3 13.3-7.9 13.3-15.8l0-224c0-8.8-7.2-16-16-16L256 48zM192 64c0-35.3 28.7-64 64-64L576 0c35.3 0 64 28.7 64 64l0 224c0 35.3-28.7 64-64 64l-320 0c-35.3 0-64-28.7-64-64l0-224zm-56 64l24 0 0 48 0 88 0 112 0 8 0 80 192 0 0-80 48 0 0 80 48 0c8.8 0 16-7.2 16-16l0-64 48 0 0 64c0 35.3-28.7 64-64 64l-48 0-24 0-24 0-192 0-24 0-24 0-48 0c-35.3 0-64-28.7-64-64L0 192c0-35.3 28.7-64 64-64l48 0 24 0zm-24 48l-48 0c-8.8 0-16 7.2-16 16l0 48 64 0 0-64zm0 288l0-64-64 0 0 48c0 8.8 7.2 16 16 16l48 0zM48 352l64 0 0-64-64 0 0 64zM304 80a32 32 0 1 1 0 64 32 32 0 1 1 0-64z"
      />
    </symbol>`,
  "icon-icons": `<symbol id="icon-icons" viewBox="0 0 512 512">
      <path
        
        d="M59.6 54.4c11.1-9.4 30.8-8.7 43.5 3.7l8 8.1 17.5 17.8 17.1-18.3L153 58c12.5-12 31.7-13.1 43.8-3.4c14.2 12.1 14.8 33.3 2 46.2c0 0 0 0 0 0l-70.7 70.8-71-70.8s0 0 0 0C44.3 87.9 44.9 66.6 59.5 54.5c0 0 0 0 0 0l.1-.1zM28.8 17.6C-7.7 47.9-9.4 102 23.1 134.6c0 0 0 0 0 0L101.7 213c14.7 15.1 38.3 14.1 52.5 .4c0 0 0 0 0 0l.3-.3 78.3-78.5s0 0 0 0C265.4 102 263.6 48 227.6 17.7c0 0 0 0 0 0l-.3-.3c-29.9-24.3-71-21.9-99.3-1C99.7-4.4 58.2-7 28.8 17.6zM512 24c0-7.2-3.2-14-8.8-18.6s-12.9-6.4-19.9-5l-160 32C312.1 34.7 304 44.6 304 56l0 105.5c-5.1-1-10.5-1.5-16-1.5c-35.3 0-64 21.5-64 48s28.7 48 64 48s64-21.5 64-48l0-132.3L464 53.3l0 76.2c-5.1-1-10.5-1.5-16-1.5c-35.3 0-64 21.5-64 48s28.7 48 64 48s64-21.5 64-48l0-152zM106.9 309.5l2.7-5.5 68.7 0 2.7 5.5c8.1 16.3 24.8 26.5 42.9 26.5c8.8 0 16 7.2 16 16l0 96c0 8.8-7.2 16-16 16L64 464c-8.8 0-16-7.2-16-16l0-96c0-8.8 7.2-16 16-16c18.2 0 34.8-10.3 42.9-26.5zM224 288l-7.2-14.3c-5.4-10.8-16.5-17.7-28.6-17.7l-88.4 0c-12.1 0-23.2 6.8-28.6 17.7L64 288c-35.3 0-64 28.7-64 64l0 96c0 35.3 28.7 64 64 64l160 0c35.3 0 64-28.7 64-64l0-96c0-35.3-28.7-64-64-64zM192 392a48 48 0 1 0 -96 0 48 48 0 1 0 96 0zM473.4 259.1c-6-4.4-14.3-4-19.9 .9l-128 112c-5 4.4-6.8 11.4-4.4 17.7s8.3 10.4 15 10.4l55.7 0-38.4 89.7c-2.9 6.9-.7 14.9 5.3 19.2s14.3 4 19.9-.9l128-112c5-4.4 6.8-11.4 4.4-17.7s-8.3-10.4-15-10.4l-55.7 0 38.4-89.7c2.9-6.9 .7-14.9-5.3-19.2z"
      />
    </symbol>`,
  "icon-paper-plane": `<symbol id="icon-paper-plane" viewBox="0 0 512 512">
      <path
        
        d="M133.9 232L65.8 95.9 383.4 232l-249.5 0zm0 48l249.5 0L65.8 416.1l68-136.1zM44.6 34.6C32.3 29.3 17.9 32.3 8.7 42S-2.6 66.3 3.4 78.3L92.2 256 3.4 433.7c-6 12-3.9 26.5 5.3 36.3s23.5 12.7 35.9 7.5l448-192c11.8-5 19.4-16.6 19.4-29.4s-7.6-24.4-19.4-29.4l-448-192z"
      />
    </symbol>`,
  "icon-at": `<symbol id="icon-at" viewBox="0 0 512 512">
      <path
        
        d="M256 48C141.1 48 48 141.1 48 256s93.1 208 208 208c13.3 0 24 10.7 24 24s-10.7 24-24 24C114.6 512 0 397.4 0 256S114.6 0 256 0S512 114.6 512 256l0 28c0 50.8-41.2 92-92 92c-31.1 0-58.7-15.5-75.3-39.2C322.7 360.9 291.1 376 256 376c-66.3 0-120-53.7-120-120s53.7-120 120-120c28.8 0 55.2 10.1 75.8 27c4.3-6.6 11.7-11 20.2-11c13.3 0 24 10.7 24 24l0 80 0 28c0 24.3 19.7 44 44 44s44-19.7 44-44l0-28c0-114.9-93.1-208-208-208zm72 208a72 72 0 1 0 -144 0 72 72 0 1 0 144 0z"
      />
    </symbol>`
};
var h5 = Object.defineProperty, b5 = Object.getOwnPropertyDescriptor, d1 = (e, t, i, r) => {
  for (var a = r > 1 ? void 0 : r ? b5(t, i) : t, o = e.length - 1, s; o >= 0; o--)
    (s = e[o]) && (a = (r ? s(t, i, a) : s(a)) || a);
  return r && a && h5(t, i, a), a;
};
let D = class extends b {
  constructor() {
    super(), this._heightString = "height: 16px;", this._widthString = "width: 16px;";
  }
  render() {
    return n`
      ${Le(this._getSvgStringRef())}
      <span class="icon-container"
        >${Le(this._getHtml())}
        ${this.badge ? n`<span
              style="background-color: ${this.badge.backgroundColor}; color: ${this.badge.color};"
              class="badge"
              >${this.badge.label}</span
            >` : c}
      </span>
    `;
  }
  _getSvgStringRef() {
    const e = He[`icon-${this.icon}`];
    return e ? `
      <svg
        aria-hidden="true"
        style="position: absolute; width: 0; height: 0; overflow: hidden"
        version="1.1"
        xmlns="http://www.w3.org/2000/svg"
        xmlns:xlink="http://www.w3.org/1999/xlink"
      >
        <defs>
          ${e}
        </defs>
      </svg>
    ` : "";
  }
  _getSvgString(e) {
    return `<svg class="icon icon-${e}" style="${this._heightString}${this._widthString}${this.color ? `--atp-icon-fill:${this.color};` : ""}"><use xlink:href="#icon-${e}"></use></svg>`;
  }
  _setStyles() {
    this.height && (this._heightString = `height: ${this.height}px;`, this._widthString = `width: ${this.height}px;`);
  }
  _getHtml() {
    return this._setStyles(), He[`icon-${this.icon}`] ? this._getSvgString(this.icon) : this.icon ? this.icon.replace("<svg", `<svg style="${this._heightString}"`) : "";
  }
};
D.styles = [p5];
d1([
  l()
], D.prototype, "icon", 2);
d1([
  l({ type: Number })
], D.prototype, "height", 2);
d1([
  l()
], D.prototype, "color", 2);
d1([
  l()
], D.prototype, "hoverColor", 2);
d1([
  l()
], D.prototype, "pressedColor", 2);
d1([
  l({ type: Object })
], D.prototype, "badge", 2);
D = d1([
  u("atp-icon")
], D);
const u5 = g`
  :host {
    --atp-box-shadow-icon-clickable-background-hover-dark: hsl(0 0 0 / 0.34);
    --atp-box-shadow-icon-clickable-background-pressed-dark: hsl(0 0 0 / 0.5);
    --atp-box-shadow-icon-clickable-background-hover-light: hsl(0 0 100 / 0.34);
    --atp-box-shadow-icon-clickable-background-pressed-light: hsl(0 0 100 / 0.5);
  }

  .button {
    --atp-icon-fill: currentColor;

    overflow: hidden;
    position: relative;
    color: var(--atp-button-inverse-medium-enabled);
    background-color: var(--atp-button-primary-medium-enabled);
    border-radius: var(--atp-border-radius-m);
    box-sizing: border-box;
    border: none;
    outline-offset: inherit;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: var(--atp-space-xxs);
    white-space: nowrap;
  }

  .button:focus-visible {
    outline: var(--atp-focus-width) solid var(--atp-focus-color);
    outline-offset: var(--atp-focus-outline-offset);
  }

  .button.focus-inverse:focus-visible {
    outline: var(--atp-focus-width) solid var(--atp-focus-color-inverse);
  }

  .button.reversed {
    flex-direction: row-reverse;
  }

  .icon.text {
    justify-content: center;
    transition: 0.2s ease-out;
    border-radius: 0;
  }

  .icon.text:hover,
  .icon.text:focus-visible {
    box-shadow: var(--atp-box-shadow-icon-clickable-hover-dark);
    background: var(--atp-box-shadow-icon-clickable-background-hover-dark);
    border-radius: var(--atp-border-radius-s);
    outline-offset: var(--atp-focus-outline-offset-extended);
  }

  .icon.text:active {
    box-shadow: var(--atp-box-shadow-icon-clickable-pressed-dark);
    background: var(--atp-box-shadow-icon-clickable-background-pressed-dark);
  }

  .icon.light.text:hover,
  .icon.text:focus-visible {
    box-shadow: var(--atp-box-shadow-icon-clickable-hover-light);
    background: var(--atp-box-shadow-icon-clickable-background-hover-light);
  }

  .icon.light.text:active {
    box-shadow: var(--atp-box-shadow-icon-clickable-pressed-light);
    background: var(--atp-box-shadow-icon-clickable-background-pressed-light);
  }

  .icon.text:is(.disabled, .loading):is(:hover, :focus-visible, :active) {
    box-shadow: none;
    background-color: transparent;
  }

  .loading .spinner {
    position: absolute;
    display: flex;
    align-items: center;
    justify-content: center;
    inset: 0;
    cursor: default;
  }

  .loading.fill .spinner {
    background-color: var(--atp-button-primary-medium-enabled);
  }

  .loading.outline .spinner {
    background-color: var(--atp-button-secondary-medium-enabled);
  }

  .loading.danger.outline .spinner {
    background: #f8d7de; /** TODO: This needs to be added as a token as --danger-primary-weak-enabled */
  }

  .loading.danger.fill .spinner {
    background-color: var(--atp-button-danger-medium-enabled);
  }

  .button.loading.text,
  .button.loading.text.danger {
    color: transparent;
    overflow: visible;
  }

  .button.disabled {
    cursor: default;
    opacity: 0.5;
    text-decoration: none;
  }

  .fill {
    color: var(--atp-button-inverse-medium-enabled);
    background-color: var(--atp-button-primary-medium-enabled);
  }

  .fill:hover,
  .fill:focus-visible {
    background-color: var(--atp-button-primary-medium-hover);
  }

  .fill:active {
    background-color: var(--atp-button-primary-medium-pressed);
  }

  .fill:is(.disabled, .loading),
  .fill:is(.disabled, .loading):is(:hover, :focus-visible, :active) {
    background-color: var(--atp-button-primary-medium-disabled);
  }

  .outline {
    border: 1px solid transparent;
    color: var(--atp-button-primary-medium-enabled);
    background-color: var(--atp-button-secondary-medium-enabled);
  }

  .outline:hover,
  .outline:focus-visible {
    border: 1px solid var(--atp-button-primary-medium-enabled);
    background: var(--atp-button-secondary-medium-hover);
  }

  .outline:active {
    border: 1px solid var(--atp-button-primary-medium-enabled);
    background: var(--atp-button-secondary-medium-pressed);
  }

  .outline:is(.disabled, .loading),
  .outline:is(.disabled, .loading):is(:hover, :focus-visible, :active) {
    border: 1px solid transparent;
    background: var(--atp-button-secondary-medium-disabled);
    color: var(--atp-button-primary-medium-disabled);
  }

  .button.light.text {
    color: var(--atp-content-inverse-medium-enabled);
  }

  .button.text {
    color: var(--atp-button-primary-medium-enabled);
    background-color: transparent;
    overflow: visible;
  }

  .text:is(:hover, :focus-visible, :active) {
    text-decoration: underline;
  }

  .text:is(.disabled, .loading):is(:hover, :focus-visible, :active) {
    text-decoration: none;
  }

  /* stylelint-disable no-descending-specificity -- keep danger styling grouped together */
  .danger:is(.outline),
  .danger:is(.outline):is(.disabled, .loading):is(:hover, :focus-visible, :active) {
    border: 1px solid var(--atp-button-danger-medium-enabled);
    background: transparent;
    color: var(--atp-button-danger-medium-enabled);
  }

  .danger:is(.outline):hover,
  .danger:is(.outline):focus-visible {
    border: 1px solid var(--atp-button-danger-medium-hover);
    background: var(--atp-danger-primary-weak-hover);
    color: var(--atp-button-danger-medium-hover);
  }

  .danger:is(.outline):active {
    border: 1px solid var(--atp-button-danger-medium-pressed);
    background: var(--atp-danger-primary-weak-pressed);
    color: var(--atp-button-danger-medium-pressed);
  }

  .danger:is(.fill),
  .danger:is(.fill):is(.disabled, .loading):is(:hover, :focus-visible, :active) {
    color: var(--atp-button-inverse-medium-enabled);
    background-color: var(--atp-button-danger-medium-enabled);
  }

  .danger:is(.fill):hover,
  .danger:is(.fill):focus-visible {
    background-color: var(--atp-button-danger-medium-hover);
  }

  .danger:is(.fill):active {
    background-color: var(--atp-button-danger-medium-pressed);
  }
  /* stylelint-enable no-descending-specificity  */

  .danger.text {
    color: var(--atp-button-danger-medium-hover);
  }

  .large {
    padding: 12px;
    block-size: 44px;
    font-family: var(--atpco-font-family);
    font-size: var(--atp-font-size-body-l);
    font-weight: var(--atp-font-weight-semibold);
    line-height: var(--atp-line-height-body-l);
  }

  .large.icon {
    inline-size: 44px;
  }

  .medium {
    padding: var(--atp-space-xs);
    block-size: var(--atp-space-l);
    font-family: var(--atpco-font-family);
    font-size: var(--atp-font-size-body-s);
    font-weight: var(--atp-font-weight-semibold);
    line-height: var(--atp-line-height-body-s);
  }

  .medium.icon {
    inline-size: var(--atp-space-l);
  }

  .small {
    padding: var(--atp-space-xxs) var(--atp-space-xs);
    block-size: var(--atp-space-m);
    font-family: var(--atpco-font-family);
    font-size: var(--atp-font-size-body-s);
    font-weight: var(--atp-font-weight-semibold);
    line-height: var(--atp-line-height-body-s);
  }

  .small.icon {
    inline-size: var(--atp-space-m);
  }

  .medium.text,
  .small.text,
  .large.text {
    padding: 0;
    block-size: unset;
    inline-size: unset;
  }
`;
const V = (e) => e ?? c;
function Be(e, t) {
  return !e.composedPath().includes(t);
}
function o1(e) {
  return e || "id" + Date.now() + Math.random().toString().replace(".", "");
}
function v(e) {
  return Object.entries(e).filter(([, t]) => t).map(([t]) => t).join(" ");
}
const m = g`
  *,
  *::before,
  *::after {
    box-sizing: border-box;
  }
`, C5 = g`
  .spinner-wrapper {
    position: relative;
    block-size: fit-content;
    inline-size: fit-content;
  }

  /* stylelint-disable -- re-enable this once we no longer need -webkit-mask-image */
  .spinner {
    inline-size: var(--atp-space-m);
    block-size: var(--atp-space-m);
    border-radius: 50%;
    -webkit-mask-image: radial-gradient(
      circle at center,
      transparent 55%,
      black 56%
    ); /* TODO: legacy browser support for Safari <=15.3; remove when no longer necessary */
    mask-image: radial-gradient(circle at center, transparent 55%, black 56%);
    background: conic-gradient(
      from 180deg at 50% 50%,
      hsl(0 0% 100% / 100%) 0deg,
      hsl(0 0% 100% / 60%) 360deg
    );
    animation: spin 1s linear infinite;
  }
  /* stylelint-enable */

  .progress {
    position: absolute;
    color: var(--atp-content-inverse-medium-enabled);
    inset: 0;
    display: flex;
    align-items: center;
    justify-content: center;

    font-family: var(--atpco-font-family);
    font-size: var(--atp-font-size-body-xs);
    font-weight: var(--atp-font-weight-regular);
    line-height: var(--atp-line-height-body-xs);
  }

  .spinner-wrapper:has(.size-xxl) .progress {
    font-size: var(--atp-font-size-body-m);
    font-weight: var(--atp-font-weight-regular);
    line-height: var(--atp-line-height-body-m);
  }

  .spinner.waiting:is(.slate, .white, .red) {
    background: var(--atp-content-primary-weak-disabled);
  }

  @keyframes spin {
    to {
      transform: rotate(360deg);
    }
  }

  .spinner.size-s {
    block-size: var(--atp-space-s);
    inline-size: var(--atp-space-s);
  }

  .spinner.size-l {
    block-size: var(--atp-space-l);
    inline-size: var(--atp-space-l);
  }

  .spinner.size-xl {
    block-size: var(--atp-space-xl);
    inline-size: var(--atp-space-xl);
  }

  .spinner.size-xxl {
    block-size: var(--atp-space-xxl);
    inline-size: var(--atp-space-xxl);
  }

  .spinner.slate {
    background: conic-gradient(
      from 180deg at 50% 50%,
      hsl(209 20% 39% / 1) 0deg,
      hsl(209 20% 39% / 0.6) 360deg
    );
  }

  .spinner-wrapper:has(.slate) .progress {
    color: var(--atp-element-fill-primary-strong-enabled);
  }

  .spinner.red {
    background: conic-gradient(
      from 180deg at 50% 50%,
      hsl(348 68% 52% / 1) 0deg,
      hsl(348 68% 52% / 0.6) 360deg
    );
  }

  .spinner-wrapper:has(.red) .progress {
    color: var(--atp-danger-primary-strong-enabled);
  }

  .visually-hidden {
    border: 0;
    padding: 0;
    margin: 0;
    position: absolute !important;
    block-size: 1px;
    inline-size: 1px;
    overflow: hidden;
    clip-path: inset(50%);
    white-space: nowrap;
  }
`;
var v5 = Object.defineProperty, g5 = Object.getOwnPropertyDescriptor, E1 = (e, t, i, r) => {
  for (var a = r > 1 ? void 0 : r ? g5(t, i) : t, o = e.length - 1, s; o >= 0; o--)
    (s = e[o]) && (a = (r ? s(t, i, a) : s(a)) || a);
  return r && a && v5(t, i, a), a;
}, a1 = /* @__PURE__ */ ((e) => (e.SLATE = "slate", e.WHITE = "white", e.RED = "red", e))(a1 || {}), H1 = /* @__PURE__ */ ((e) => (e.XXL = "xxl", e.XL = "xl", e.L = "l", e.M = "m", e.S = "s", e))(H1 || {});
let s1 = class extends b {
  constructor() {
    super(...arguments), this.color = "slate", this.size = "m", this.isWaiting = !1;
  }
  render() {
    return n`
      <div class="spinner-wrapper">
        <div class="${this._getClasses()}"></div>
        <span class="visually-hidden">${this.progress === 100 ? "complete" : "loading"}</span>
        ${!this.isWaiting && this.progress && (this.size === "xl" || this.size === "xxl") ? n`<div class="progress">${this.progress}%</div>` : c}
      </div>
    `;
  }
  _getClasses() {
    return v({
      [this.color]: !0,
      spinner: !0,
      [`size-${this.size}`]: !0,
      waiting: this.isWaiting
    });
  }
};
s1.styles = [C5];
E1([
  l()
], s1.prototype, "color", 2);
E1([
  l()
], s1.prototype, "size", 2);
E1([
  l({ type: Number })
], s1.prototype, "progress", 2);
E1([
  l({ type: Boolean })
], s1.prototype, "isWaiting", 2);
s1 = E1([
  u("atp-spinner")
], s1);
var m5 = Object.defineProperty, f5 = Object.getOwnPropertyDescriptor, $ = (e, t, i, r) => {
  for (var a = r > 1 ? void 0 : r ? f5(t, i) : t, o = e.length - 1, s; o >= 0; o--)
    (s = e[o]) && (a = (r ? s(t, i, a) : s(a)) || a);
  return r && a && m5(t, i, a), a;
}, he = /* @__PURE__ */ ((e) => (e.FILL = "fill", e.OUTLINE = "outline", e.TEXT = "text", e))(he || {}), ee = /* @__PURE__ */ ((e) => (e.LEFT = "left", e.RIGHT = "right", e))(ee || {}), te = /* @__PURE__ */ ((e) => (e.LARGE = "large", e.MEDIUM = "medium", e.SMALL = "small", e))(te || {});
let y = class extends b {
  constructor() {
    super(...arguments), this.label = "", this.appearance = "fill", this.size = "medium", this.isDestructive = !1, this.disabled = !1, this.iconPosition = "right", this.tabNumber = 0, this.isLoading = !1, this.focusInverse = !1, this.dataTrackingId = null, this.iconClickableLight = !1;
  }
  render() {
    return n`
      <button
        ?disabled=${this.disabled || this.isLoading}
        tabindex=${this.tabNumber}
        class=${this._getClasses()}
        @click=${this._onClick}
        @blur=${this._onBlur}
        @focus=${this._onFocus}
        aria-label="${this.iconConfig?.label ?? ""}"
        data-tracking-id=${V(this.dataTrackingId)}
      >
        ${this.iconConfig ? n`<atp-icon
              aria-hidden=${!0}
              .color="${this.iconConfig.color}"
              .icon="${this.iconConfig.icon}"
              .height="${this.iconConfig.height}"
            ></atp-icon>` : ""}${this.label}
        <slot></slot>
        ${this.isLoading ? n`<atp-spinner
              class="spinner"
              .size="${this.size === "large" ? H1.M : H1.S}"
              .color="${this._getSpinnerColor()}"
            ></atp-spinner>` : ""}
      </button>
    `;
  }
  _onClick() {
    this.dispatchEvent(new CustomEvent("clickEventOutput", { bubbles: !0, composed: !0 }));
  }
  _onFocus() {
    this.dispatchEvent(new CustomEvent("focusEventOutput", { bubbles: !0, composed: !0 }));
  }
  _onBlur() {
    this.dispatchEvent(new CustomEvent("blurEventOutput", { bubbles: !0, composed: !0 }));
  }
  focusButton() {
    this._buttonElement?.focus();
  }
  blurButton() {
    this._buttonElement?.blur();
  }
  _getSpinnerColor() {
    return this.appearance === "text" && !this.isDestructive ? a1.SLATE : this.isDestructive && this.appearance !== "fill" ? a1.RED : this.appearance === "outline" && !this.isDestructive ? a1.SLATE : a1.WHITE;
  }
  _getClasses() {
    return v({
      button: !0,
      loading: this.isLoading,
      [`${this.appearance}`]: !0,
      [`${this.size}`]: !0,
      danger: this.isDestructive,
      disabled: this.disabled,
      reversed: this.iconConfig && this.iconPosition === "right",
      icon: this.iconConfig && !this.label,
      light: this.iconClickableLight,
      "focus-inverse": this.focusInverse
    });
  }
};
y.styles = [m, u5];
$([
  l()
], y.prototype, "label", 2);
$([
  l()
], y.prototype, "appearance", 2);
$([
  l()
], y.prototype, "size", 2);
$([
  l({ type: Boolean })
], y.prototype, "isDestructive", 2);
$([
  l({ type: Boolean })
], y.prototype, "disabled", 2);
$([
  l()
], y.prototype, "iconPosition", 2);
$([
  l({ type: Object })
], y.prototype, "iconConfig", 2);
$([
  l({ type: Number })
], y.prototype, "tabNumber", 2);
$([
  l({ type: Boolean })
], y.prototype, "isLoading", 2);
$([
  l({ type: Boolean })
], y.prototype, "focusInverse", 2);
$([
  l({ type: String })
], y.prototype, "dataTrackingId", 2);
$([
  l({ type: Boolean })
], y.prototype, "iconClickableLight", 2);
$([
  F1("button")
], y.prototype, "_buttonElement", 2);
y = $([
  u("atp-button")
], y);
const y5 = g`
  .button {
    --atp-icon-fill: currentcolor;

    all: unset;
    padding: var(--atp-space-xxs) var(--atp-space-xs);
    display: flex;
    gap: var(--atp-space-xxs);
    align-items: center;
    background-color: var(--atp-button-translucent-light-medium-enabled);
    color: var(--atp-button-primary-medium-enabled);
    border-radius: var(--atp-border-radius-m);
    block-size: var(--atp-space-l);
    cursor: pointer;
    font-family: var(--atpco-font-family);
    font-size: var(--atp-font-size-body-s);
    font-weight: var(--atp-font-weight-semibold);
    line-height: var(--atp-line-height-body-s);
    box-sizing: border-box;
  }

  .button:focus-visible {
    outline: var(--atp-focus-width) solid currentcolor;
    outline-offset: var(--atp-focus-outline-offset);
  }

  .button.focus-inverse:focus-visible {
    outline: var(--atp-focus-width) solid var(--atp-focus-color-inverse);
  }

  .button.reversed {
    flex-direction: row-reverse;
  }

  .button.large {
    padding: var(--atp-space-xs);
    font-size: var(--atp-font-size-body-l);
    font-weight: var(--atp-font-weight-semibold);
    line-height: var(--atp-line-height-body-l);
    block-size: 44px;
  }

  .button.small {
    block-size: var(--atp-space-m);
  }

  .button:hover,
  .button:focus-visible {
    background-color: var(--atp-button-translucent-light-medium-hover);
  }

  .button:active {
    background-color: var(--atp-button-translucent-light-medium-pressed);
  }

  .button.text:is(.medium, .large, .small) {
    padding: 0;
    background-color: transparent;
  }

  .button.text:is(.medium, .large, .small):is(:hover, :focus-visible, :active) {
    text-decoration: underline;
  }

  .button.text:is(.medium, .large, .small):focus-visible,
  .button.text:is(.medium, .large, .small):hover {
    color: var(--atp-button-primary-medium-hover);
  }

  .button.text:is(.medium, .large, .small):active {
    color: var(--atp-button-primary-medium-pressed);
  }

  .button.light.text:is(.medium, .large, .small),
  .button.light.text:is(.medium, .large, .small):is(:hover, :focus-visible, :active) {
    color: var(--atp-button-inverse-medium-enabled);
  }

  .button.danger.text:is(.medium, .large, .small) {
    color: var(--atp-button-danger-medium-enabled);
  }

  .button.danger.text:is(.medium, .large, .small):focus-visible,
  .button.danger.text:is(.medium, .large, .small):hover {
    color: var(--atp-button-danger-medium-hover);
  }

  .button.danger.text:is(.medium, .large, .small):active {
    color: var(--atp-button-danger-medium-pressed);
  }
`;
var w5 = Object.defineProperty, x5 = Object.getOwnPropertyDescriptor, P = (e, t, i, r) => {
  for (var a = r > 1 ? void 0 : r ? x5(t, i) : t, o = e.length - 1, s; o >= 0; o--)
    (s = e[o]) && (a = (r ? s(t, i, a) : s(a)) || a);
  return r && a && w5(t, i, a), a;
};
let Z = class extends b {
  constructor() {
    super(...arguments), this.label = "", this.appearance = he.FILL, this.size = te.MEDIUM, this.iconPosition = ee.RIGHT, this.isLoading = !1, this.lightLoader = !1, this.textButtonColor = "dark", this.focusInverse = !1;
  }
  render() {
    return n`
      <button class=${this._getClasses()} @click=${this._onClick}>
        ${this.iconConfig ? n`<atp-icon
              .color="${this.iconConfig.color}"
              .icon="${this.iconConfig.icon}"
              .height="${this.iconConfig.height}"
            ></atp-icon>` : ""}${this.label}
        ${this.isLoading ? n`<atp-spinner
              class="spinner"
              .size="${this.size === te.LARGE ? H1.M : H1.S}"
              .color="${this.lightLoader ? a1.WHITE : a1.SLATE}"
            ></atp-spinner>` : ""}
      </button>
    `;
  }
  _onClick() {
    this.dispatchEvent(new CustomEvent("clickEventOutput", { bubbles: !0, composed: !0 }));
  }
  _getClasses() {
    return v({
      button: !0,
      loading: this.isLoading,
      [`${this.appearance}`]: !0,
      [`${this.size}`]: !0,
      reversed: this.iconPosition === ee.RIGHT,
      [`${this.textButtonColor}`]: !0,
      "focus-inverse": this.focusInverse
    });
  }
};
Z.styles = [m, y5];
P([
  l()
], Z.prototype, "label", 2);
P([
  l()
], Z.prototype, "appearance", 2);
P([
  l()
], Z.prototype, "size", 2);
P([
  l()
], Z.prototype, "iconPosition", 2);
P([
  l({ type: Object })
], Z.prototype, "iconConfig", 2);
P([
  l({ type: Boolean })
], Z.prototype, "isLoading", 2);
P([
  l({ type: Boolean })
], Z.prototype, "lightLoader", 2);
P([
  l({ type: String })
], Z.prototype, "textButtonColor", 2);
P([
  l({ type: Boolean })
], Z.prototype, "focusInverse", 2);
Z = P([
  u("atp-alert-button")
], Z);
var _5 = Object.defineProperty, k5 = Object.getOwnPropertyDescriptor, f1 = (e, t, i, r) => {
  for (var a = r > 1 ? void 0 : r ? k5(t, i) : t, o = e.length - 1, s; o >= 0; o--)
    (s = e[o]) && (a = (r ? s(t, i, a) : s(a)) || a);
  return r && a && _5(t, i, a), a;
}, $5 = /* @__PURE__ */ ((e) => (e.DANGER = "danger", e.WARNING = "warning", e.INFO = "info", e))($5 || {}), L5 = /* @__PURE__ */ ((e) => (e.FULL = "full", e.PAGE = "page", e.EXPANDABLE = "expandable", e.TOAST = "toast", e))(L5 || {});
let K = class extends b {
  constructor() {
    super(...arguments), this.label = "", this.appearance = "full", this.color = "info", this.hasClose = !0, this._showContent = !0;
  }
  render() {
    return n`
      <div class="outer-wrapper">
        <div class=${this._getClasses()}>
          ${this.appearance === "expandable" ? n` <atp-button
                class="toggle ${this._showContent ? "" : "rotate"}"
                appearance="text"
                .iconConfig=${{
      icon: "chevron-down",
      height: 16,
      color: this._getColor()
    }}
                .focusInverse=${this._useFocusInverse()}
                @clickEventOutput="${this._toggleContent}"
              ></atp-button>` : c}
          ${this.appearance === "full" ? n`<span></span>` : ""}
          ${this.icon && this.appearance !== "expandable" && this.appearance !== "full" ? n`<atp-icon
                .height=${16}
                .color=${this._getColor()}
                .icon=${this.icon}
              ></atp-icon>` : ""}
          <div class="label-button-container">
            <div class="label">${this.label}</div>
            <div class="buttons">
              <slot name="button"></slot>
            </div>
          </div>
          ${this.hasClose ? n`<atp-button
                @clickEventOutput=${this._closeHandler}
                appearance="text"
                .iconConfig=${{
      icon: "x",
      height: 16,
      color: this._getColor()
    }}
                .focusInverse=${this._useFocusInverse()}
              ></atp-button>` : ""}
          ${!this.hasClose && this.appearance === "full" ? n`<span></span>` : ""}
        </div>
        ${this.appearance === "expandable" && this._showContent ? n`<div class="content-wrapper">
              <slot name="content"></slot>
            </div>` : c}
      </div>
    `;
  }
  _getClasses() {
    return v({
      alert: !0,
      [`${this.appearance}`]: !0,
      [`${this.color}`]: !0,
      open: this._showContent
    });
  }
  _useFocusInverse() {
    return (this.appearance === "expandable" || this.appearance === "full" || this.appearance === "toast") && this.color === "info";
  }
  _toggleContent() {
    this._showContent = !this._showContent, this.requestUpdate();
  }
  _closeHandler() {
    this.dispatchEvent(new CustomEvent("closeEventOutput", { bubbles: !0, composed: !0 }));
  }
  _getColor() {
    return this.color === "warning" ? "var(--atp-content-primary-medium-enabled)" : this.appearance === "page" ? this.color === "danger" ? "var(--atp-danger-primary-strong-enabled)" : "var(--atp-content-primary-medium-enabled)" : (this.appearance === "toast" || this.appearance === "expandable", "var(--atp-content-inverse-medium-enabled)");
  }
};
K.styles = [m, c5];
f1([
  l()
], K.prototype, "icon", 2);
f1([
  l()
], K.prototype, "label", 2);
f1([
  l()
], K.prototype, "appearance", 2);
f1([
  l()
], K.prototype, "color", 2);
f1([
  l({ type: Boolean })
], K.prototype, "hasClose", 2);
K = f1([
  u("atp-alert")
], K);
const H5 = g`
  .breadcrumbs {
    font-size: var(--atp-font-size-body-s);
    line-height: var(--atp-line-height-body-s);
  }

  .breadcrumbs.large {
    font-size: var(--atp-font-size-heading-s);
    line-height: var(--atp-line-height-heading-s);
  }

  .breadcrumbs ul {
    display: inline-flex;
    flex-wrap: wrap;
    gap: var(--atp-space-xs);
    margin: 0;
    padding: 0;
    list-style-type: none;
  }

  .breadcrumbs li {
    display: inline-flex;
    flex-wrap: nowrap;
    align-items: baseline;
  }

  /* 
    for a11y purposes, we can't use a slash character inside the content property, 
    since it will be read out by assistive technologies. 
    Instead, draw a fake slash using CSS.
    This is the W3C-recommended pattern: 
    https://www.w3.org/WAI/ARIA/apg/patterns/breadcrumb/examples/breadcrumb/
  */
  .breadcrumbs li::after {
    content: '';
    display: inline-block;
    block-size: 0.8em;
    inline-size: 1px;
    padding-inline-start: var(--atp-space-xs);
    border-inline-end: 1px solid currentcolor;
    rotate: 15deg;
  }

  .breadcrumbs li:last-of-type::after {
    display: none;
  }

  .breadcrumbs a,
  .breadcrumbs .current-page {
    display: inline-block;
    padding: var(--atp-space-xxxs) var(--atp-space-xs);
    text-decoration: none;
    font-weight: var(--atp-font-weight-regular);
    color: var(--atp-content-primary-enabled-weak);
    white-space: nowrap;
    border-radius: var(--atp-border-radius-m);
  }

  .breadcrumbs a:focus-visible {
    outline: var(--atp-focus-width) solid var(--atp-focus-color);
    outline-offset: var(--atp-focus-outline-offset);
  }

  .breadcrumbs .current-page {
    font-weight: var(--atp-font-weight-medium);
    color: var(--atp-content-primary-enabled-medium);
  }

  .breadcrumbs a:hover {
    background: var(--atp-element-fill-blue-weak-hover);
  }

  .breadcrumbs a:active {
    background: var(--atp-element-fill-blue-weak-pressed);
  }
`;
var V5 = Object.defineProperty, M5 = Object.getOwnPropertyDescriptor, be = (e, t, i, r) => {
  for (var a = r > 1 ? void 0 : r ? M5(t, i) : t, o = e.length - 1, s; o >= 0; o--)
    (s = e[o]) && (a = (r ? s(t, i, a) : s(a)) || a);
  return r && a && V5(t, i, a), a;
}, z5 = /* @__PURE__ */ ((e) => (e.LARGE = "large", e.SMALL = "small", e))(z5 || {});
let V1 = class extends b {
  constructor() {
    super(...arguments), this.itemsList = [], this.size = "small";
  }
  _onClick(e) {
    e.preventDefault(), this.dispatchEvent(
      new CustomEvent("clickEventOutput", {
        bubbles: !0,
        composed: !0,
        detail: e.target.id
      })
    );
  }
  render() {
    return n`
      <nav class="${this._getClasses()}" aria-label="Breadcrumb">
        <ul>
          ${this.itemsList.map(
      (e, t) => n`
              <li aria-current="${t === this.itemsList.length - 1 ? "page" : c}">
                ${t == this.itemsList.length - 1 ? n`<span class="current-page" id=${o1(e.id)}>${e.name}</span>` : n`<a
                      href="${e.href ? e.href : "#"}"
                      id=${o1(e.id)}
                      @click=${e.emitEvent ? this._onClick : c}
                    >
                      ${e.name}</a
                    >`}
              </li>
            `
    )}
        </ul>
      </nav>
    `;
  }
  _getClasses() {
    return v({
      breadcrumbs: !0,
      large: this.size === "large"
      /* LARGE */
    });
  }
};
V1.styles = [m, H5];
be([
  l({ type: Array })
], V1.prototype, "itemsList", 2);
be([
  l()
], V1.prototype, "size", 2);
V1 = be([
  u("atp-breadcrumbs")
], V1);
const E5 = (e) => e.strings === void 0;
const _1 = (e, t) => {
  const i = e._$AN;
  if (i === void 0) return !1;
  for (const r of i) r._$AO?.(t, !1), _1(r, t);
  return !0;
}, T1 = (e) => {
  let t, i;
  do {
    if ((t = e._$AM) === void 0) break;
    i = t._$AN, i.delete(e), e = t;
  } while (i?.size === 0);
}, Ie = (e) => {
  for (let t; t = e._$AM; e = t) {
    let i = t._$AN;
    if (i === void 0) t._$AN = i = /* @__PURE__ */ new Set();
    else if (i.has(e)) break;
    i.add(e), O5(t);
  }
};
function Z5(e) {
  this._$AN !== void 0 ? (T1(this), this._$AM = e, Ie(this)) : this._$AM = e;
}
function A5(e, t = !1, i = 0) {
  const r = this._$AH, a = this._$AN;
  if (a !== void 0 && a.size !== 0) if (t) if (Array.isArray(r)) for (let o = i; o < r.length; o++) _1(r[o], !1), T1(r[o]);
  else r != null && (_1(r, !1), T1(r));
  else _1(this, e);
}
const O5 = (e) => {
  e.type == de.CHILD && (e._$AP ??= A5, e._$AQ ??= Z5);
};
class B5 extends pe {
  constructor() {
    super(...arguments), this._$AN = void 0;
  }
  _$AT(t, i, r) {
    super._$AT(t, i, r), Ie(this), this.isConnected = t._$AU;
  }
  _$AO(t, i = !0) {
    t !== this.isConnected && (this.isConnected = t, t ? this.reconnected?.() : this.disconnected?.()), i && (_1(this, t), T1(this));
  }
  setValue(t) {
    if (E5(this._$Ct)) this._$Ct._$AI(t, this);
    else {
      const i = [...this._$Ct._$AH];
      i[this._$Ci] = t, this._$Ct._$AI(i, this, 0);
    }
  }
  disconnected() {
  }
  reconnected() {
  }
}
const h1 = () => new I5();
class I5 {
}
const X1 = /* @__PURE__ */ new WeakMap(), b1 = ce(class extends B5 {
  render(e) {
    return c;
  }
  update(e, [t]) {
    const i = t !== this.G;
    return i && this.G !== void 0 && this.rt(void 0), (i || this.lt !== this.ct) && (this.G = t, this.ht = e.options?.host, this.rt(this.ct = e.element)), c;
  }
  rt(e) {
    if (this.isConnected || (e = void 0), typeof this.G == "function") {
      const t = this.ht ?? globalThis;
      let i = X1.get(t);
      i === void 0 && (i = /* @__PURE__ */ new WeakMap(), X1.set(t, i)), i.get(this.G) !== void 0 && this.G.call(this.ht, void 0), i.set(this.G, e), e !== void 0 && this.G.call(this.ht, e);
    } else this.G.value = e;
  }
  get lt() {
    return typeof this.G == "function" ? X1.get(this.ht ?? globalThis)?.get(this.G) : this.G?.value;
  }
  disconnected() {
    this.lt === this.ct && this.rt(void 0);
  }
  reconnected() {
    this.rt(this.ct);
  }
}), S5 = g`
  :host {
    --atp-checkbox-input-width: 16px;
    --atp-checkbox-input-border-width: 2px;
    --atp-checkbox-between-input-and-label: var(--atp-space-xs);
    --atp-checkbox-label-padding-left: calc(
      var(--atp-checkbox-input-width) + var(--atp-checkbox-between-input-and-label)
    );
    --atp-checkbox-icon-width: 10px;
    --atp-checkbox-bordered-padding-left: var(--atp-space-s);
  }

  .container {
    position: relative;
    display: inline-flex;
    align-items: center;
  }

  .input {
    position: absolute;
    block-size: 1px;
    inline-size: 1px;
    overflow: hidden;
    clip-path: inset(50%);
    white-space: nowrap;
  }

  .label {
    position: relative;
    color: var(--atp-content-primary-medium-enabled);
    cursor: pointer;
    display: inline-block;
    min-block-size: var(--atp-space-s);
    margin-block: 0;
    padding-inline-start: var(--atp-checkbox-label-padding-left);
    font-size: var(--atp-font-size-body-s);
    font-weight: normal;
    line-height: var(--atp-line-height-body-s);
    vertical-align: middle;
    white-space: nowrap;
  }

  .label:focus-visible,
  .input:focus-visible + .label {
    border-radius: 1px;
    outline: var(--atp-focus-width) solid var(--atp-focus-color);
    outline-offset: var(--atp-focus-outline-offset);
  }

  /* the visible "checkbox" */
  .label::before {
    background: var(--atp-neutral-0);
    border: var(--atp-checkbox-input-border-width) solid currentcolor;
    border-radius: 2px;
    color: var(--atp-content-primary-medium-enabled); /* used for border and background color */
    content: '';
    padding: 0 1px;
    position: absolute;
    display: block;
    inset-block-start: 50%;
    inset-inline-start: 0;
    transform: translateY(-50%);
    inline-size: var(--atp-checkbox-input-width);
    block-size: var(--atp-checkbox-input-width);
    z-index: var(--atp-z-index-base);
  }

  .label:hover::before {
    color: var(--atp-utility-primary-medium-hover);
  }

  .label:active::before {
    color: var(--atp-utility-primary-medium-pressed);
  }

  .icon {
    fill: var(--atp-element-fill-inverse-weak-enabled);
    stroke: var(--atp-element-fill-inverse-weak-enabled);
    opacity: 0;
    position: absolute;
    inset-inline-start: calc(
      (var(--atp-checkbox-input-width) - var(--atp-checkbox-icon-width)) / 2
    );
    inset-block-start: 50%;
    transform: translateY(-50%);
    block-size: var(--atp-checkbox-icon-width);
    inline-size: var(--atp-checkbox-icon-width);
    z-index: var(--atp-z-index-over-base);
  }

  /* checked state */
  .input:checked + .label::before {
    color: var(--atp-utility-primary-medium-enabled);
    background-color: currentColor;
  }

  .input:checked + .label .icon {
    opacity: 1;
  }

  .input:checked + .label:hover::before {
    color: var(--atp-utility-primary-medium-hover);
  }

  .input:checked + .label:active::before {
    color: var(--atp-utility-primary-medium-pressed);
  }

  /* stylelint-disable no-descending-specificity -- so we can keep features grouped together */

  /* disabled state */
  .input:disabled + .label {
    cursor: not-allowed;
  }

  .input:disabled + .label::before {
    color: var(--atp-content-primary-weak-disabled);
  }

  .input:checked:disabled + .label::before,
  .input:indeterminate:disabled + .label::before {
    color: var(--atp-utility-primary-medium-disabled);
  }

  /* error/invalid */
  .input[aria-invalid] + .label::before {
    color: var(--atp-danger-primary-strong-enabled);
  }

  .input[aria-invalid]:checked + .label::before {
    background-color: currentColor;
  }

  .input[aria-invalid] + .label:hover::before,
  .input[aria-invalid]:checked + .label:hover::before {
    color: var(--atp-danger-primary-strong-hover);
  }

  .input[aria-invalid] + .label:active::before,
  .input[aria-invalid]:checked + .label:active::before {
    color: var(--atp-danger-primary-strong-pressed);
  }

  .input[aria-invalid]:disabled + .label::before,
  .input[aria-invalid]:disabled + .label:hover::before,
  .input[aria-invalid]:disabled + .label:active::before {
    color: var(--atp-danger-primary-strong-disabled);
  }

  /* bordered */
  .bordered .label {
    display: inline-block;
    padding: var(--atp-space-xs) var(--atp-space-s) var(--atp-space-xs)
      calc(var(--atp-checkbox-label-padding-left) + var(--atp-checkbox-bordered-padding-left));
    border-radius: var(--atp-border-radius-s);
    border: 1px solid var(--atp-element-border-primary-medium-enabled);
  }

  .bordered .label::before {
    inset-inline-start: var(--atp-checkbox-bordered-padding-left);
  }

  .bordered .input:checked + .label {
    background: var(--atp-element-fill-blue-medium-enabled);
    border-color: var(--atp-utility-primary-medium-enabled);
  }

  .bordered .label:hover,
  .bordered .input:checked + label:hover {
    border-color: var(--atp-utility-primary-medium-enabled);
  }

  .bordered .label:active,
  .bordered .input:checked + label:active {
    border-color: var(--atp-utility-primary-medium-pressed);
  }

  .bordered .input:disabled + .label,
  .bordered .input:checked:disabled + .label {
    background: var(--atp-element-fill-inverse-medium-disabled);
    border-color: var(--atp-element-border-primary-medium-enabled);
  }

  .bordered .input[aria-invalid] + .label {
    background-color: var(--atp-element-fill-red-weak-enabled);
    border-color: var(--atp-danger-primary-strong-enabled);
  }

  .bordered .input[aria-invalid] + .label:hover {
    background-color: var(--atp-element-fill-red-weak-hover);
    border-color: var(--atp-danger-primary-strong-hover);
  }

  .bordered .input[aria-invalid] + .label:active {
    background-color: var(--atp-element-fill-red-weak-pressed);
    border-color: var(--atp-danger-primary-strong-pressed);
  }

  .bordered .input[aria-invalid]:disabled + .label {
    background: var(--atp-element-fill-inverse-medium-disabled);
    border-color: var(--atp-element-border-primary-medium-enabled);
  }

  .bordered .icon {
    inset-inline-start: calc(
      var(--atp-checkbox-bordered-padding-left) +
        ((var(--atp-checkbox-input-width) - var(--atp-checkbox-icon-width)) / 2)
    );
  }

  /* no label */
  .no-label {
    /* stylelint-disable-next-line -- logical property value "inline-start" doesn't have baseline support yet */
    float: left;
    margin-inline-end: var(--atp-checkbox-between-input-and-label);
  }

  .no-label .label {
    padding-inline-start: var(--atp-checkbox-input-width);
  }

  .bordered.no-label .label {
    min-block-size: calc(1em + (2 * var(--atp-space-xs)));
    margin-inline-end: 0;
    padding: var(--atp-space-xs) var(--atp-space-xs) var(--atp-space-xs)
      calc(var(--atp-checkbox-label-padding-left) + var(--atp-checkbox-bordered-padding-left));
  }

  /* stylelint-enable no-descending-specificity */
`;
var T5 = Object.defineProperty, P5 = Object.getOwnPropertyDescriptor, M = (e, t, i, r) => {
  for (var a = r > 1 ? void 0 : r ? P5(t, i) : t, o = e.length - 1, s; o >= 0; o--)
    (s = e[o]) && (a = (r ? s(t, i, a) : s(a)) || a);
  return r && a && T5(t, i, a), a;
};
let x = class extends b {
  constructor() {
    super(), this.checked = !1, this.disabled = !1, this.indeterminate = !1, this.isError = !1, this.required = !1, this.bordered = !1, this.tabindex = 0, this._inputId = o1(this.id), this.inputRef = h1(), this._invalidMessage = "This checkbox is required.", this._internals = this.attachInternals();
  }
  checkIconTemplate() {
    return n`
      <svg
        version="1.1"
        xmlns="http://www.w3.org/2000/svg"
        width="40"
        height="32"
        viewBox="0 0 40 32"
        class="icon"
        aria-hidden="true"
      >
        <title>Checked</title>
        <path
          d="M13.26 32l-13.26-13.26 4.994-4.994 8.265 8.265 21.967-22.011 4.994 4.994-26.961 27.006z"
        ></path>
      </svg>
    `;
  }
  indeterminateIconTemplate() {
    return n`
      <svg
        xmlns="http://www.w3.org/2000/svg"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        stroke-width="3"
        stroke-linecap="round"
        stroke-linejoin="round"
        class="icon"
        aria-hidden="true"
      >
        <title>Indeterminate</title>
        <line x1="5" y1="12" x2="19" y2="12"></line>
      </svg>
    `;
  }
  static get formAssociated() {
    return !0;
  }
  render() {
    return n`
      <div class=${this._getContainerStyleClasses()}>
        <input
          ${b1(this.inputRef)}
          class=${this._getInputStyleClasses()}
          type="checkbox"
          name=${V(this.name)}
          value=${V(this.value)}
          ?checked=${this.checked || this.indeterminate}
          ?disabled=${this.disabled}
          ?required=${this.required}
          ?aria-required=${this.required}
          tabindex=${this.tabindex}
          id=${this._inputId}
          ?indeterminate=${this.indeterminate}
          ?aria-invalid=${this.isError}
          aria-errormessage=${V(this.ariaErrorMessage)}
          aria-label=${V(this.ariaLabel)}
          @click=${this._onClick}
          @change=${this._onChange}
          @keydown=${this._onKeyDown}
          @blur=${this._onBlur}
          @focus=${this._onFocus}
        />
        <label
          class="label"
          for=${this._inputId}
          title=${this.label}
          aria-label=${this.label ? null : V(this.ariaLabel)}
          @keydown=${this._onKeyDown}
          @blur=${this._onBlur}
          @focus=${this._onFocus}
        >
          ${this.label}
          ${this.indeterminate ? this.indeterminateIconTemplate() : this.checkIconTemplate()}
        </label>
      </div>
    `;
  }
  setValidity() {
    this._internals.setValidity(
      { valueMissing: this.required && !this.checked },
      this.required && !this.checked ? this._invalidMessage : ""
    ), this._internals.setFormValue(this.checked ? this.value ? this.value : "on" : null);
  }
  checkValidity() {
    return this._internals.checkValidity();
  }
  reportValidity() {
    this._internals.reportValidity();
  }
  get validity() {
    return this._internals.validity;
  }
  get validationMessage() {
    return this._internals.validationMessage;
  }
  updated(e) {
    (e.has("checked") || e.has("required")) && (this.setValidity(), this._internals.setFormValue(this.checked ? this.value ? this.value : "on" : null));
  }
  _onKeyDown(e) {
    if (e.code === "Space" && this.disabled == !1) {
      this._onChange();
      const t = this.inputRef.value;
      t.checked = !t.checked;
    }
    e.code === "Space" && e.preventDefault();
  }
  update(e) {
    super.update(e), e.has("checked") && (this.inputRef.value.checked = this.checked);
  }
  _onChange() {
    this.checked = !this.checked, this.indeterminate = !1, this._internals.setFormValue(this.checked ? this.value ? this.value : "on" : null), this.dispatchEvent(new CustomEvent("changeEventOutput", { bubbles: !0, composed: !0 }));
  }
  _onClick() {
    this.dispatchEvent(new CustomEvent("clickEventOutput", { bubbles: !0, composed: !0 }));
  }
  _onFocus() {
    this.dispatchEvent(new CustomEvent("focusEventOutput", { bubbles: !0, composed: !0 }));
  }
  _onBlur() {
    this.dispatchEvent(new CustomEvent("blurEventOutput", { bubbles: !0, composed: !0 }));
  }
  /* TODO: update this to use the utility class that sets style classes */
  _getContainerStyleClasses() {
    return `container ${this.label ? "" : "no-label"} ${this.bordered ? "bordered" : ""}`.trim();
  }
  _getInputStyleClasses() {
    return `input ${this.indeterminate ? "indeterminate" : ""}`.trim();
  }
  connectedCallback() {
    super.connectedCallback(), this.setValidity(), this._internals.setFormValue(this.checked ? this.value ? this.value : "on" : null);
  }
  formDisabledCallback(e) {
    this.disabled = e;
  }
};
x.styles = [m, S5];
M([
  l({ type: String || void 0 })
], x.prototype, "label", 2);
M([
  l({ type: String })
], x.prototype, "name", 2);
M([
  l({ type: String })
], x.prototype, "value", 2);
M([
  l({ type: String })
], x.prototype, "ariaLabel", 2);
M([
  l({ type: String })
], x.prototype, "ariaErrorMessage", 2);
M([
  l({ type: Boolean, reflect: !0 })
], x.prototype, "checked", 2);
M([
  l({ type: Boolean })
], x.prototype, "disabled", 2);
M([
  l({ type: Boolean })
], x.prototype, "indeterminate", 2);
M([
  l({ type: Boolean, reflect: !0 })
], x.prototype, "isError", 2);
M([
  l({ type: Boolean, reflect: !0 })
], x.prototype, "required", 2);
M([
  l({ type: Boolean })
], x.prototype, "bordered", 2);
M([
  l({ type: Number })
], x.prototype, "tabindex", 2);
x = M([
  u("atp-checkbox")
], x);
const R5 = g`
  :host {
    --atp-dialog-padding: var(--atp-space-m);
    --atp-dialog-sticky-background-color: hsl(0 100% 100% / 0.9);
    --atp-dialog-transition-time: 0.3s;
    --atp-dialog-vertical-offset: 10vh;
  }

  /* the actual dialog tag spans the full display, so that any content that expands beyond the visible box (e.g. dropdown menus) won't get clipped */
  .dialog {
    position: fixed;
    inset: 0;
    display: none;
    block-size: 100%;
    max-block-size: 100%;
    inline-size: 100%;
    max-inline-size: 100%;
    background: transparent;
    border: none;
    opacity: 0;
    transition: display var(--atp-dialog-transition-time) ease-in-out,
      opacity var(--atp-dialog-transition-time) ease-in-out,
      transform var(--atp-dialog-transition-time) ease-in-out,
      overlay var(--atp-dialog-transition-time) ease-in-out;
    transition-behavior: allow-discrete;
  }

  .dialog:modal {
    display: block;
    opacity: 1;
    transition: display var(--atp-dialog-transition-time) ease-in-out,
      opacity var(--atp-dialog-transition-time) ease-in-out,
      transform var(--atp-dialog-transition-time) ease-in-out,
      overlay var(--atp-dialog-transition-time) ease-in-out;
    transition-behavior: allow-discrete;
  }

  @starting-style {
    .dialog {
      opacity: 0;
    }

    .dialog:modal {
      opacity: 0;
    }
  }

  .dialog::backdrop {
    background-color: hsl(0 0% 0% / 0);
    transition: display var(--atp-dialog-transition-time) ease-in-out,
      background-color var(--atp-dialog-transition-time) ease-in-out,
      overlay var(--atp-dialog-transition-time) ease-in-out;
  }

  .dialog:modal::backdrop {
    background-color: var(--atp-dialog-backdrop-color, hsl(0 0% 0% / 0.25));
  }

  @starting-style {
    .dialog:modal::backdrop {
      background-color: hsl(0 0% 0% / 0);
    }
  }

  /* the visible dialog box */
  .dialog-box {
    position: fixed;
    inset-block-start: var(--atp-dialog-vertical-offset);
    inset-inline-start: 50vw;
    display: block;
    block-size: fit-content;
    max-block-size: calc(100vh - (var(--atp-dialog-vertical-offset) * 2));
    min-inline-size: var(--atp-dialog-min-width, 250px);
    max-inline-size: var(--atp-dialog-max-width, 80vw);
    background: var(--atp-background-primary-weak);
    border: none;
    border-radius: var(--atp-border-radius-m);
    box-shadow: var(--atp-box-shadow-strong);
    overflow: auto;
    transform: translateX(-50%);
    transition: opacity var(--atp-dialog-transition-time) ease-in-out;
  }

  .dialog-header {
    position: sticky;
    inset-block-start: 0;
    display: flex;
    justify-content: flex-start;
    align-items: center;
    gap: var(--atp-space-xs);
    padding: var(--atp-dialog-padding) var(--atp-dialog-padding) var(--atp-space-s)
      var(--atp-dialog-padding);
    background: var(--atp-dialog-sticky-background-color);
  }

  .dialog-title {
    font-size: var(--atp-font-size-body-l);
    font-weight: var(--atp-font-weight-semibold);
    line-height: var(--atp-line-height-body-l);
    letter-spacing: var(--atp-letter-spacing-body);
    padding-inline-end: var(--atp-space-s); /* to leave room for the close button */
  }

  .dialog-close-button {
    position: absolute;
    inset-block-start: var(--atp-dialog-padding);
    inset-inline-end: var(--atp-dialog-padding);
    flex-grow: 9999;
    display: inline-flex;
    justify-content: flex-end;
    border: none;
    background: none;
    cursor: pointer;
  }

  .dialog-contents {
    flex-grow: 9999;
    padding: 0 var(--atp-dialog-padding) var(--atp-dialog-padding) var(--atp-dialog-padding);
  }

  .dialog-box:has(.dialog-footer) .dialog-contents {
    padding-block-end: 0;
  }

  .dialog-footer {
    position: sticky;
    inset-block-end: 0;
    display: flex;
    flex-wrap: nowrap;
    justify-content: flex-end;
    gap: var(--atp-space-xs);
    inline-size: 100%;
    padding: var(--atp-dialog-padding);
    background: var(--atp-dialog-sticky-background-color);
  }

  .dialog-footer ::slotted(div) {
    display: flex;
    flex-wrap: nowrap;
    justify-content: flex-end;
    gap: var(--atp-space-xs);
    inline-size: 100%;
  }

  .dialog.position-center .dialog-box {
    inset-block-start: 50vh;
    transform: translateX(-50%) translateY(-50%);
  }

  .dialog.drawer .dialog-box {
    inset: 0;
    transition: transform var(--atp-dialog-transition-time) ease-in-out;
    transition-behavior: allow-discrete;
  }

  /* drawer "inline-end", which for LTR languages means "right" */
  .dialog.drawer-inline-end .dialog-box {
    /*
      * CSS translate() uses X and Y rather than logical properties.
      * If we need to add RTL support for Dialog, we'll need to add additional
      * selectors using [dir="rtl"] that will change these translate() values.
    */
    inset-inline-start: unset;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    block-size: 100%;
    min-block-size: 100%;
    max-block-size: 100%;
    border-start-end-radius: 0;
    border-end-end-radius: 0;
    transform: translateX(100%);
  }

  .dialog.drawer-inline-end:modal .dialog-box {
    transform: translateX(0%);
  }

  @starting-style {
    .dialog.drawer-inline-end:modal .dialog-box {
      transform: translateX(100%);
    }
  }

  /* drawer "block-start", which for LTR languages means "top" */
  /* stylelint-disable no-descending-specificity */
  .dialog.drawer-block-start .dialog-box {
    inset-block-end: unset;
    inline-size: 100%;
    min-inline-size: 100%;
    max-inline-size: 100%;
    border-start-start-radius: 0;
    border-start-end-radius: 0;
    transform: translateY(-100%);
  }
  /* stylelint-enable no-descending-specificity */

  .dialog.drawer-block-start:modal .dialog-box {
    transform: translateY(0%);
  }

  @starting-style {
    .dialog.drawer-block-start:modal .dialog-box {
      transform: translateY(-100%);
    }
  }

  /* drawer "block-end", which for LTR languages means "bottom" */
  /* stylelint-disable no-descending-specificity */
  .dialog.drawer-block-end .dialog-box {
    inset-block-start: unset;
    inline-size: 100%;
    min-inline-size: 100%;
    max-inline-size: 100%;
    border-end-start-radius: 0;
    border-end-end-radius: 0;
    transform: translateY(100%);
    transition-behavior: allow-discrete;
  }
  /* stylelint-enable no-descending-specificity */

  .dialog.drawer-block-end:modal .dialog-box {
    transform: translateY(0%);
  }

  @starting-style {
    .dialog.drawer-block-end:modal .dialog-box {
      transform: translateY(100%);
    }
  }
`;
var D5 = Object.defineProperty, j5 = Object.getOwnPropertyDescriptor, X = (e, t, i, r) => {
  for (var a = r > 1 ? void 0 : r ? j5(t, i) : t, o = e.length - 1, s; o >= 0; o--)
    (s = e[o]) && (a = (r ? s(t, i, a) : s(a)) || a);
  return r && a && D5(t, i, a), a;
}, N5 = /* @__PURE__ */ ((e) => (e.BLOCK_START = "block-start", e.CENTER = "center", e))(N5 || {}), U5 = /* @__PURE__ */ ((e) => (e.BLOCK_END = "block-end", e.BLOCK_START = "block-start", e.INLINE_END = "inline-end", e))(U5 || {});
let I = class extends b {
  constructor() {
    super(...arguments), this.open = !1, this.label = "", this.position = "block-start", this.drawer = null, this.preventClickOnBackdrop = !1, this._hasFooterContent = !1, this._titleId = o1(), this._onEscape = (e) => {
      e.key === "Escape" && this.open && (this.open = !1);
    }, this._onFooterSlotChange = () => this._reflectFooterPresence();
  }
  _onClickCloseButton() {
    this.open = !1;
  }
  render() {
    return n`
      <dialog aria-modal="true" class=${this._getClasses()} aria-labelledby=${this._titleId}>
        <div class="dialog-box">
          <div class="dialog-header">
            ${this.iconConfig ? n`<atp-icon
                  .color="${this.iconConfig.color}"
                  .icon="${this.iconConfig.icon}"
                  .height="${this.iconConfig.height}"
                ></atp-icon>` : n``}
            <h2 class="dialog-title" id=${this._titleId}>${this.label}</h2>

            <atp-button
              class="dialog-close-button"
              .appearance=${"text"}
              .iconConfig=${{
      icon: "x",
      height: 16,
      color: "black",
      label: "Close dialog"
    }}
              @click=${this._onClickCloseButton}
            ></atp-button>
          </div>
          <div class="dialog-contents">
            <slot></slot>
          </div>
          <div class="${v({ "dialog-footer": this._hasFooterContent })}">
            <slot @slotchange=${this._onFooterSlotChange} name="footer"></slot>
          </div>
        </div>
      </dialog>
    `;
  }
  _checkExternalClick(e, t) {
    e.target === t && !this.preventClickOnBackdrop && (this.open = !1);
  }
  firstUpdated() {
    const e = this.shadowRoot?.querySelector("dialog");
    e && e.addEventListener(
      "click",
      (t) => this._checkExternalClick(t, e)
    ), window.addEventListener("keyup", this._onEscape), this._reflectFooterPresence();
  }
  disconnectedCallback() {
    window.removeEventListener("keyup", this._onEscape), window.removeEventListener("click", () => this._checkExternalClick), super.disconnectedCallback();
  }
  /*
   * We can't use the HTML `open` attribute to show/hide the dialog,
   * because some functionality (like the backdrop and the Escape key)
   * only works when using the showModal() method to open it
   */
  updated() {
    this.open ? (this.shadowRoot.querySelector("dialog")?.showModal(), this.dispatchEvent(new CustomEvent("open", { bubbles: !0, composed: !0 }))) : (this.shadowRoot.querySelector("dialog")?.close(), this.dispatchEvent(new CustomEvent("close", { bubbles: !0, composed: !0 })));
  }
  _reflectFooterPresence() {
    this._hasFooterContent = this._footerSlot?.assignedNodes({ flatten: !0 }).length > 0;
  }
  _getClasses() {
    return v({
      dialog: !0,
      "position-block-start": !this.drawer && this.position === "block-start",
      "position-center": !this.drawer && this.position === "center",
      drawer: this.drawer !== null,
      "drawer-block-end": this.drawer === "block-end",
      "drawer-block-start": this.drawer === "block-start",
      "drawer-inline-end": this.drawer === "inline-end"
      /* INLINE_END */
    });
  }
};
I.styles = [m, R5];
X([
  l({ type: Boolean })
], I.prototype, "open", 2);
X([
  l()
], I.prototype, "label", 2);
X([
  l({ type: Object })
], I.prototype, "iconConfig", 2);
X([
  l()
], I.prototype, "position", 2);
X([
  l()
], I.prototype, "drawer", 2);
X([
  l({ type: Boolean })
], I.prototype, "preventClickOnBackdrop", 2);
X([
  F1('slot[name="footer"]')
], I.prototype, "_footerSlot", 2);
I = X([
  u("atp-dialog")
], I);
const F5 = g`
  .atp-divider {
    color: var(--atp-element-border-primary-medium-enabled);
    background-color: currentColor;
    block-size: 1px;
    margin: 0;
    padding: 0;
    border: none;
  }

  .atp-divider-vertical {
    block-size: 100%;
    inline-size: 1px;
  }
`;
var q5 = Object.defineProperty, G5 = Object.getOwnPropertyDescriptor, Se = (e, t, i, r) => {
  for (var a = r > 1 ? void 0 : r ? G5(t, i) : t, o = e.length - 1, s; o >= 0; o--)
    (s = e[o]) && (a = (r ? s(t, i, a) : s(a)) || a);
  return r && a && q5(t, i, a), a;
}, W5 = /* @__PURE__ */ ((e) => (e.HORIZONTAL = "horizontal", e.VERTICAL = "vertical", e))(W5 || {});
let P1 = class extends b {
  constructor() {
    super(...arguments), this.orientation = "horizontal";
  }
  render() {
    return n`
      <div
        role="presentation"
        class="atp-divider ${this.orientation === "vertical" ? "atp-divider-vertical" : ""}"
      ></div>
    `;
  }
};
P1.styles = [m, F5];
Se([
  l()
], P1.prototype, "orientation", 2);
P1 = Se([
  u("atp-divider")
], P1);
const K5 = g`
  :host {
    display: block;
    block-size: 100%;
    inline-size: 100%;
    position: relative;
  }

  .child-dropdown {
    inset-block-start: var(--nested-menu-position);
    position: absolute;
    inset-inline-start: 100%;
  }

  .menu-item:focus-within .child-dropdown {
    display: block;
  }

  .menu-wrapper {
    background: var(--atp-element-fill-inverse-weak-enabled, #fff);
    overflow: hidden;
    padding: var(--atp-space-xxs) 0 var(--atp-space-xs) 0;
    display: flex;
    flex-direction: column;
    max-block-size: var(--atp-dropdown-max-height, 300px);
    border-radius: var(--atp-border-radius-s);
    box-shadow: var(--atp-box-shadow-medium);
  }

  .menu-container {
    overflow: hidden auto;
    list-style: none;
    margin: 0;
    padding: 0;
  }

  .menu-button {
    all: unset;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: var(--atp-space-xs);
    box-sizing: border-box;
    inline-size: 100%;
    color: var(--atp-content-primary-strong-enabled);
    font-family: var(--atpco-font-family);
    font-size: var(--atp-font-size-body-s);
    font-weight: var(--atp-font-weight-regular);
    line-height: var(--atp-line-height-body-s);
    padding: var(--atp-space-xs) var(--atp-space-s);
  }

  .menu-button .label {
    display: flex;
    align-items: center;
    gap: var(--atp-space-xs);
    max-inline-size: calc(100% - var(--left-icon-space) - var(--right-icon-space));
  }

  .menu-button .label .main-text {
    white-space: nowrap;
    overflow: hidden;
    flex-grow: 1;
    text-overflow: ellipsis;
    flex-shrink: 0;
    max-inline-size: 100%;
  }

  .menu-button .label .description-text {
    flex-shrink: 1;
    color: var(--atp-text-primary-weak-enabled);
    font-family: var(--atpco-font-family);
    font-size: var(--atp-font-size-body-xs);
    font-weight: var(--atp-font-weight-semibold);
    line-height: var(--atp-line-height-body-xs);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    max-inline-size: 100%;
  }

  .menu-button .label.top,
  .menu-button .label.bottom {
    align-items: flex-start;
    gap: var(--atp-space-xxxs);
  }

  .menu-button .label.left {
    flex-direction: row-reverse;
  }

  .menu-button .label.top {
    flex-direction: column-reverse;
  }

  .menu-button .label.bottom {
    flex-direction: column;
  }

  .menu-button:not(:has(.description)) .label {
    flex-grow: 1;
  }

  .menu-button:is(.active) {
    background: var(--atp-element-fill-blue-medium-enabled);
  }

  .menu-button:focus-visible,
  .menu-button:hover {
    background: var(--atp-element-fill-inverse-weak-hover);
  }

  .menu-button.is-keyboard:focus-visible {
    box-shadow: inset 0 0 0 2px var(--atp-focus-color);
  }

  .menu-button:active {
    background: var(--atp-element-fill-inverse-weak-pressed);
  }

  .search-bar {
    display: flex;
    align-items: center;
    margin: var(--atp-space-xxs) var(--atp-space-xs);
    padding: var(--atp-space-xs);
    gap: var(--atp-space-xs);
    border-radius: var(--atp-border-radius-s);
    border: 1px solid var(--atp-element-border-primary-strong-enabled);
    background: var(--atp-element-fill-inverse-weak-enabled);
  }

  .search-bar .search-input {
    border: none;
    font-family: var(--atpco-font-family);
    font-size: var(--atp-font-size-body-s);
    font-weight: var(--atp-font-weight-regular);
    line-height: var(--atp-line-height-body-s);
    flex-grow: 1;
  }

  .search-bar .search-input:focus {
    outline: none;
    box-shadow: none;
  }

  .title-item {
    block-size: var(--atp-space-l);
    padding: calc(var(--atp-space-xxxs) + var(--atp-space-xxs)) var(--atp-space-s)
      var(--atp-space-xxxs) 0;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: var(--atp-space-xxs);
    margin-inline-start: var(--atp-space-s);
    border-block-end: 1px solid var(--atp-element-border-primary-medium-enabled);
  }

  .title-item .title-label {
    color: var(--atp-content-primary-medium-enabled);
    font-family: var(--atpco-font-family);
    font-size: var(--atp-font-size-body-xs);
    font-weight: var(--atp-font-weight-regular);
    line-height: var(--atp-line-height-body-xs);
    margin: 0;
  }

  .title-item .title-button {
    all: unset;
    cursor: pointer;
    color: var(--atp-button-primary-medium-enabled);
    font-family: var(--atpco-font-family);
    font-size: var(--atp-font-size-body-s);
    font-weight: var(--atp-font-weight-semibold);
    line-height: var(--atp-line-height-body-s);
  }

  .title-item .title-button:active,
  .title-item .title-button:hover,
  .title-item .title-button:focus-visible {
    text-decoration: underline;
  }

  .title-item .title-button.is-keyboard:focus-visible {
    outline: var(--atp-focus-width) solid var(--atp-focus-color);
    outline-offset: var(--atp-focus-outline-offset);
  }
`;
const J1 = ce(class extends pe {
  constructor(e) {
    if (super(e), e.type !== de.ATTRIBUTE || e.name !== "class" || e.strings?.length > 2) throw Error("`classMap()` can only be used in the `class` attribute and must be the only part in the attribute.");
  }
  render(e) {
    return " " + Object.keys(e).filter(((t) => e[t])).join(" ") + " ";
  }
  update(e, [t]) {
    if (this.st === void 0) {
      this.st = /* @__PURE__ */ new Set(), e.strings !== void 0 && (this.nt = new Set(e.strings.join(" ").split(/\s/).filter(((r) => r !== ""))));
      for (const r in t) t[r] && !this.nt?.has(r) && this.st.add(r);
      return this.render(t);
    }
    const i = e.element.classList;
    for (const r of this.st) r in t || (i.remove(r), this.st.delete(r));
    for (const r in t) {
      const a = !!t[r];
      a === this.st.has(r) || this.nt?.has(r) || (a ? (i.add(r), this.st.add(r)) : (i.remove(r), this.st.delete(r)));
    }
    return W;
  }
});
var Y5 = /* @__PURE__ */ ((e) => (e.DEFAULT = "", e.PRIMARY = "primary", e.SECONDARY = "secondary", e.ACCENT = "accent", e.SUCCESS = "success", e.WARNING = "warning", e.DANGER = "danger", e.WEAK = "weak", e.STRONG = "strong", e.INVERSE = "inverse", e.TERTIARY = "tertiary", e.DISABLED = "disabled", e.UTILITY = "utility", e))(Y5 || {}), X5 = /* @__PURE__ */ ((e) => (e.LARGE = "large", e.MEDIUM = "medium", e.SMALL = "small", e))(X5 || {}), q = /* @__PURE__ */ ((e) => (e.LEFT = "left", e.RIGHT = "right", e.TOP = "top", e.BOTTOM = "bottom", e))(q || {}), J5 = Object.defineProperty, Q5 = Object.getOwnPropertyDescriptor, z = (e, t, i, r) => {
  for (var a = r > 1 ? void 0 : r ? Q5(t, i) : t, o = e.length - 1, s; o >= 0; o--)
    (s = e[o]) && (a = (r ? s(t, i, a) : s(a)) || a);
  return r && a && J5(t, i, a), a;
};
let _ = class extends b {
  constructor() {
    super(), this.itemsList = [], this.isMenuVisible = !1, this.isSearchVisible = !1, this.searchValue = "", this.activeIds = [], this.placeholder = "Search", this.openAtActiveIndex = !1, this.closeOnClickOutside = !0, this.maxHeight = "300px", this.showCheckmarks = !1, this.visualPosition = q.RIGHT, this._hasClickedOnce = !1, this._focusIndex = -1, this._titleList = [], this._activeItem = { position: 0, id: "", children: [], index: 0 }, this._isKeyboard = !1, this._clickOutsideHandler = (e) => {
      Be(e, this) && this._hasClickedOnce && this.closeOnClickOutside && this._closeDropdown(), this._hasClickedOnce = !0;
    };
  }
  render() {
    return n`
      ${this.isMenuVisible ? n`
            <div style="--atp-dropdown-max-height: ${this.maxHeight}" class="menu-wrapper">
              <slot name="above-menu-content"></slot>
              ${this.isSearchVisible ? n`
                    <div class="search-bar">
                      <atp-icon height="14" icon="search"></atp-icon>
                      <input
                        .value=${this.searchValue}
                        class="search-input"
                        type="search"
                        aria-label="Search"
                        placeholder="${this.placeholder}"
                        @input=${(e) => this.searchValue = e.target.value}
                        @keydown=${(e) => this._onItemKeydown(e, 0)}
                      />
                    </div>
                  ` : ""}
              <ul class="menu-container">
                ${this.filteredItemList.map(
      (e, t) => n`<li class="menu-item">
                      ${e.isTitle ? n`<div class="title-item">
                            <p class="title-label">${e.name}</p>
                            ${this.filteredItemList.length !== this.itemsList.length || !e.titleAction ? n`<span class="title-button"></span>` : n`<button
                                  @click=${() => this._selectAll(t + 1, this._titleList[t])}
                                  @mousemove=${() => this._focusItem(t + (this.isSearchVisible ? 1 : 0), !0)}
                                  @keydown=${(i) => this._onItemKeydown(i, t + (this.isSearchVisible ? 1 : 0))}
                                  class="title-button ${J1({
        "is-keyboard": this._isKeyboard
      })}"
                                >
                                  ${this._titleList[t] ? "Deselect All" : "Select All"}
                                </button>`}
                          </div>` : n`<button
                            @click=${() => this._onClick(e)}
                            @focus=${() => this._focusHandler(e, t)}
                            @mousemove=${() => this._focusItem(t + (this.isSearchVisible ? 1 : 0), !0)}
                            @keydown=${(i) => this._onItemKeydown(
        i,
        t + (this.isSearchVisible ? 1 : 0),
        e.children?.length > 0
      )}
                            ?disabled=${e.isDisabled}
                            class="menu-button ${J1({
        active: this.activeIds.includes(e.id),
        "is-keyboard": this._isKeyboard
      })}"
                          >
                            ${this.showCheckmarks ? n`<atp-icon
                                  color="${this.activeIds.includes(e.id) ? "var(--atp-content-primary-medium-enabled)" : "transparent"}"
                                  height="16"
                                  icon="check"
                                ></atp-icon>` : ""}
                            ${e.icon ? n`<atp-icon
                                  .color="${e.icon.color}"
                                  .height="${e.icon.height}"
                                  .icon="${e.icon.icon}"
                                ></atp-icon>` : ""}
                            <span
                              style="--left-icon-space: ${!this.showCheckmarks && !e.icon ? "0" : "var(--atp-space-m)"};--right-icon-space: ${e.children?.length > 0 ? "var(--atp-space-m)" : "0"};"
                              class="label ${J1({
        right: this.visualPosition === q.RIGHT,
        left: this.visualPosition === q.LEFT,
        top: this.visualPosition === q.TOP,
        bottom: this.visualPosition === q.BOTTOM
      })}"
                            >
                              <span class="main-text">${e.name}</span>
                              ${e.description ? n`<span class="description-text">${e.description}</span>` : ""}
                            </span>
                            ${e.children?.length > 0 ? n`<atp-icon height="16" icon="chevron-right"></atp-icon>` : ""}
                          </button>`}
                    </li>`
    )}
              </ul>
            </div>
            ${this._activeItem.children.length > 0 ? n`<atp-dropdown
                  @keydown="${(e) => this._handleChildKeydown(e)}"
                  id="child-dropdown"
                  @childSelectedOutput="${(e) => this._handleChildClick(e)}"
                  class="child-dropdown"
                  style="--nested-menu-position: ${this._activeItem.position}px;"
                  .isMenuVisible=${!0}
                  .itemsList="${this._activeItem.children}"
                  .activeIds="${this.activeIds}"
                  .showCheckmarks=${!0}
                ></atp-dropdown>` : ""}
          ` : ""}
    `;
  }
  get filteredItemList() {
    const e = this.itemsList.filter((t) => this._filterMenuItem(t));
    return e.filter((t, i) => !(t.isTitle && (i === e.length - 1 || e[i + 1].isTitle)));
  }
  connectedCallback() {
    super.connectedCallback(), window.addEventListener("click", this._clickOutsideHandler);
  }
  disconnectedCallback() {
    window.removeEventListener("click", this._clickOutsideHandler), super.disconnectedCallback();
  }
  async updated(e) {
    super.updated(e), await this.updateComplete, e.has("isMenuVisible") && this.isMenuVisible && this.openAtActiveIndex && this._handleOpenAtActive(), e.has("itemList") && (this._titleList = Array(this.itemsList.length).fill(!1)), e.has("activeIds") && this._setTitleButtons(), e.has("isMenuVisible") && this.requestUpdate();
  }
  _handleChildClick({ detail: e }) {
    this._onClick(e);
  }
  startKeyScrolling() {
    this._hasClickedOnce = !1, this._focusIndex = -1, this.isMenuVisible = !0, this.updateComplete.then(() => this._focusItem(0, !1));
  }
  disableKeyScrolling() {
    this.isMenuVisible = !1, this._focusIndex = -1;
  }
  _closeDropdown() {
    this.isMenuVisible && this.dispatchEvent(new CustomEvent("dropdownClosedOutput", { bubbles: !0, composed: !0 }));
  }
  _onClick(e) {
    const t = this.activeIds.includes(e.id) ? this.activeIds.filter((i) => i !== e.id) : [e.id, ...this.activeIds];
    this.dispatchEvent(
      new CustomEvent("itemSelectedOutput", {
        detail: t,
        bubbles: !0,
        composed: !0
      })
    );
  }
  _filterMenuItem(e) {
    return !this.isSearchVisible || e.name.toLocaleLowerCase().startsWith(this.searchValue.toLocaleLowerCase()) || e.isTitle;
  }
  _focusHandler(e, t) {
    let i = 0;
    if (e.children?.length > 0 && this.isMenuVisible)
      for (let r = 0; r < t; r++)
        this.visualPosition === q.TOP || this.visualPosition === q.BOTTOM ? i += 48 : i += 32;
    this._activeItem = {
      id: e.id,
      position: i,
      children: e.children ?? [],
      index: t
    }, this.requestUpdate();
  }
  _selectAll(e, t) {
    let i = [...this.activeIds];
    for (; e < this.filteredItemList.length && !this.filteredItemList[e].isTitle; )
      t ? i = i.filter((r) => r !== this.filteredItemList[e].id) : i.includes(this.filteredItemList[e].id) || i.push(this.filteredItemList[e].id), e++;
    this.dispatchEvent(
      new CustomEvent("itemSelectedOutput", {
        detail: i,
        bubbles: !0,
        composed: !0
      })
    );
  }
  _setTitleButtons() {
    let e = 0, t = !0;
    for (let i = 1; i < this.itemsList.length; i++)
      this.itemsList[i].isTitle ? (this._titleList[e] = t, e = i, t = !0) : this.activeIds?.includes(this.itemsList[i].id) || (t = !1);
    this._titleList[e] = t, this.requestUpdate();
  }
  _handleChildKeydown(e) {
    e.key === "ArrowLeft" && this._focusItem(this._activeItem.index, !1, 1, !0);
  }
  _onItemKeydown(e, t, i = !1) {
    if (this.isMenuVisible) {
      e.key === "ArrowRight" && i ? this.updateComplete.then(() => this._childDropdown?.startKeyScrolling()) : this._childDropdown?.disableKeyScrolling();
      const r = this.filteredItemList.length + (this.isSearchVisible ? 1 : 0);
      e.key === "ArrowDown" ? (e.preventDefault(), this.updateComplete.then(() => this._focusItem((t + 1) % r, !1))) : e.key === "ArrowUp" ? (e.preventDefault(), this.updateComplete.then(
        () => this._focusItem((t - 1 + r) % r, !1, -1)
      )) : (e.key === "Escape" || e.key === "Tab") && this._closeDropdown();
    }
  }
  _focusItem(e, t, i = 1, r = !1) {
    if (e !== this._focusIndex || r) {
      const a = Array.from(
        this.shadowRoot?.querySelectorAll(
          ".search-input, .menu-item .menu-button, .menu-item .title-button"
        ) || []
      ), o = this.filteredItemList[e - (this.isSearchVisible ? 1 : 0)]?.isTitle && (!this.filteredItemList[e - (this.isSearchVisible ? 1 : 0)]?.titleAction || this.filteredItemList.length !== this.itemsList.length) ? e + 1 * i : e;
      this._focusIndex = o, a?.[o]?.focus({ preventScroll: !0 }), t || a?.[o]?.scrollIntoView({ behavior: "auto", block: "nearest" }), this._isKeyboard = !t, this.requestUpdate();
    }
  }
  async _handleOpenAtActive() {
    await this.updateComplete, this.filteredItemList.forEach((t, i) => {
      this.activeIds.includes(t.id) && this._focusItem(i, !1);
    });
    let e = !1;
    for (const [t, i] of this.filteredItemList.entries())
      if (i.children?.some((r) => this.activeIds.includes(r.id))) {
        this._focusHandler(i, t), e = !0, this._focusIndex = -1;
        for (const [r, a] of i.children.entries())
          this.activeIds.includes(a.id) && (await this.updateComplete, this._childDropdown._focusItem(r, !1));
      }
    e || (this._activeItem = { position: 0, id: "", children: [], index: 0 });
  }
};
_.styles = [m, K5];
z([
  l({ type: Array })
], _.prototype, "itemsList", 2);
z([
  l({ type: Boolean })
], _.prototype, "isMenuVisible", 2);
z([
  l({ type: Boolean })
], _.prototype, "isSearchVisible", 2);
z([
  l()
], _.prototype, "searchValue", 2);
z([
  l({ type: Array })
], _.prototype, "activeIds", 2);
z([
  l()
], _.prototype, "placeholder", 2);
z([
  l({ type: Boolean })
], _.prototype, "openAtActiveIndex", 2);
z([
  l({ type: Boolean })
], _.prototype, "closeOnClickOutside", 2);
z([
  l()
], _.prototype, "maxHeight", 2);
z([
  l({ type: Boolean })
], _.prototype, "showCheckmarks", 2);
z([
  l()
], _.prototype, "visualPosition", 2);
z([
  F1("#child-dropdown")
], _.prototype, "_childDropdown", 2);
_ = z([
  u("atp-dropdown")
], _);
const et = g`
  .header-wrapper {
    display: flex;
    align-items: center;
    justify-content: space-between;
    background: var(--atp-element-fill-header-global-header-medium-enabled);
    block-size: var(--atp-space-xl);
  }

  .header-left {
    display: flex;
    align-items: center;
    flex-shrink: 0;
  }

  .menu-wrapper {
    position: relative;
  }

  .org-menu-wrapper {
    position: relative;
    margin-inline-start: var(--atp-space-m);
  }

  .menu {
    position: absolute;
    inset-block-start: calc(100% + var(--atp-space-xxs));
    inline-size: fit-content;
  }

  .header-right {
    display: flex;
    align-items: center;
    padding: 0 var(--atp-space-m);
    gap: var(--atp-space-s);
    flex-shrink: 0;
    flex-grow: 1;
    justify-content: flex-end;
    min-inline-size: fit-content;
  }

  button:focus-visible {
    border-radius: var(--atp-border-radius-m);
    outline: var(--atp-focus-width) solid var(--atp-button-inverse-medium-enabled);
    outline-offset: var(--atp-focus-outline-offset);
  }

  .logo-button {
    all: unset;
    cursor: pointer;
    margin-inline-start: calc(var(--atp-space-m) + var(--atp-space-xxs));
  }

  .page-title {
    margin: 0;
    margin-inline-start: var(--atp-space-xs);
    color: var(--atp-button-inverse-medium-enabled);
    font-family: var(--atpco-font-family);
    font-size: var(--atp-font-size-heading-xs);
    font-weight: var(--atp-font-weight-bold);
    line-height: var(--atp-line-height-heading-xs);
  }

  .org-button {
    --atp-icon-fill: currentColor;

    all: unset;
    box-sizing: border-box;
    block-size: var(--atp-space-m);
    border-radius: var(--atp-space-xs);
    padding: var(--atp-space-xxs) var(--atp-space-xs);
    display: flex;
    align-items: center;
    gap: var(--atp-space-xxs);
    border: 1px solid var(--atp-button-inverse-medium-enabled);
    color: var(--atp-button-inverse-medium-enabled);
    text-align: center;
    font-family: var(--atpco-font-family);
    font-size: var(--atp-font-size-body-xs);
    font-weight: var(--atp-font-weight-regular);
    line-height: var(--atp-line-height-body-xs);
  }

  button.org-button:hover,
  button.org-button:focus-visible {
    cursor: pointer;
    background: var(--atp-element-fill-header-global-icon-not-selected-hover);
    border: 1px solid var(--atp-button-inverse-medium-enabled);
    box-shadow: 0 0 0 1px var(--atp-button-inverse-medium-enabled);
  }

  button.org-button:active {
    background: var(--atp-element-fill-header-global-icon-not-selected-pressed);
    border: 1px solid var(--atp-button-inverse-medium-enabled);
    box-shadow: 0 0 0 1px var(--atp-button-inverse-medium-enabled);
  }

  button.org-button.active {
    background: var(--atp-element-fill-header-global-icon-selected-enabled);
    border: 1px solid var(--atp-element-fill-header-global-icon-selected-enabled);
    color: var(--atp-content-primary-strong-enabled);
    box-shadow: 0 0 0 1px var(--atp-element-fill-header-global-icon-selected-enabled);
  }

  button.org-button.active:hover,
  button.org-button.active:focus-visible {
    background: var(--atp-element-fill-header-global-icon-selected-hover);
    border: 1px solid var(--atp-element-fill-header-global-icon-selected-hover);
    color: var(--atp-content-primary-strong-enabled);
    box-shadow: 0 0 0 1px var(--atp-element-fill-header-global-icon-selected-hover);
  }

  button.org-button.active:active {
    border: 1px solid var(--atp-element-fill-primary-strong-pressed);
    background: var(--atp-element-fill-header-global-icon-selected-pressed);
    color: var(--atp-button-inverse-medium-enabled);
    box-shadow: 0 0 0 1px var(--atp-element-fill-primary-strong-pressed);
  }

  .divider {
    all: unset;
    cursor: pointer;
    inline-size: 1px;
    block-size: var(--atp-space-m);
    display: block;
    border-radius: var(--atp-border-radius-xs);
    background-color: var(--atp-element-border-primary-strong-enabled);
  }

  .icon-button {
    --atp-icon-fill: var(--atp-button-inverse-medium-enabled);

    all: unset;
    box-sizing: border-box;
    cursor: pointer;
    block-size: var(--atp-space-l);
    inline-size: var(--atp-space-l);
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: var(--atp-border-radius-s);
    background: var(--atp-element-fill-header-global-header-medium-enabled);
    border: var(--atp-space-xxxs) solid var(--atp-element-fill-header-global-header-medium-enabled);
  }

  .icon-button:hover,
  .icon-button:focus-visible {
    background: var(--atp-element-fill-header-global-icon-not-selected-hover);
    border: var(--atp-space-xxxs) solid
      var(--atp-element-fill-header-global-icon-not-selected-hover);
  }

  .icon-button:active {
    background: var(--atp-element-fill-header-global-icon-not-selected-pressed);

    /* TODO: this border color is listed only as a primitive in figma, borrowing var that maps to same primitive */

    border: var(--atp-space-xxxs) solid var(--atp-element-fill-header-global-icon-selected-hover);
  }

  .icon-button.active {
    --atp-icon-fill: var(--atp-content-primary-medium-enabled);

    background: var(--atp-element-fill-header-global-icon-selected-enabled);
    border: 2px solid var(--atp-element-fill-header-global-icon-selected-enabled);
  }

  .icon-button.active:hover,
  .icon-button.active:focus-visible {
    background: var(--atp-element-fill-header-global-icon-selected-hover);
    border: 2px solid var(--atp-element-fill-header-global-icon-selected-hover);
  }

  .icon-button.active:active {
    border: 2px solid var(--atp-element-fill-primary-strong-pressed);
    background: var(--atp-element-fill-header-global-icon-selected-pressed);
  }

  .search-wrapper {
    display: flex;
    inline-size: var(--atp-space-l);
    justify-content: flex-end;
    transition: width 0.2s ease-out;
    max-inline-size: 32px;
  }

  .pill-slot {
    margin-inline-start: var(--atp-space-m);
    display: block;
  }

  .search-wrapper .icon-button {
    flex-shrink: 0;
  }

  .search-wrapper .search-input {
    max-inline-size: 0;
    padding: 0;
    border: 0;
  }

  .search-wrapper.search-wrapper--active {
    max-inline-size: 243px;
    inline-size: unset;
    flex-grow: 1;
  }

  .search-wrapper.search-wrapper--active .search-input {
    /** TODO: --Element-Fill-Header-Global-Icon-Selected-Enabled (#B9C1C9) used in figma, it is not in color variable file */
    border: 1px solid var(--atp-slate-400);
    border-inline-start: none;
    outline: none;
    padding: calc(var(--atp-space-xs) - 1px);
    max-inline-size: 211px;
    flex-grow: 1;
    border-radius: 0 var(--atp-border-radius-s) var(--atp-border-radius-s) 0;
    background-color: var(--atp-element-fill-inverse-weak-enabled);
    color: var(--atp-content-primary-medium-enabled);
    font-family: var(--atpco-font-family);
    font-size: var(--atp-font-size-body-s);
    font-weight: var(--atp-font-weight-regular);
    line-height: var(--atp-line-height-body-s);
  }

  .search-wrapper.search-wrapper--active .icon-button {
    --atp-icon-fill: var(--atp-button-primary-medium-enabled);

    background: var(--atp-slate-400);
    border-start-end-radius: 0;
    border-end-end-radius: 0;
  }

  .icon-dropdown {
    position: relative;
  }

  .dropdown-wrapper {
    position: absolute;
    inset-block-start: calc(100% + var(--atp-space-xxxs));
  }

  .dropdown-wrapper.right {
    inset-inline-end: 0;
  }
`, tt = `<svg width="65" height="27" viewBox="0 0 65 27" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path
        d="M64.4 14.4207C64.4 11.4941 61.8702 9.14453 58.7518 9.14453C55.6335 9.14453 53.13 11.4941 53.13 14.4207V17.5781C53.13 20.5047 55.6335 22.8542 58.7518 22.8542C60.5614 22.8542 61.7209 22.0216 61.7209 22.0216V21.766C61.5188 21.8155 60.781 22.0216 60.087 22.0216C56.1781 22.0216 54.3686 19.7875 54.3686 17.5863V14.4289C54.3686 12.1536 56.3274 10.3152 58.7518 10.3152C61.1762 10.3152 63.1614 12.1536 63.1614 14.4289V16.9598C63.1614 18.1716 62.1688 19.5154 60.087 19.5154C58.0052 19.5154 57.0389 18.5426 57.0389 17.5863V14.4289C57.0389 13.5221 57.7856 12.8213 58.7518 12.8213C59.7181 12.8213 60.4823 13.5221 60.4823 14.4289V18.3365C60.9742 18.3118 61.7209 17.9903 61.7209 17.3637V14.4371C61.7209 12.9038 60.3857 11.6754 58.7518 11.6754C57.118 11.6754 55.8092 12.9038 55.8092 14.4371V17.5946C55.8092 19.1279 57.1443 20.6861 60.0958 20.6861C63.0473 20.6861 64.4 18.7322 64.4 16.968V14.4371V14.4207Z"
        fill="#EBF2FE"
      />
      <path
        d="M50.7068 14.0744C50.5029 11.288 48.2435 9.14453 45.4866 9.14453C43.8063 9.14453 42.7296 9.98541 42.7296 9.98541V10.241C42.9172 10.1915 43.6024 9.98541 44.2468 9.98541C47.0037 9.98541 48.6351 11.3127 49.2794 12.912H47.7868C47.1913 12.0052 46.0168 11.3292 44.2468 11.3292C41.5143 11.3292 40.25 13.283 40.25 15.0472V17.5781C40.25 20.5047 42.5991 22.8542 45.4947 22.8542C48.3904 22.8542 50.5111 20.6448 50.715 17.9243H47.0608C46.8732 18.6003 46.2288 19.1774 45.4947 19.1774C44.5975 19.1774 43.8879 18.4767 43.8879 17.5698V13.6622C43.4311 13.6869 42.7378 14.0085 42.7378 14.635V17.5616C42.7378 19.095 43.9776 20.3233 45.4947 20.3233C46.4409 20.3233 47.2892 19.8369 47.7949 19.0702H49.2631C48.6432 20.6036 47.1913 21.6753 45.4947 21.6753C43.2435 21.6753 41.4001 19.8369 41.4001 17.5616V15.0307C41.4001 13.8188 42.3218 12.4751 44.2549 12.4751C45.9597 12.4751 46.8569 13.217 47.0608 14.0579H50.715L50.7068 14.0744Z"
        fill="#EBF2FE"
      />
      <path
        d="M30.1893 22.5996C30.5077 22.8089 31.2913 23.0685 31.7811 23.0685C34.679 23.0685 37.0299 20.6822 37.0299 17.7099V14.5031C37.0299 11.5308 34.7035 9.14453 31.8056 9.14453C30.124 9.14453 29.0465 9.99856 29.0465 9.99856V10.2581C29.2342 10.2079 29.9199 9.99856 30.5648 9.99856C34.1974 9.99856 35.879 12.2676 35.879 14.5031V17.7099C35.879 20.0208 34.0341 21.8879 31.7811 21.8879C30.7444 21.8879 29.7812 21.486 29.0465 20.7994V25.7059H27.7159V15.1311C27.7159 13.9003 28.6139 12.5355 30.5485 12.5355C32.4831 12.5355 33.4056 13.5235 33.4056 14.4947V17.7015C33.4056 18.6225 32.6954 19.3342 31.7974 19.3342C30.8995 19.3342 30.2057 18.6058 30.2057 17.6848V13.7412C29.7485 13.7663 29.0547 14.0928 29.0547 14.7292V17.6764C29.0547 19.2337 30.271 20.5064 31.7893 20.5064C33.3076 20.5064 34.5484 19.2589 34.5484 17.7015V14.4947C34.5484 12.9374 33.2831 11.3549 30.5485 11.3549C27.8139 11.3549 26.5649 13.3393 26.5649 15.1311V26.8865H30.1975V22.5912L30.1893 22.5996Z"
        fill="#EBF2FE"
      />
      <path
        d="M24.1501 19.2576C23.7339 19.3736 23.1703 19.4896 22.5374 19.4896C20.4825 19.4896 19.5288 18.5119 19.5288 17.5508V13.3915H22.8322V9.70442H19.5288V5.91797H17.8901L13.6851 10.7981V13.3915H15.6619V17.5508C15.6619 20.4921 18.1329 22.8535 21.2108 22.8535C22.9969 22.8535 24.1414 22.0166 24.1414 22.0166V21.7598C23.942 21.8095 23.2137 22.0166 22.5287 22.0166C18.6705 22.0166 16.8844 19.7713 16.8844 17.559V12.2315H14.9076V11.2289L18.3063 7.28507V10.881H21.6097V12.2315H18.3063V17.559C18.3063 19.1001 19.6242 20.6661 22.5374 20.6661C23.2223 20.6661 23.6819 20.6164 24.1501 20.5004V19.2658V19.2576Z"
        fill="#EBF2FE"
      />
      <path
        d="M12.075 18.6555C11.47 18.5153 11.0983 18.1441 11.0983 17.5832V14.4238C11.0983 11.0748 8.51387 9.14453 4.97867 9.14453C3.82908 9.14453 2.71407 9.51573 1.97937 9.77145V13.1865C2.63627 12.9803 3.38826 12.8153 4.48599 12.8153C6.18876 12.8153 7.58037 13.302 8.46201 14.2094C8.19406 12.8153 7.00125 11.6522 4.73665 11.6522C4.00195 11.6522 3.1981 11.8584 3.1981 11.8584V10.5798C3.1981 10.5798 3.90687 10.2994 4.97867 10.2994C7.8051 10.2994 9.87955 11.8089 9.87955 14.4156V17.8141C9.87955 18.5318 10.2685 18.9525 10.8563 19.3484V20.8332C10.2253 20.7177 9.63753 20.4125 9.22264 19.7609C8.48794 20.924 7.13091 21.6911 5.56643 21.6911C3.18082 21.6911 1.22738 19.8764 1.22738 18.0204C1.22738 16.3211 2.59306 15.323 4.25261 15.323C5.79116 15.323 7.25191 15.7849 7.25191 17.5584C7.25191 18.4658 6.51722 19.1834 5.56643 19.1834C4.61564 19.1834 3.86365 18.4658 3.86365 17.5584V16.5108C3.35369 16.5355 2.64492 16.9562 2.64492 18.0204C2.64492 19.2082 3.95873 20.3465 5.56643 20.3465C7.17412 20.3465 8.46201 19.0927 8.46201 17.5584C8.46201 14.9105 6.41349 14.1599 4.24397 14.1599C1.90157 14.1599 0 15.5787 0 18.0204C0 20.462 2.48933 22.8542 5.55778 22.8542C7.01854 22.8542 8.35829 22.318 9.36093 21.4354C10.1389 21.9468 11.0637 22.2273 12.0664 22.2273V18.6473L12.075 18.6555Z"
        fill="#EBF2FE"
      />
    </svg>`;
var it = Object.defineProperty, at = Object.getOwnPropertyDescriptor, N = (e, t, i, r) => {
  for (var a = r > 1 ? void 0 : r ? at(t, i) : t, o = e.length - 1, s; o >= 0; o--)
    (s = e[o]) && (a = (r ? s(t, i, a) : s(a)) || a);
  return r && a && it(t, i, a), a;
};
let O = class extends b {
  constructor() {
    super(...arguments), this.label = "", this.org = "", this.isSwitchable = !1, this.hasSearch = !1, this._searchOpen = !1, this._menuMap = {}, this._activeIconId = "";
  }
  render() {
    return n`
      <header role="banner" class="header-wrapper">
        <div class="header-left">
          <a
            aria-label="Go to home page"
            href="${this.homeHref}"
            @click=${(e) => this._goHome(e)}
            class="logo-button"
          >
            <atp-icon aria-hidden="true" height="26" .icon=${tt}></atp-icon>
          </a>
          <div class="page-title">${this.label}</div>
          <div class="org-menu-wrapper">
            ${this.isSwitchable ? n`<button
                  @click="${() => this._toggleMenu(
      "org-switcher",
      !this._menuMap["org-switcher"].visible,
      this._menuMap["org-switcher"]
    )}"
                  aria-haspopup="listbox"
                  class="org-button ${this._activeIconId === "org-switcher" ? "active" : ""}"
                >
                  ${this.org}
                  <atp-icon aria-hidden="true" height="12" icon="chevron-down"></atp-icon>
                </button>` : n`<div class="org-button">${this.org}</div>`}
            <div class="menu">
              <slot name="org-list"></slot>
            </div>
          </div>
          <slot class="pill-slot" name="pill"></slot>
        </div>
        <div class="header-right">
          ${this.hasSearch ? n`
                <div class="${this._getSearchClasses()}">
                  <button
                    aria-expanded="${this._searchOpen}"
                    aria-label="${this._searchOpen ? "Search for a term" : "Expand the search bar"}"
                    @click=${this._searchHandler}
                    class="icon-button ${this._searchOpen ? "active" : ""}"
                  >
                    <atp-icon icon="search"></atp-icon>
                  </button>
                  <input
                    ?hidden=${!this._searchOpen}
                    id="search-input"
                    class="search-input"
                    type="text"
                  />
                </div>
              ` : c}
          ${this.hasSearch && this.iconActions?.length > 0 ? n`<div class="divider"></div>` : c}
          ${this.iconActions?.length > 0 ? this.iconActions.map(
      (e) => n`
                  <div class="icon-dropdown">
                    <button
                      aria-label="${e.label}"
                      aria-haspopup="listbox"
                      @click=${() => this._toggleMenu(
        e.id,
        !this._menuMap[e.id]?.visible,
        this._menuMap[e.id]
      )}
                      class="icon-button ${this._activeIconId === e.id ? "active" : ""}"
                    >
                      <atp-icon
                        aria-hidden="true"
                        .icon=${e.icon}
                        .badge=${e.badge}
                      ></atp-icon>
                    </button>
                    <div class="dropdown-wrapper ${e.rightAligned ? "right" : ""}">
                      <slot
                        @slotchange=${() => this._setUpSlotMap()}
                        class="dropdown-wrapper ${e.rightAligned ? "right" : ""}"
                        .name=${e.id}
                      ></slot>
                    </div>
                  </div>
                `
    ) : c}
        </div>
      </header>
    `;
  }
  async firstUpdated() {
    await this._setUpSlotMap();
  }
  async _setUpSlotMap() {
    await this.updateComplete, this.addEventListener("dropdownClosedOutput", this._toggleAllWrapper), this.addEventListener("itemSelectedOutput", this._toggleAllWrapper), this.renderRoot.querySelectorAll(
      'slot[name="user-menu"], slot[name="org-list"]'
    ).forEach((t) => {
      const i = t.assignedElements({ flatten: !0 })[0];
      i && (this._menuMap[i.id] = { ref: i, visible: !1 });
    });
  }
  disconnectedCallback() {
    this.removeEventListener("dropdownClosedOutput", this._toggleAllWrapper), this.removeEventListener("itemSelectedOutput", this._toggleAllWrapper), super.disconnectedCallback();
  }
  _toggleAllWrapper() {
    this._toggleMenu("all", !1, !0);
  }
  /** TODO: eventually remove hasDropdown arguement as all these toggles should have dropdown */
  _toggleMenu(e, t, i = !1) {
    i && (e === "all" ? (Object.values(this._menuMap).forEach((r) => {
      r?.ref?.disableKeyScrolling(), r.visible = t;
    }), this._activeIconId = "") : (t ? (this._menuMap[e]?.ref.startKeyScrolling(), this._activeIconId = e) : (this._activeIconId = "", this._menuMap[e]?.ref.disableKeyScrolling()), this._menuMap[e].visible = t), this.requestUpdate());
  }
  _getSearchClasses() {
    return v({ "search-wrapper": !0, "search-wrapper--active": this._searchOpen });
  }
  _goHome(e) {
    this.homeHref || (e.preventDefault(), this.dispatchEvent(new CustomEvent("homeEventOutput", { bubbles: !0, composed: !0 })));
  }
  _searchHandler() {
    const e = this.renderRoot.querySelector("#search-input");
    this._searchOpen ? this.dispatchEvent(
      new CustomEvent("searchEventOutput", { bubbles: !0, composed: !0, detail: e.value })
    ) : (this._searchOpen = !0, e?.focus(), this._searchOpen = !0, this.requestUpdate());
  }
};
O.styles = [m, et];
N([
  l()
], O.prototype, "label", 2);
N([
  l()
], O.prototype, "org", 2);
N([
  l({ type: Boolean })
], O.prototype, "isSwitchable", 2);
N([
  l({ type: Boolean })
], O.prototype, "hasSearch", 2);
N([
  l({ type: Array })
], O.prototype, "iconActions", 2);
N([
  l()
], O.prototype, "homeHref", 2);
N([
  z1({ slot: "org-list" })
], O.prototype, "_slottedOrgElements", 2);
N([
  z1({ slot: "dropdowns" })
], O.prototype, "_slottedDropdownElements", 2);
O = N([
  u("atp-header")
], O);
const rt = g`
  .field-wrapper {
    display: flex;
    box-sizing: border-box;
    flex-direction: column;
    gap: var(--atp-space-xxs);
  }

  .field-wrapper .field-label {
    position: relative;
    inline-size: fit-content;
    color: var(--atp-content-primary-medium-enabled);
    font-family: var(--atpco-font-family);
    font-size: var(--atp-font-size-body-s);
    font-weight: var(--atp-font-weight-regular);
    line-height: var(--atp-line-height-body-s);
  }

  .field-wrapper .field-label.none {
    display: none;
  }

  .field-wrapper .required-indicator {
    position: absolute;
    inset-inline-start: calc(100% + var(--atp-space-xxxs));
    inset-block-start: 0;
    color: var(--atp-red-600);
    font-family: var(--atpco-font-family);
    font-size: var(--atp-font-size-body-s);
    font-weight: var(--atp-font-weight-regular);
    line-height: var(--atp-line-height-body-s);
  }

  .field-wrapper .input-wrapper {
    position: relative;
    padding: var(--atp-space-xs);
    display: flex;
    gap: var(--atp-space-xs);
    align-items: center;
    border-radius: var(--atp-border-radius-s);
    border: 1px solid var(--atp-element-border-primary-strong-enabled);
    background: var(--atp-element-fill-inverse-weak-enabled);
  }

  .field-wrapper.disabled .input-wrapper {
    background: var(--atp-background-primary-medium);
  }

  .field-wrapper.textarea .input-wrapper {
    padding: 0;
  }

  .field-wrapper:not(.select) .input-wrapper:focus-within {
    outline: var(--atp-focus-width) solid var(--atp-focus-color);
    outline-offset: var(--atp-focus-outline-offset);
  }

  .field-wrapper.select:not(.disabled) .input-wrapper {
    cursor: pointer;
  }

  /* if an element inside the input has focus, don't draw a focus indicator on the input itself */
  .field-wrapper .input-wrapper:has(*:focus-visible, *:focus):focus-within {
    outline: 0;
  }

  .field-wrapper.error:not(.disabled) .input-wrapper,
  .field-wrapper.error:not(.disabled) .input-wrapper:focus-within {
    border: 1px solid var(--atp-red-600);
    outline: 1px solid var(--atp-red-600);
  }

  .field-wrapper .input-wrapper .inner-input {
    flex-grow: 1;
    display: flex;
    flex-direction: column;
    justify-content: center;
    gap: var(--atp-space-xs);
  }

  .field-wrapper .input-wrapper .inner-input .tag-list {
    display: flex;
    gap: var(--atp-space-xxs);
    flex-wrap: wrap;
  }

  .field-wrapper .input-wrapper .dropdown {
    position: absolute;
    inset-block-start: calc(100% + var(--atp-space-xxxs));
    inset-inline: calc(-1 * var(--atp-space-xxxs)) 0;
    inline-size: calc(100% + var(--atp-space-xxs));
    z-index: var(--atp-z-index-menu);
  }

  .field-wrapper .input-wrapper .dropdown.right {
    inset-inline-start: unset;
    inline-size: unset;
  }

  .field-wrapper .input-wrapper .dropdown.left {
    inset-inline-end: unset;
    inline-size: unset;
  }

  .field-wrapper .help-text {
    margin: 0;
    color: var(--atp-content-primary-medium-enabled);
    font-family: var(--atpco-font-family);
    font-size: var(--atp-font-size-body-xs);
    font-weight: var(--atp-font-weight-regular);
    line-height: var(--atp-line-height-body-xs);
  }

  .field-wrapper.error:not(.disabled) .help-text {
    color: var(--atp-red-600);
  }

  /* target only default slot */

  ::slotted(:not([slot])) {
    all: unset;
    block-size: var(--atp-space-m);
    inline-size: 100%;
    font: inherit;
    color: inherit;
    background: transparent;
  }
`, ot = g`
  .tag {
    --atp-tag-background-color: var(--atp-element-fill-blue-medium-enabled);
    --atp-icon-fill: currentColor;
    --atp-icon-padding-block: var(--atp-space-xxxs);

    inline-size: fit-content;
    outline: none;
    margin: 0;
    padding: var(--atp-icon-padding-block) var(--atp-space-xs);
    display: flex;
    align-items: center;
    gap: var(--atp-space-xxs);
    background: var(--atp-tag-background-color);
    border: 1px solid var(--atp-tag-background-color);
    border-radius: var(--atp-border-radius-s);
    font-family: var(--atpco-font-family);
    font-size: var(--atp-font-size-body-xs);
    font-weight: var(--atp-font-weight-medium);
    line-height: var(--atp-line-height-body-xs);
    white-space: nowrap;
    color: var(--atp-content-primary-medium-enabled);
  }

  .tag:has(atp-icon) {
    padding: var(--atp-icon-padding-block) calc(var(--atp-space-xxs) + var(--atp-space-xxxs))
      var(--atp-icon-padding-block) var(--atp-space-xs);
  }

  .tag:focus-visible {
    outline: var(--atp-focus-width) solid var(--atp-focus-color);
    outline-offset: var(--atp-focus-outline-offset);
  }

  .tag.tag-action {
    cursor: pointer;
  }

  /* icon */
  .icon {
    border-radius: var(--atp-border-radius-s);
  }

  .tag-action:not(.disabled):hover .icon,
  .tag-action:not(.disabled):focus-visible .icon {
    background: hsl(0 0% 0% / 0.24);
  }

  .tag-action:not(.disabled):active .icon {
    background: hsl(0 0% 0% / 0.38);
  }

  .darkslate.tag-action:not(.disabled):hover .icon,
  .darkslate.tag-action:not(.disabled):focus-visible .icon {
    background: hsl(0 100% 100% / 0.66);
  }

  .darkslate.tag-action:not(.disabled):active .icon {
    background: hsl(0 100% 100% / 0.59);
  }

  /** fill */
  .tag.blue.fill {
    --atp-tag-background-color: var(--atp-element-fill-blue-medium-enabled);
  }

  .tag.purple.fill {
    --atp-tag-background-color: var(--atp-element-fill-purple-medium-enabled);
  }

  .tag.green.fill {
    --atp-tag-background-color: var(--atp-element-fill-green-medium-enabled);
  }

  .tag.pink.fill {
    --atp-tag-background-color: var(--atp-element-fill-red-medium-enabled);
  }

  .tag.orange.fill {
    --atp-tag-background-color: var(--atp-element-fill-orange-medium-enabled);
  }

  .tag.utility-blue.fill {
    --atp-tag-background-color: var(--atp-utility-primary-medium-enabled);

    color: var(--atp-content-inverse-medium-enabled);
  }

  .tag.dark-slate.fill {
    --atp-tag-background-color: var(--atp-element-fill-primary-strong-enabled);

    color: var(--atp-content-inverse-medium-enabled);
  }

  .tag.light-slate.fill {
    --atp-tag-background-color: var(--atp-element-fill-primary-weak-enabled);
  }

  /** fill-dark */
  .tag.blue.fill-dark {
    --atp-tag-background-color: var(--atp-element-fill-blue-medium-pressed);
  }

  .tag.purple.fill-dark {
    --atp-tag-background-color: var(--atp-element-fill-purple-medium-pressed);

    color: var(--atp-content-inverse-medium-enabled);
  }

  .tag.green.fill-dark {
    --atp-tag-background-color: var(--atp-element-fill-green-medium-pressed);

    color: var(--atp-content-inverse-medium-enabled);
  }

  .tag.pink.fill-dark {
    --atp-tag-background-color: var(--atp-element-fill-red-medium-pressed);
  }

  .tag.orange.fill-dark {
    --atp-tag-background-color: var(--atp-element-fill-orange-medium-pressed);
  }

  .tag.utility-blue.fill-dark {
    --atp-tag-background-color: var(--atp-utility-primary-medium-pressed);

    color: var(--atp-content-inverse-medium-enabled);
  }

  .tag.dark-slate.fill-dark {
    --atp-tag-background-color: var(--atp-element-fill-primary-strong-pressed);

    color: var(--atp-content-inverse-medium-enabled);
  }

  .tag.light-slate.fill-dark {
    --atp-tag-background-color: var(--atp-element-fill-primary-medium-pressed);

    color: var(--atp-content-inverse-medium-enabled);
  }

  /** outline */
  .tag.blue.outline {
    --atp-tag-background-color: var(--atp-element-fill-blue-weak-enabled);

    border-color: var(--atp-element-fill-blue-medium-enabled);
  }

  .tag.purple.outline {
    --atp-tag-background-color: var(--atp-element-fill-purple-weak-enabled);

    border-color: var(--atp-element-fill-purple-medium-enabled);
  }

  .tag.green.outline {
    --atp-tag-background-color: var(--atp-element-fill-green-weak-enabled);

    border-color: var(--atp-element-fill-green-medium-enabled);
  }

  .tag.pink.outline {
    --atp-tag-background-color: var(--atp-element-fill-red-weak-enabled);

    border-color: var(--atp-element-fill-red-medium-enabled);
  }

  .tag.orange.outline {
    --atp-tag-background-color: var(--atp-element-fill-orange-weak-enabled);

    border-color: var(--atp-element-fill-orange-medium-enabled);
  }

  .tag.utility-blue.outline {
    --atp-tag-background-color: transparent;

    color: var(--atp-utility-primary-medium-enabled);
    border-color: var(--atp-utility-primary-medium-enabled);
  }

  .tag.dark-slate.outline {
    --atp-tag-background-color: transparent;

    color: var(--atp-utility-primary-strong-enabled);
    border-color: var(--atp-element-fill-primary-strong-enabled);
  }

  .tag.light-slate.outline {
    --atp-tag-background-color: transparent;

    color: var(--atp-utility-primary-strong-enabled);
    border-color: var(--atp-slate-200);
  }

  /* disabled */
  .tag.tag.disabled {
    color: var(--atp-content-primary-strong-disabled);
    background: var(--atp-element-fill-primary-strong-disabled);
    border-color: var(--atp-element-fill-primary-strong-disabled);
    cursor: default;
  }
`;
var st = Object.defineProperty, lt = Object.getOwnPropertyDescriptor, c1 = (e, t, i, r) => {
  for (var a = r > 1 ? void 0 : r ? lt(t, i) : t, o = e.length - 1, s; o >= 0; o--)
    (s = e[o]) && (a = (r ? s(t, i, a) : s(a)) || a);
  return r && a && st(t, i, a), a;
}, nt = /* @__PURE__ */ ((e) => (e.FILL = "fill", e.FILL_DARK = "fill-dark", e.OUTLINE = "outline", e))(nt || {}), dt = /* @__PURE__ */ ((e) => (e.BLUE = "blue", e.PURPLE = "purple", e.GREEN = "green", e.PINK = "pink", e.ORANGE = "orange", e.UTILITY_BLUE = "utility-blue", e.DARK_SLATE = "dark-slate", e.LIGHT_SLATE = "light-slate", e))(dt || {});
let j = class extends b {
  constructor() {
    super(...arguments), this.label = "", this.isAction = !1, this.disabled = !1, this.color = "blue", this.appearance = "fill";
  }
  render() {
    return n`${this.isAction ? n`<button
          @click=${this._handleClick}
          ?disabled="${this.disabled}"
          class="${this._getClasses()}"
        >
          ${this.label}
          ${this.icon ? n`<atp-icon
                class="icon"
                .icon="${this.icon.icon}"
                .height="${this.icon.height}"
              ></atp-icon>` : ""}
        </button>` : n`<div class="${this._getClasses()}">
          ${this.label}
          ${this.icon ? n`<atp-icon
                class="icon"
                .icon="${this.icon.icon}"
                .height="${this.icon.height}"
              ></atp-icon>` : ""}
        </div>`}`;
  }
  _getClasses() {
    return v({
      tag: !0,
      "tag-action": this.isAction,
      [this.color]: !0,
      [this.appearance]: !0,
      disabled: this.disabled
    });
  }
  _handleClick() {
    this.isAction && !this.disabled && this.dispatchEvent(new CustomEvent("clickEventOutput", { bubbles: !0, composed: !0 }));
  }
};
j.styles = [m, ot];
c1([
  l()
], j.prototype, "label", 2);
c1([
  l({ type: Object })
], j.prototype, "icon", 2);
c1([
  l({ type: Boolean })
], j.prototype, "isAction", 2);
c1([
  l({ type: Boolean })
], j.prototype, "disabled", 2);
c1([
  l()
], j.prototype, "color", 2);
c1([
  l()
], j.prototype, "appearance", 2);
j = c1([
  u("atp-tag")
], j);
const ct = /* @__PURE__ */ Symbol.for(""), pt = (e) => {
  if (e?.r === ct) return e?._$litStatic$;
}, Ve = /* @__PURE__ */ new Map(), ht = (e) => (t, ...i) => {
  const r = i.length;
  let a, o;
  const s = [], p = [];
  let d, h = 0, f = !1;
  for (; h < r; ) {
    for (d = t[h]; h < r && (o = i[h], (a = pt(o)) !== void 0); ) d += a + t[++h], f = !0;
    h !== r && p.push(o), s.push(d), h++;
  }
  if (h === r && s.push(t[r]), f) {
    const C = s.join("$$lit$$");
    (t = Ve.get(C)) === void 0 && (s.raw = s, Ve.set(C, t = s)), i = p;
  }
  return e(t, ...i);
}, t1 = ht(n);
var bt = Object.defineProperty, ut = Object.getOwnPropertyDescriptor, E = (e, t, i, r) => {
  for (var a = r > 1 ? void 0 : r ? ut(t, i) : t, o = e.length - 1, s; o >= 0; o--)
    (s = e[o]) && (a = (r ? s(t, i, a) : s(a)) || a);
  return r && a && bt(t, i, a), a;
}, Ct = /* @__PURE__ */ ((e) => (e.LEFT = "left", e.RIGHT = "right", e))(Ct || {});
let k = class extends b {
  constructor() {
    super(...arguments), this.required = !1, this.isError = !1, this.disabled = !1, this.textarea = !1, this._dropdownVisible = !1, this._isSelect = !1, this._isMultiSelect = !1, this._clickOutsideHandler = (e) => {
      Be(e, this) && this._isSelect && this.dispatchEvent(new CustomEvent("dropdownClosedOutput", { bubbles: !0, composed: !0 }));
    }, this._handleClick = (e) => {
      !this._isSelect && e.target.classList.contains("input-wrapper") && e.target.tagName !== "ATP-BUTTON" && e.target.tagName !== "INPUT" && (e.preventDefault(), this.inputElementRef?.focus()), this._isSelect && e.target.tagName !== "ATP-TAG" && e.target.tagName !== "ATP-DROPDOWN" && e.target.tagName !== "ATP-BUTTON" && (e.preventDefault(), this._toggleDropdown(!this._dropdownVisible));
    }, this._singleItemSelect = () => {
      this._toggleDropdown(!1);
    }, this._onInputKeydown = (e) => {
      e.code === "Space" && this._toggleDropdown(!this._dropdownVisible);
    };
  }
  render() {
    return t1`
      <div class="${this._getClasses()}">
        <div class="field-label ${this._slottedLabelElements.length === 0 ? "none" : ""}">
          <slot name="label"></slot>
          ${this.required ? t1`<span class="required-indicator">*</span>` : ""}
        </div>
        <div @mousedown="${(e) => this._handleClick(e)}" class="input-wrapper">
          ${this.iconLeft ? t1`<atp-icon
                .icon=${this.iconLeft.icon}
                .height=${this.iconLeft.height}
                .color=${"black"}
              ></atp-icon>` : ""}
          <div class="inner-input">
            <slot></slot>
            <div class="dropdown ${this.dropdownPosition}">
              <slot name="dropdown"></slot>
            </div>
            ${this.tags?.length > 0 ? t1`<div class="tag-list">
                  ${this.tags.map(
      (e) => t1`<atp-tag
                      .label="${e.label}"
                      .icon="${e.icon}"
                      .isAction="${e.isAction}"
                      .disabled="${this.disabled || e.disabled}"
                      @clickEventOutput=${() => this._tagRemoveHandler(e.label)}
                    ></atp-tag>`
    )}
                </div>` : ""}
          </div>
          ${this.iconRight ? this.iconRightClickable ? t1`<atp-button
                  id="icon-clickable"
                  .iconConfig=${this.iconRight}
                  .appearance=${he.TEXT}
                  @clickEventOutput=${this._iconClicked}
                ></atp-button>` : t1`<atp-icon
                  .icon=${this.iconRight.icon}
                  .height=${this.iconRight.height}
                  .color=${"black"}
                ></atp-icon>` : c}
        </div>
        <slot class="help-text" name="help-text"></slot>
      </div>
    `;
  }
  async firstUpdated() {
    await this.updateComplete;
    const e = this._slottedInputElements[0], t = this._slottedDropdownElements[0];
    this._isSelect = !!this._slottedDropdownElements[0], this._isMultiSelect = !this._slottedDropdownElements[0]?.closeOnClickOutside, this._slottedLabelElements.length > 0 && (this._isSelect && this._slottedLabelElements[0]?.addEventListener("click", () => {
      setTimeout(() => {
        this._toggleDropdown(!0);
      }, 0);
    }), this.requestUpdate()), e && (this.inputElementRef = e, this._isSelect && (this.iconRightClickable = !0, this.iconRight = { icon: "chevron-down", height: 16, label: "Toggle dropdown menu" }, this.inputElementRef.readOnly = !0, this.inputElementRef.tabIndex = -1), this.disabled && (this.inputElementRef.disabled = !0)), t && (this.dropdownElementRef = t, this.addEventListener("dropdownClosedOutput", () => {
      this._toggleDropdown(!1);
    }), this._isMultiSelect || this.addEventListener("itemSelectedOutput", this._singleItemSelect));
  }
  connectedCallback() {
    super.connectedCallback(), window.addEventListener("click", this._clickOutsideHandler);
  }
  disconnectedCallback() {
    this.removeEventListener("dropdownClosedOutput", () => this._toggleDropdown(!1)), this.removeEventListener("itemSelectedOutput", this._singleItemSelect), window.removeEventListener("click", this._clickOutsideHandler), this._slottedLabelElements[0]?.removeEventListener("click", () => {
      setTimeout(() => {
        this._toggleDropdown(!0);
      }, 0);
    }), super.disconnectedCallback();
  }
  update(e) {
    e.has("disabled") && this.inputElementRef && (this.inputElementRef.disabled = this.disabled), super.update(e);
  }
  _iconClicked() {
    this.dispatchEvent(new CustomEvent("iconClickedOutput", { bubbles: !0, composed: !0 })), this._isSelect && this._toggleDropdown(!this._dropdownVisible);
  }
  _tagRemoveHandler(e) {
    this.dispatchEvent(
      new CustomEvent("tagRemoveOutput", {
        detail: e,
        bubbles: !0,
        composed: !0
      })
    );
  }
  _toggleDropdown(e) {
    this._dropdownVisible = e, this.dropdownElementRef && (e ? this.dropdownElementRef.startKeyScrolling() : this.dropdownElementRef.disableKeyScrolling());
  }
  _getClasses() {
    return v({
      "field-wrapper": !0,
      error: this.isError,
      disabled: this.disabled,
      select: this._isSelect,
      textarea: this.textarea
    });
  }
};
k.styles = [m, rt];
E([
  l({ type: Boolean })
], k.prototype, "required", 2);
E([
  l({ type: Object })
], k.prototype, "iconLeft", 2);
E([
  l({ type: Object })
], k.prototype, "iconRight", 2);
E([
  l({ type: Boolean })
], k.prototype, "iconRightClickable", 2);
E([
  l({ type: Boolean })
], k.prototype, "isError", 2);
E([
  l()
], k.prototype, "dropdownPosition", 2);
E([
  l({ type: Array })
], k.prototype, "tags", 2);
E([
  l({ type: Boolean })
], k.prototype, "disabled", 2);
E([
  l({ type: Boolean })
], k.prototype, "textarea", 2);
E([
  z1()
], k.prototype, "_slottedInputElements", 2);
E([
  z1({ slot: "label" })
], k.prototype, "_slottedLabelElements", 2);
E([
  z1({ slot: "dropdown" })
], k.prototype, "_slottedDropdownElements", 2);
k = E([
  u("atp-input")
], k);
const Te = g`
  :host {
    display: block;
  }

  .atp-list-bounded {
    margin: 0;
    padding: 0;
    border: 1px solid var(--atp-element-border-primary-medium-enabled);
    border-block-end-width: 0;
  }

  .atp-list-bounded-item {
    list-style-type: none;
    border-block-end: 1px solid var(--atp-element-border-primary-medium-enabled);
    margin: 0;
    padding: var(--atp-space-xs) var(--atp-space-s);
  }
`;
var vt = Object.defineProperty, gt = Object.getOwnPropertyDescriptor, ue = (e, t, i, r) => {
  for (var a = r > 1 ? void 0 : r ? gt(t, i) : t, o = e.length - 1, s; o >= 0; o--)
    (s = e[o]) && (a = (r ? s(t, i, a) : s(a)) || a);
  return r && a && vt(t, i, a), a;
};
let R1 = class extends b {
  constructor() {
    super(...arguments), this.ordered = !1;
  }
  render() {
    return n` ${this.ordered ? n`<ol class="atp-list-bounded">
          <slot></slot>
        </ol>` : n`<ul class="atp-list-bounded">
          <slot></slot>
        </ul>`}`;
  }
};
R1.styles = [m, Te];
ue([
  l({ type: Boolean })
], R1.prototype, "ordered", 2);
R1 = ue([
  u("atp-list-bounded")
], R1);
let ie = class extends b {
  render() {
    return n`
      <li class="atp-list-bounded-item">
        <slot></slot>
      </li>
    `;
  }
};
ie.styles = [Te, m];
ie = ue([
  u("atp-list-bounded-item")
], ie);
const mt = g`
  .media-object {
    display: flex;
    align-items: center;
    gap: var(--atp-space-xs);
  }

  .icon-wrapper {
    block-size: var(--atp-space-l);
    inline-size: var(--atp-space-l);
    aspect-ratio: 1/1;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 50%;
  }

  .icon-wrapper.blue {
    background: var(--atp-element-fill-blue-strong-enabled);
  }

  .icon-wrapper.green {
    background: var(--atp-element-fill-green-strong-enabled);
  }

  .icon-wrapper.purple {
    background: var(--atp-element-fill-purple-strong-enabled);
  }

  .icon-wrapper.red {
    background: var(--atp-danger-primary-strong-enabled);
  }

  .icon-wrapper.slate {
    background: var(--atp-element-fill-primary-strong-enabled);
  }

  .label-text {
    margin: 0;
    color: var(--atp-content-inverse-medium-enabled);
    font-family: var(--atpco-font-family);
    font-size: var(--atp-font-size-body-s);
    font-weight: var(--atp-font-weight-semibold);
    line-height: var(--atp-line-height-body-s);
  }

  .text-container {
    display: flex;
    flex-direction: column;
    gap: var(--atp-space-xxxs);
  }

  .text-container .label {
    margin: 0;
    color: var(--atp-content-primary-medium-enabled);
    font-family: var(--atpco-font-family);
    font-size: var(--atp-font-size-body-s);
    font-weight: var(--atp-font-weight-semibold);
    line-height: var(--atp-line-height-body-s);
  }

  .text-container .sub-title {
    margin: 0;
    overflow: hidden;
    color: var(--atp-content-primary-weak-enabled);
    text-overflow: ellipsis;
    font-family: var(--atpco-font-family);
    font-size: var(--atp-font-size-body-xs);
    font-weight: var(--atp-font-weight-regular);
    line-height: var(--atp-line-height-body-xs);
  }
`;
var ft = Object.defineProperty, yt = Object.getOwnPropertyDescriptor, y1 = (e, t, i, r) => {
  for (var a = r > 1 ? void 0 : r ? yt(t, i) : t, o = e.length - 1, s; o >= 0; o--)
    (s = e[o]) && (a = (r ? s(t, i, a) : s(a)) || a);
  return r && a && ft(t, i, a), a;
}, wt = /* @__PURE__ */ ((e) => (e.BLUE = "blue", e.GREEN = "green", e.PURPLE = "purple", e.RED = "red", e.SLATE = "slate", e))(wt || {});
let Y = class extends b {
  constructor() {
    super(...arguments), this.iconText = "", this.label = "", this.subtitle = "", this.color = "slate";
  }
  render() {
    return n`
      <div class="media-object">
        <div class="${this._getIconClasses()}">
          ${this.iconText ? n`<p class="label-text">${this.iconText}</p>` : n`<atp-icon
                .icon="${this.icon?.icon}"
                .color="${this.icon?.color}"
                .height="${this.icon?.height}"
              ></atp-icon>`}
        </div>
        <div class="text-container">
          <p class="label">${this.label}</p>
          <p class="sub-title">${this.subtitle}</p>
        </div>
      </div>
    `;
  }
  _getIconClasses() {
    return v({ "icon-wrapper": !0, [this.color]: !0 });
  }
};
Y.styles = [m, mt];
y1([
  l()
], Y.prototype, "iconText", 2);
y1([
  l({ type: Object })
], Y.prototype, "icon", 2);
y1([
  l()
], Y.prototype, "label", 2);
y1([
  l()
], Y.prototype, "subtitle", 2);
y1([
  l()
], Y.prototype, "color", 2);
Y = y1([
  u("atp-media-object")
], Y);
const xt = g`
  .meter {
    appearance: none;
    inline-size: var(--atp-meter-width);
  }

  .meter::-webkit-meter-bar {
    background: var(--atp-meter-track-color);
    block-size: var(--atp-meter-height);
    border-radius: var(--atp-meter-border-radius);
  }

  .meter::-webkit-meter-optimum-value {
    background: var(--atp-meter-fill-color);
    border-radius: var(--atp-meter-border-radius);
  }

  .meter::-moz-meter-bar {
    background: var(--atp-meter-fill-color);
    border-radius: var(--atp-meter-border-radius);
  }

  .meter:-moz-meter-optimum {
    background: var(--atp-meter-track-color);
    block-size: var(--atp-meter-height);
    border-radius: var(--atp-border-radius-s);
  }

  /* circular meters */
  .circle {
    block-size: var(--atp-meter-circle-size);
    inline-size: var(--atp-meter-circle-size);
    border-radius: 50%;
    appearance: none;
    border: none;
    background: transparent;

    /* 
      Transition the gradient by a few percentage points to smooth the rendering of the subpixel rounding.
      Without this, the inside of the circle can look a little chunky.
    */

    /* stylelint-disable -- mask-image doesn't have baseline support yet, but the vendor prefix covers us */
    -webkit-mask-image: radial-gradient(
      transparent var(--atp-meter-circle-mask-size),
      black calc(var(--atp-meter-circle-mask-size) + 2%)
    );

    mask-image: radial-gradient(
      transparent var(--atp-meter-circle-mask-size),
      black calc(var(--atp-meter-circle-mask-size) + 2%)
    );
    /* stylelint-enable  */
  }

  .circle::-webkit-meter-bar {
    block-size: var(--atp-meter-circle-size);
    border-radius: 50%;

    /* 
      Transition the gradient by 1 degree to smooth the rendering of the subpixel rounding.
      Without this, the edge of the filled section can look a little chunky.
    */
    background: conic-gradient(
      var(--atp-meter-fill-color) calc(360deg / var(--atp-meter-max) * var(--atp-meter-value)),
      var(--atp-meter-track-color)
        calc(360deg / var(--atp-meter-max) * var(--atp-meter-value) + 1deg),
      var(--atp-meter-track-color) 360deg
    );
  }

  .circle::-webkit-meter-optimum-value {
    background: none;
  }

  .circle::-moz-meter-bar {
    block-size: var(--atp-meter-circle-size);
    inline-size: var(--atp-meter-circle-size);
    border-radius: 50%;
  }

  .circle:-moz-meter-optimum {
    block-size: var(--atp-meter-circle-size);
    inline-size: var(--atp-meter-circle-size);
    border-radius: 50%;
    background: conic-gradient(
      var(--atp-meter-fill-color) calc(360deg / var(--atp-meter-max) * var(--atp-meter-value)),
      var(--atp-meter-track-color)
        calc(360deg / var(--atp-meter-max) * var(--atp-meter-value) + 1deg),
      var(--atp-meter-track-color) 360deg
    );
  }

  .circle:-moz-meter-optimum::-moz-meter-bar {
    background: none;
  }
`;
var _t = Object.defineProperty, kt = Object.getOwnPropertyDescriptor, Z1 = (e, t, i, r) => {
  for (var a = r > 1 ? void 0 : r ? kt(t, i) : t, o = e.length - 1, s; o >= 0; o--)
    (s = e[o]) && (a = (r ? s(t, i, a) : s(a)) || a);
  return r && a && _t(t, i, a), a;
}, $t = /* @__PURE__ */ ((e) => (e.DEFAULT = "default", e.CIRCLE = "circle", e))($t || {});
let l1 = class extends b {
  constructor() {
    super(...arguments), this.appearance = "default";
  }
  render() {
    return n`<meter
      class=${this._getClasses()}
      value=${this.value}
      max=${this.max}
      min=${V(this.min)}
      style="--atp-meter-value: ${this.value}; --atp-meter-max: ${this.max};"
    >
      at ${this.value} of ${this.max}
    </meter>`;
  }
  _getClasses() {
    return v({
      meter: !0,
      circle: this.appearance === "circle"
      /* CIRCLE */
    });
  }
};
l1.styles = [m, xt];
Z1([
  l()
], l1.prototype, "appearance", 2);
Z1([
  l({ type: Number })
], l1.prototype, "min", 2);
Z1([
  l({ type: Number })
], l1.prototype, "max", 2);
Z1([
  l({ type: Number })
], l1.prototype, "value", 2);
l1 = Z1([
  u("atp-meter")
], l1);
const Lt = g`
  .pill {
    display: flex;
    padding: var(--atp-space-xxxs) var(--atp-space-xs);
    align-items: center;
    gap: var(--atp-space-xxs);
    color: var(--atp-content-primary-medium-enabled);
    font-family: var(--atpco-font-family);
    font-size: var(--atp-font-size-body-s);
    font-weight: var(--atp-font-weight-regular);
    line-height: var(--atp-line-height-body-s);
    border-radius: var(--atp-border-radius-xl);
    inline-size: fit-content;
    outline: none;
    border: 1px solid transparent;
  }

  .pill.active:not(.disabled) {
    cursor: pointer;
  }

  .pill.disabled:is(.fill, .outline):is(.green, .blue, .pink, .purple, .orange) {
    --atp-icon-fill: var(--atp-button-primary-medium-disabled);

    color: var(--atp-button-primary-medium-disabled);
  }

  .pill:not(.disabled):is(.fill, .outline):is(.green, .blue, .pink, .purple, .orange) {
    --atp-icon-fill: var(--atp-content-primary-medium-enabled);

    color: var(--atp-content-primary-medium-enabled);
  }

  /** blue */
  .pill.blue.fill {
    background: var(--atp-element-fill-blue-medium-enabled);
  }

  .pill.blue.fill.active:not(.disabled):hover,
  .pill.blue.fill.active:not(.disabled):focus-visible {
    background: var(--atp-element-fill-blue-medium-hover);
  }

  .pill.blue.fill.active:not(.disabled):active {
    background: var(--atp-element-fill-blue-medium-pressed);
  }

  .pill.blue.fill.disabled {
    background: var(--atp-element-fill-blue-medium-disabled);
  }

  .pill.blue.outline {
    border: 1px solid var(--atp-element-fill-blue-medium-enabled);
    background: var(--atp-element-fill-blue-weak-enabled);
  }

  .pill.blue.outline.active:not(.disabled):hover,
  .pill.blue.outline.active:not(.disabled):focus-visible {
    border: 1px solid var(--atp-element-fill-blue-medium-hover);
    background: var(--atp-element-fill-blue-weak-hover);
  }

  .pill.blue.outline.active:not(.disabled):active {
    border: 1px solid var(--atp-element-fill-blue-medium-pressed);
    background: var(--atp-element-fill-blue-weak-pressed);
  }

  .pill.blue.outline.disabled {
    border: 1px solid var(--atp-element-fill-blue-medium-enabled);
    background: var(--atp-element-fill-blue-weak-disabled);
  }

  /** green */
  .pill.green.fill {
    background: var(--atp-element-fill-green-medium-enabled);
  }

  .pill.green.fill.active:not(.disabled):hover,
  .pill.green.fill.active:not(.disabled):focus-visible {
    background: var(--atp-element-fill-green-medium-hover);
  }

  .pill.green.fill.active:not(.disabled):active {
    background: var(--atp-element-fill-green-medium-pressed);
  }

  .pill.green.fill.disabled {
    background: var(--atp-element-fill-green-medium-disabled);
  }

  .pill.green.outline {
    border: 1px solid var(--atp-element-fill-green-medium-enabled);
    background: var(--atp-element-fill-green-weak-enabled);
  }

  .pill.green.outline.active:not(.disabled):hover,
  .pill.green.outline.active:not(.disabled):focus-visible {
    border: 1px solid var(--atp-element-fill-green-medium-hover);
    background: var(--atp-element-fill-green-weak-hover);
  }

  .pill.green.outline.active:not(.disabled):active {
    border: 1px solid var(--atp-element-fill-green-medium-pressed);
    background: var(--atp-element-fill-green-weak-pressed);
  }

  .pill.green.outline.disabled {
    border: 1px solid var(--atp-element-fill-green-medium-disabled);
    background: var(--atp-element-fill-green-weak-disabled);
  }

  .pill.pink.fill {
    background: var(--atp-element-fill-red-medium-enabled);
  }

  .pill.pink.fill.active:not(.disabled):hover,
  .pill.pink.fill.active:not(.disabled):focus-visible {
    background: var(--atp-element-fill-red-medium-hover);
  }

  .pill.pink.fill.active:not(.disabled):active {
    background: var(--atp-element-fill-red-medium-pressed);
  }

  .pill.pink.fill.disabled {
    background: var(--atp-element-fill-red-medium-disabled);
  }

  .pill.pink.outline {
    border: 1px solid var(--atp-element-fill-red-medium-enabled);
    background: var(--atp-element-fill-red-weak-enabled);
  }

  .pill.pink.outline.active:not(.disabled):hover,
  .pill.pink.outline.active:not(.disabled):focus-visible {
    border: 1px solid var(--atp-element-fill-red-medium-hover);
    background: var(--atp-element-fill-red-weak-hover);
  }

  .pill.pink.outline.active:not(.disabled):active {
    border: 1px solid var(--atp-element-fill-red-medium-pressed);
    background: var(--atp-element-fill-red-medium-enabled);
  }

  .pill.pink.outline.disabled {
    border: 1px solid var(--atp-element-fill-red-medium-enabled);
    background: var(--atp-element-fill-red-weak-disabled);
  }

  /** purple */
  .pill.purple.fill {
    background: var(--atp-element-fill-purple-medium-enabled);
  }

  .pill.purple.fill.active:not(.disabled):hover,
  .pill.purple.fill.active:not(.disabled):focus-visible {
    background: var(--atp-element-fill-purple-medium-hover);
  }

  .pill.purple.fill.active:not(.disabled):active {
    background: var(--atp-element-fill-purple-medium-pressed);
  }

  .pill.purple.fill.disabled {
    background: var(--atp-element-fill-purple-medium-disabled);
  }

  .pill.purple.outline {
    border: 1px solid var(--atp-element-fill-purple-medium-enabled);
    background: var(--atp-element-fill-purple-weak-enabled);
  }

  .pill.purple.outline.active:not(.disabled):hover,
  .pill.purple.outline.active:not(.disabled):focus-visible {
    border: 1px solid var(--atp-element-fill-purple-medium-hover);
    background: var(--atp-element-fill-purple-weak-hover);
  }

  .pill.purple.outline.active:not(.disabled):active {
    border: 1px solid var(--atp-element-fill-purple-medium-pressed);
    background: var(--atp-element-fill-purple-weak-pressed);
  }

  .pill.purple.outline.disabled {
    border: 1px solid var(--atp-element-fill-purple-medium-disabled);
    background: var(--atp-element-fill-purple-weak-disabled);
  }

  /** orange */
  .pill.orange.fill {
    background: var(--atp-element-fill-orange-medium-enabled);
  }

  .pill.orange.fill.active:not(.disabled):hover,
  .pill.orange.fill.active:not(.disabled):focus-visible {
    background: var(--atp-element-fill-orange-medium-hover);
  }

  .pill.orange.fill.active:not(.disabled):active {
    background: var(--atp-element-fill-orange-medium-pressed);
  }

  .pill.orange.fill.disabled {
    background: var(--atp-element-fill-orange-medium-disabled);
  }

  .pill.orange.outline {
    border: 1px solid var(--atp-element-fill-orange-medium-enabled);
    background: var(--atp-element-fill-orange-weak-enabled);
  }

  .pill.orange.outline.active:not(.disabled):hover,
  .pill.orange.outline.active:not(.disabled):focus-visible {
    border: 1px solid var(--atp-element-fill-orange-medium-hover);
    background: var(--atp-element-fill-orange-weak-hover);
  }

  .pill.orange.outline.active:not(.disabled):active {
    border: 1px solid var(--atp-element-fill-orange-medium-pressed);
    background: var(--atp-element-fill-orange-weak-pressed);
  }

  .pill.orange.outline.disabled {
    border: 1px solid var(--atp-element-fill-orange-strong-disabled);
    background: var(--atp-element-fill-orange-weak-disabled);
  }

  /* dark-blue */
  .pill.dark-blue.fill {
    --atp-icon-fill: var(--atp-button-inverse-medium-enabled);

    background: var(--atp-element-fill-blue-strong-enabled);
    color: var(--atp-button-inverse-medium-enabled);
  }

  .pill.dark-blue.fill.active:not(.disabled):hover,
  .pill.dark-blue.fill.active:not(.disabled):focus-visible {
    background: var(--atp-element-fill-blue-strong-hover);
  }

  .pill.dark-blue.fill.active:not(.disabled):active {
    background: var(--atp-element-fill-blue-strong-pressed);
  }

  .pill.dark-blue.fill.disabled {
    background: var(--atp-element-fill-blue-strong-disabled);
  }

  .pill.dark-blue.outline {
    --atp-icon-fill: var(--atp-utility-primary-medium-enabled);

    color: var(--atp-utility-primary-medium-enabled);
    border: 1px solid var(--atp-utility-primary-medium-enabled);
    background: var(--atp-element-fill-inverse-weak-enabled);
  }

  .pill.dark-blue.outline.active:not(.disabled):hover,
  .pill.dark-blue.outline.active:not(.disabled):focus-visible {
    --atp-icon-fill: var(--atp-utility-primary-medium-hover);

    border: 1px solid var(--atp-utility-primary-medium-hover);
    color: var(--atp-utility-primary-medium-hover);
  }

  .pill.dark-blue.outline.active:not(.disabled):active {
    --atp-icon-fill: var(--atp-utility-primary-medium-pressed);

    border: 1px solid var(--atp-utility-primary-medium-pressed);
    color: var(--atp-utility-primary-medium-pressed);
  }

  .pill.dark-blue.outline.disabled {
    --atp-icon-fill: var(--atp-utility-primary-medium-disabled);

    border: 1px solid var(--atp-utility-primary-medium-disabled);
    color: var(--atp-utility-primary-medium-disabled);
  }

  /** red */
  .pill.red.fill {
    --atp-icon-fill: var(--atp-button-inverse-medium-enabled);

    background: var(--atp-danger-primary-strong-enabled);
    color: var(--atp-button-inverse-medium-enabled);
  }

  .pill.red.fill.active:not(.disabled):hover,
  .pill.red.fill.active:not(.disabled):focus-visible {
    background: var(--atp-danger-primary-strong-hover);
  }

  .pill.red.fill.active:not(.disabled):active {
    background: var(--atp-danger-primary-strong-pressed);
  }

  .pill.red.fill.disabled {
    background: var(--atp-danger-primary-strong-disabled);
  }

  .pill.red.outline {
    --atp-icon-fill: var(--atp-danger-primary-strong-enabled);

    border: 1px solid var(--atp-danger-primary-strong-enabled);
    background: var(--atp-element-fill-inverse-weak-enabled);
    color: var(--atp-danger-primary-strong-enabled);
  }

  .pill.red.outline.active:not(.disabled):hover,
  .pill.red.outline.active:not(.disabled):focus-visible {
    --atp-icon-fill: var(--atp-danger-primary-strong-hover);

    border: 1px solid var(--atp-danger-primary-strong-hover);
    color: var(--atp-danger-primary-strong-hover);
  }

  .pill.red.outline.active:not(.disabled):active {
    --atp-icon-fill: var(--atp-danger-primary-strong-pressed);

    border: 1px solid var(--atp-danger-primary-strong-pressed);
    color: var(--atp-danger-primary-strong-pressed);
  }

  .pill.red.outline.disabled {
    --atp-icon-fill: var(--atp-danger-primary-strong-disabled);

    border: 1px solid var(--atp-danger-primary-strong-disabled);
    color: var(--atp-danger-primary-strong-disabled);
  }
`;
var Ht = Object.defineProperty, Vt = Object.getOwnPropertyDescriptor, J = (e, t, i, r) => {
  for (var a = r > 1 ? void 0 : r ? Vt(t, i) : t, o = e.length - 1, s; o >= 0; o--)
    (s = e[o]) && (a = (r ? s(t, i, a) : s(a)) || a);
  return r && a && Ht(t, i, a), a;
}, Mt = /* @__PURE__ */ ((e) => (e.BLUE = "blue", e.GREEN = "green", e.PINK = "pink", e.PURPLE = "purple", e.ORANGE = "orange", e.DARK_BLUE = "dark-blue", e.RED = "red", e))(Mt || {}), zt = /* @__PURE__ */ ((e) => (e.FILL = "fill", e.OUTLINE = "outline", e))(zt || {});
let S = class extends b {
  constructor() {
    super(...arguments), this.label = "", this.appearance = "fill", this.color = "blue", this.isAction = !1, this.disabled = !1;
  }
  render() {
    return n`${this.isAction ? n`<button
          @click="${this._handleClick}"
          class="${this._getClasses()}"
          ?disabled="${this.disabled}"
        >
          ${this.iconLeft ? n`<atp-icon
                .icon=${this.iconLeft.icon}
                .height=${this.iconLeft.height}
                .color=${this.iconLeft.color}
              ></atp-icon>` : c}
          ${this.label}
          ${this.iconRight ? n`<atp-icon
                .icon=${this.iconRight.icon}
                .height=${this.iconRight.height}
                .color=${this.iconRight.color}
              ></atp-icon>` : c}
        </button>` : n`<div class="${this._getClasses()}">
          ${this.iconLeft ? n`<atp-icon
                .icon=${this.iconLeft.icon}
                .height=${this.iconLeft.height}
                .color=${this.iconLeft.color}
              ></atp-icon>` : c}
          ${this.label}
          ${this.iconRight ? n`<atp-icon
                .icon=${this.iconRight.icon}
                .height=${this.iconRight.height}
                .color=${this.iconRight.color}
              ></atp-icon>` : c}
        </div>`}`;
  }
  _getClasses() {
    return v({
      pill: !0,
      [this.color]: !0,
      disabled: this.disabled,
      [this.appearance]: !0,
      active: this.isAction
    });
  }
  _handleClick() {
    this.isAction && !this.disabled && this.dispatchEvent(new CustomEvent("pillClickEventOutput", { bubbles: !0, composed: !0 }));
  }
};
S.styles = [m, Lt];
J([
  l()
], S.prototype, "label", 2);
J([
  l({ type: Object })
], S.prototype, "iconLeft", 2);
J([
  l({ type: Object })
], S.prototype, "iconRight", 2);
J([
  l()
], S.prototype, "appearance", 2);
J([
  l()
], S.prototype, "color", 2);
J([
  l({ type: Boolean })
], S.prototype, "isAction", 2);
J([
  l({ type: Boolean })
], S.prototype, "disabled", 2);
S = J([
  u("atp-pill")
], S);
const Et = g`
  .progress {
    appearance: none;
    block-size: var(--atp-meter-height);
    inline-size: var(--atp-meter-width);
    background: var(--atp-meter-track-color);
    border: none;
    border-radius: var(--atp-meter-border-radius);
  }

  .progress::-webkit-progress-bar {
    block-size: var(--atp-meter-height);
    background: transparent;
  }

  .progress::-webkit-progress-value {
    background: var(--atp-meter-fill-color);
    border-radius: var(--atp-meter-border-radius);
  }

  /* 
   * For Firefox, "-bar" is the filled portion, instead of "-value". 
   * To style the underlying track, style the <progress> component itself.
   */
  .progress::-moz-progress-bar {
    background: var(--atp-meter-fill-color);
    border-radius: var(--atp-meter-border-radius);
  }

  /* circular progress */
  .circle {
    block-size: var(--atp-meter-circle-size);
    inline-size: var(--atp-meter-circle-size);
    border-radius: 50%;
    appearance: none;
    border: none;

    /* 
      Transition the gradient by 1 degree to smooth the rendering of the subpixel rounding.
      Without this, the edge of the filled section can look a little chunky.
    */
    background: conic-gradient(
      var(--atp-meter-fill-color) calc(360deg / var(--atp-meter-max) * var(--atp-meter-value)),
      var(--atp-meter-track-color)
        calc(360deg / var(--atp-meter-max) * var(--atp-meter-value) + 1deg),
      var(--atp-meter-track-color) 360deg
    );

    /* 
      Transition the gradient by a few percentage points to smooth the rendering of the subpixel rounding.
      Without this, the inside of the circle can look a little chunky.
    */

    /* stylelint-disable -- mask-image doesn't have baseline support yet, but the vendor prefix covers us */
    -webkit-mask-image: radial-gradient(
      transparent var(--atp-meter-circle-mask-size),
      black calc(var(--atp-meter-circle-mask-size) + 2%)
    );
    mask-image: radial-gradient(
      transparent var(--atp-meter-circle-mask-size),
      black calc(var(--atp-meter-circle-mask-size) + 2%)
    );
    /* stylelint-enable */
  }

  .circle::-webkit-progress-bar {
    background: transparent;
  }

  .circle::-webkit-progress-value {
    background: transparent;
  }

  .circle::-moz-progress-bar {
    background: transparent;
  }
`;
var Zt = Object.defineProperty, At = Object.getOwnPropertyDescriptor, q1 = (e, t, i, r) => {
  for (var a = r > 1 ? void 0 : r ? At(t, i) : t, o = e.length - 1, s; o >= 0; o--)
    (s = e[o]) && (a = (r ? s(t, i, a) : s(a)) || a);
  return r && a && Zt(t, i, a), a;
}, Ot = /* @__PURE__ */ ((e) => (e.DEFAULT = "default", e.CIRCLE = "circle", e))(Ot || {});
let C1 = class extends b {
  constructor() {
    super(...arguments), this.appearance = "default";
  }
  render() {
    return n`<progress
      class=${this._getClasses()}
      value=${this.value}
      max=${this.max}
      style="--atp-meter-value: ${this.value}; --atp-meter-max: ${this.max};"
    >
      at ${this.value} of ${this.max}
    </meter>`;
  }
  _getClasses() {
    return v({
      progress: !0,
      circle: this.appearance === "circle"
      /* CIRCLE */
    });
  }
};
C1.styles = [m, Et];
q1([
  l()
], C1.prototype, "appearance", 2);
q1([
  l({ type: Number })
], C1.prototype, "max", 2);
q1([
  l({ type: Number })
], C1.prototype, "value", 2);
C1 = q1([
  u("atp-progress")
], C1);
const Bt = g`
  :host {
    --atp-radio-button-input-width: 16px;
    --atp-radio-button-input-border-width: 2px;
    --atp-radio-button-between-input-and-label: var(--atp-space-xs);
    --atp-radio-button-label-padding-left: calc(
      var(--atp-radio-button-input-width) + var(--atp-radio-button-between-input-and-label)
    );
    --atp-radio-button-icon-width: 6px;
    --atp-radio-button-icon-inset: calc(
      (var(--atp-radio-button-input-width) - var(--atp-radio-button-icon-width)) / 2
    );
    --atp-radio-button-bordered-padding-top: var(--atp-space-xs);
    --atp-radio-button-bordered-padding-left: var(--atp-space-s);
  }

  .radio-button-group {
    display: flex;
    flex-direction: column;
    gap: var(--atp-space-xs);
    margin: 0;
    min-inline-size: 0;
    padding: 0;
    border: none;
  }

  .radio-button-container {
    position: relative;
    display: inline-flex;
    align-items: center;
  }

  .input {
    position: absolute;
    block-size: 1px;
    inline-size: 1px;
    overflow: hidden;
    clip-path: inset(50%);
    white-space: nowrap;
  }

  .label {
    position: relative;
    color: var(--atp-content-primary-medium-enabled);
    cursor: pointer;
    display: inline-block;
    min-block-size: var(--atp-space-s);
    margin-block: 0;
    padding-inline-start: var(--atp-radio-button-label-padding-left);
    font-size: var(--atp-font-size-body-s);
    font-weight: normal;
    line-height: var(--atp-line-height-body-s);
    vertical-align: middle;
    white-space: nowrap;
  }

  .label:focus-visible,
  .input:focus-visible + .label {
    border-radius: 1px;
    outline: var(--atp-focus-width) solid var(--atp-focus-color);
    outline-offset: var(--atp-focus-outline-offset);
  }

  /* the visible "radio button" */
  .label::before {
    background: var(--atp-neutral-0);
    border: var(--atp-radio-button-input-border-width) solid currentColor;
    border-radius: 100%;
    color: var(--atp-content-primary-medium-enabled); /* used for border and dot color */
    content: '';
    padding: 0 1px;
    position: absolute;
    display: block;
    inset-block-start: 50%;
    inset-inline-start: 0;
    transform: translateY(-50%);
    block-size: var(--atp-radio-button-input-width);
    inline-size: var(--atp-radio-button-input-width);
    z-index: var(--atp-z-index-base);
  }

  .label:hover::before {
    color: var(--atp-utility-primary-medium-hover);
  }

  .label:active::before {
    color: var(--atp-utility-primary-medium-pressed);
  }

  /* the radio button dot "icon" */
  .label::after {
    content: '';
    background: currentcolor;
    border-radius: 100%;
    padding: 0;
    position: absolute;
    display: none;
    inset-block-start: var(--atp-radio-button-icon-inset);
    inset-inline-start: var(--atp-radio-button-icon-inset);
    block-size: var(--atp-radio-button-icon-width);
    inline-size: var(--atp-radio-button-icon-width);
    z-index: var(--atp-z-index-over-base);
  }

  /* the radio button dot "icon" */
  .input:checked + .label::after {
    display: block;
  }

  /* stylelint-disable no-descending-specificity -- so we can keep states grouped together */

  /* checked state */
  .input:checked + .label::before,
  .input:checked + .label::after {
    color: var(--atp-utility-primary-medium-enabled);
  }

  .input:checked + .label:hover::before,
  .input:checked + .label:hover::after {
    color: var(--atp-utility-primary-medium-hover);
  }

  .input:checked + .label:active::before,
  .input:checked + .label:active::after {
    color: var(--atp-utility-primary-medium-pressed);
  }

  /* disabled state */
  .input:disabled + .label {
    color: var(--atp-button-primary-medium-disabled);
    cursor: not-allowed;
  }

  .input:disabled + .label::before,
  .input:disabled + .label::after {
    color: var(--atp-content-primary-weak-disabled);
  }

  .input:checked:disabled + .label::before,
  .input:checked:disabled + .label::after {
    color: var(--atp-utility-primary-medium-disabled);
  }

  /* error/invalid */
  .error .label::before {
    color: var(--atp-danger-primary-strong-enabled);
  }

  .error .label:hover::before {
    color: var(--atp-danger-primary-strong-hover);
  }

  .error .label:active::before {
    color: var(--atp-danger-primary-strong-pressed);
  }

  .error .input:checked + .label::before,
  .error .input:checked + .label::after {
    color: var(--atp-danger-primary-strong-enabled);
  }

  .error .input:disabled + .label::before,
  .error .input:disabled + .label:hover::before,
  .error .input:disabled + .label:active::before {
    color: var(--atp-danger-primary-strong-disabled);
  }

  /* bordered */
  .bordered .label {
    display: inline-block;
    padding: var(--atp-radio-button-bordered-padding-top) var(--atp-space-s) var(--atp-space-xs)
      calc(
        var(--atp-radio-button-label-padding-left) + var(--atp-radio-button-bordered-padding-left)
      );
    border-radius: var(--atp-border-radius-s);
    border: 1px solid var(--atp-element-border-primary-medium-enabled);
  }

  .bordered .label::before {
    inset-inline-start: var(--atp-radio-button-bordered-padding-left);
  }

  .bordered .label::after {
    inset-block-start: calc(
      var(--atp-radio-button-icon-inset) + var(--atp-radio-button-bordered-padding-top)
    );
    inset-inline-start: calc(
      var(--atp-radio-button-icon-inset) + var(--atp-radio-button-bordered-padding-left)
    );
  }

  .bordered .input:checked + .label {
    background: var(--atp-element-fill-blue-medium-enabled);
    border-color: var(--atp-utility-primary-medium-enabled);
  }

  .bordered .label:hover,
  .bordered .input:checked + label:hover {
    border-color: var(--atp-utility-primary-medium-enabled);
  }

  .bordered .label:active,
  .bordered .input:checked + label:active {
    border-color: var(--atp-utility-primary-medium-pressed);
  }

  .bordered .input:disabled + .label,
  .bordered .input:checked:disabled + .label {
    background: var(--atp-element-fill-inverse-medium-disabled);
    border-color: var(--atp-element-border-primary-medium-enabled);
  }

  .bordered.error + .label {
    border-color: var(--atp-danger-primary-strong-enabled);
  }

  .bordered.error .input:checked + .label {
    background-color: var(--atp-element-fill-red-weak-enabled);
    border-color: var(--atp-danger-primary-strong-enabled);
  }

  .bordered.error + .label:hover {
    background-color: var(--atp-element-fill-red-weak-hover);
    border-color: var(--atp-danger-primary-strong-hover);
  }

  .bordered.error + .label:active {
    background-color: var(--atp-element-fill-red-weak-pressed);
    border-color: var(--atp-danger-primary-strong-pressed);
  }

  .bordered.error .input:disabled + .label {
    background: var(--atp-element-fill-inverse-medium-disabled);
    border-color: var(--atp-element-border-primary-medium-enabled);
  }

  .bordered .icon {
    inset-inline-start: calc(
      var(--atp-radio-button-bordered-padding-left) +
        ((var(--atp-radio-button-input-width) - var(--atp-radio-button-icon-width)) / 2)
    );
  }

  /* horizontal */
  .horizontal {
    justify-content: flex-start;
    flex-direction: row;
  }

  .horizontal .radio-button-container {
    flex: 1 1 0;
    inline-size: 100%;
  }

  .horizontal .label {
    display: block;
    inline-size: 100%;
  }

  /* stylelint-enable no-descending-specificity */
`;
var It = Object.defineProperty, St = Object.getOwnPropertyDescriptor, Q = (e, t, i, r) => {
  for (var a = r > 1 ? void 0 : r ? St(t, i) : t, o = e.length - 1, s; o >= 0; o--)
    (s = e[o]) && (a = (r ? s(t, i, a) : s(a)) || a);
  return r && a && It(t, i, a), a;
}, Tt = /* @__PURE__ */ ((e) => (e.HORIZONTAL = "horizontal", e.VERTICAL = "vertical", e))(Tt || {});
let T = class extends b {
  constructor() {
    super(), this.bordered = !1, this.isError = !1, this.required = !1, this.direction = "vertical", this.itemsList = [], this.fieldsetRef = h1(), this._invalidMessage = "Please make a selection.", this._internals = this.attachInternals();
  }
  // read-only property that returns the value of the selected radio button
  get value() {
    return this.getGroupValue();
  }
  getGroupValue() {
    const e = this.fieldsetRef.value?.querySelectorAll("input");
    if (!e) return null;
    for (const t of Array.from(e))
      if (t.checked)
        return t.value;
    return null;
  }
  static get formAssociated() {
    return !0;
  }
  render() {
    return n`
      <fieldset
        class="${this._getClasses()}"
        role="radiogroup"
        aria-errormessage=${V(this.ariaErrorMessage)}
        ${b1(this.fieldsetRef)}
      >
        ${this.itemsList.map(
      (e) => n`
            <div class="radio-button-container">
              <input
                type="radio"
                class="input"
                name=${this.name}
                value=${e.value}
                id=${e.id}
                ?checked=${e.checked}
                ?disabled=${e.disabled}
                ?required=${this.required}
                ?aria-required="${this.required}"
                ?aria-invalid="${this.isError}"
                @click=${this._onClick}
                @change=${this._onChange}
                @blur=${this._onBlur}
                @focus=${this._onFocus}
              />
              <label class="label" for=${e.id}>${e.label}</label>
            </div>
          `
    )}
      </fieldset>
    `;
  }
  _getClasses() {
    return v({
      "radio-button-group": !0,
      bordered: this.bordered,
      error: this.isError,
      horizontal: this.direction === "horizontal"
      /* HORIZONTAL */
    });
  }
  setValidity() {
    const e = this.getGroupValue(), t = !(this.required && !e);
    return this._internals.setValidity({ valueMissing: !t }, t ? "" : this._invalidMessage), this._internals.setFormValue(e), t;
  }
  checkValidity() {
    return this._internals.checkValidity();
  }
  reportValidity() {
    this._internals.reportValidity();
  }
  get validity() {
    return this._internals.validity;
  }
  get validationMessage() {
    return this._internals.validationMessage;
  }
  updated(e) {
    e.has("required") && this.setValidity(), this._internals.setFormValue(this.getGroupValue());
  }
  connectedCallback() {
    super.connectedCallback(), this.setValidity(), this._internals.setFormValue(this.getGroupValue());
  }
  /* event dispatches */
  _onChange(e) {
    const t = e.target;
    this.itemsList = this.itemsList.map((i) => ({
      ...i,
      checked: i.id === t.id
    })), this._internals.setFormValue(t.value), this.setValidity(), this.dispatchEvent(new CustomEvent("changeEventOutput", { bubbles: !0, composed: !0 }));
  }
  _onClick(e) {
    e.target.dispatchEvent(
      new CustomEvent("clickEventOutput", {
        bubbles: !0,
        composed: !0,
        detail: e.target.id
      })
    );
  }
  _onFocus(e) {
    e.target.dispatchEvent(
      new CustomEvent("focusEventOutput", {
        bubbles: !0,
        composed: !0,
        detail: e.target.id
      })
    );
  }
  _onBlur(e) {
    e.target.dispatchEvent(
      new CustomEvent("blurEventOutput", {
        bubbles: !0,
        composed: !0,
        detail: e.target.id
      })
    );
  }
};
T.styles = [m, Bt];
Q([
  l()
], T.prototype, "name", 2);
Q([
  l({ type: Boolean })
], T.prototype, "bordered", 2);
Q([
  l({ type: Boolean, reflect: !0 })
], T.prototype, "isError", 2);
Q([
  l({ type: String })
], T.prototype, "ariaErrorMessage", 2);
Q([
  l({ type: Boolean, reflect: !0 })
], T.prototype, "required", 2);
Q([
  l()
], T.prototype, "direction", 2);
Q([
  l({ type: Array })
], T.prototype, "itemsList", 2);
T = Q([
  u("atp-radio-button-group")
], T);
const Pt = g`
  :host:has(.no-top-content) {
    --atp-app-sidebar-width: 224px;
    --atp-toggle-button-distance: calc(var(--atp-app-sidebar-width) + var(--atp-space-s));
  }

  /** TODO: There is going to be an animation but it is still being designed */

  .icon-rotate {
    transform: rotateY(180deg);
  }

  .top-button {
    padding-block-end: var(--atp-space-s);
    display: block;
  }

  :host:has(.no-top-content) .top-button {
    margin-block-end: 0;
  }

  .hidden {
    display: none;
    transition: display 0.2s;
    transition-behavior: allow-discrete;
  }

  /* stylelint-disable-next-line -- we are allowing this as a progressive enhancement */
  .hidden::starting-style {
    display: block;
  }

  .toggle-button {
    position: absolute;
    inset-inline-start: var(--atp-toggle-button-distance);
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    block-size: var(--atp-space-l);
    inline-size: var(--atp-space-l);
    border-radius: 50%;
    border: 1px solid var(--atp-neutral-200);
    background: var(--atp-neutral-0);
    inset-block-start: var(--atp-toggle-button-position-top);
  }

  .toggle-button:hover,
  .toggle-button:focus-visible {
    border: 1px solid var(--atp-element-border-primary-medium-enabled);
    background: var(--atp-element-fill-inverse-weak-hover);
    box-shadow: var(--atp-box-shadow-sidebar-toggle);
  }

  .toggle-button:active {
    border: 1px solid var(--atp-element-border-primary-medium-enabled);
    background: var(--atp-element-fill-inverse-weak-pressed);
    box-shadow: var(--atp-box-shadow-sidebar-toggle);
  }

  .sidebar-wrapper {
    /** TODO: customize behavior when sidebar needs to scroll, left Figma comment here https://www.figma.com/design/HA7RCY6fiLpetLwLPGQdHI?node-id=1935-9768&m=dev#1343352851 */
    box-sizing: border-box;
    inline-size: var(--atp-app-sidebar-width);
    position: relative;
    max-block-size: 100%;
    display: flex;
    flex-direction: column;
  }

  .sidebar-wrapper .nav-links {
    max-block-size: 100%;
    overflow-y: auto;
  }

  .sidebar-wrapper ul {
    list-style: none;
    padding: 0;
    margin: 0;
    display: flex;
    flex-direction: column;
  }

  .sidebar-wrapper li {
    margin: 0;
    padding: 0;
    display: flex;
    flex-direction: column;
  }

  .sidebar-wrapper .list-parent {
    gap: var(--atp-space-xs);
  }

  .sidebar-wrapper .list-parent-alt {
    gap: var(--atp-space-xxs);
  }

  .sidebar-wrapper .list-child {
    padding: 0 var(--atp-space-xs) var(--atp-space-xxs) var(--atp-space-xs);
    background: var(--atp-sidebar-list-selected);
    border-end-start-radius: var(--atp-border-radius-s);
    border-end-end-radius: var(--atp-border-radius-s);
    overflow: hidden;
  }

  .sidebar-wrapper .list-grandchild {
    padding: 0 0 0 calc(var(--atp-space-s) + var(--atp-space-xxxs));
  }

  .button-parent {
    all: unset;
    background: transparent;
    padding: var(--atp-space-xxs) 0 var(--atp-space-xxs)
      calc(var(--atp-space-xs) + var(--atp-space-xxs));
    border-radius: var(--atp-border-radius-s);
    cursor: pointer;
  }

  .button-parent-alt {
    all: unset;
    background: transparent;
    padding: var(--atp-space-xxs) 0 var(--atp-space-xxs)
      calc(var(--atp-space-xs) + var(--atp-space-xxs));
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: var(--atp-space-xxs);
    border-radius: var(--atp-border-radius-s);
  }

  .sidebar-wrapper .button-parent {
    all: unset;
    background: transparent;
    padding: var(--atp-space-xxs) 0 var(--atp-space-xxs)
      calc(var(--atp-space-xs) + var(--atp-space-xxs));
    cursor: pointer;
  }

  .sidebar-wrapper .button-parent-alt {
    all: unset;
    background: transparent;
    padding: var(--atp-space-xxs) 0 var(--atp-space-xxs)
      calc(var(--atp-space-xs) + var(--atp-space-xxs));
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: var(--atp-space-xxs);
  }

  .sidebar-wrapper .list-item-parent {
    border-radius: var(--atp-space-xxs);
    color: var(--atp-content-primary-medium-enabled);
    font-family: var(--atpco-font-family);
    font-size: var(--atp-font-size-body-m);
    font-weight: var(--atp-font-weight-semibold);
    line-height: var(--atp-line-height-body-m);
  }

  .sidebar-wrapper .list-item-parent-alt {
    border-radius: var(--atp-border-radius-s);
    color: var(--atp-content-primary-medium-enabled);
    font-family: var(--atpco-font-family);
    font-size: var(--atp-font-size-body-s);
    font-weight: var(--atp-font-weight-regular);
    line-height: var(--atp-line-height-body-s);
  }

  .sidebar-wrapper .list-item-parent,
  .sidebar-wrapper .list-item-child,
  .sidebar-wrapper .list-item-grandchild,
  .sidebar-wrapper .list-item-parent-alt,
  .sidebar-wrapper .button-child,
  .sidebar-wrapper .button-child-icon,
  .sidebar-wrapper .button-parent {
    transition: 0.2s ease-out;
  }

  .sidebar-wrapper .list-item-parent:has(:hover),
  .sidebar-wrapper .list-item-parent:has(:focus-visible),
  .sidebar-wrapper .list-item-parent-alt:has(:hover),
  .sidebar-wrapper .list-item-parent-alt:has(:focus-visible) {
    background: var(--atp-sidebar-parent-item-hover);
    color: var(--atp-content-primary-strong-enabled);
  }

  .sidebar-wrapper .list-item-parent:has(:active),
  .sidebar-wrapper .list-item-parent-alt:has(:active) {
    background: var(--atp-sidebar-parent-item-active);
    color: var(--atp-content-primary-strong-enabled);
  }

  .sidebar-wrapper .list-item-parent.active,
  .sidebar-wrapper .list-item-parent-alt.active {
    background: var(--atp-sidebar-item-selected);
    color: var(--atp-content-primary-strong-enabled);
    font-weight: var(--atp-font-weight-semibold);
  }

  .sidebar-wrapper .list-item-parent.active:has(:hover),
  .sidebar-wrapper .list-item-parent.active:has(:focus-visible),
  .sidebar-wrapper .list-item-parent-alt.active:has(:hover),
  .sidebar-wrapper .list-item-parent-alt.active:has(:focus-visible) {
    background: var(--atp-sidebar-item-hover);
    color: var(--atp-content-primary-strong-enabled);
  }

  .sidebar-wrapper .list-item-parent.active:has(:active),
  .sidebar-wrapper .list-item-parent-alt.active:has(:active) {
    background: var(--atp-sidebar-item-active);
    color: var(--atp-content-primary-strong-enabled);
  }

  .sidebar-wrapper .list-item-parent.is-open {
    background: var(--atp-sidebar-list-selected);
    border-radius: var(--atp-border-radius-s);
    color: var(--atp-content-primary-medium-enabled);
    font-weight: var(--atp-font-weight-semibold);
  }

  .sidebar-wrapper .list-item-child {
    position: relative;
    color: var(--atp-content-primary-strong-enabled);
    font-family: var(--atpco-font-family);
    font-size: var(--atp-font-size-body-s);
    font-weight: var(--atp-font-weight-regular);
    line-height: var(--atp-line-height-body-s);
  }

  .sidebar-wrapper .list-item-grandchild {
    border-radius: var(--atp-border-radius-s);
    color: var(--atp-content-primary-medium-enabled);
    font-family: var(--atpco-font-family);
    font-size: var(--atp-font-size-body-s);
    font-weight: var(--atp-font-weight-regular);
    line-height: var(--atp-line-height-body-s);
  }

  .sidebar-wrapper .button-child-icon {
    all: unset;
    cursor: pointer;
    position: absolute;
    inset-block-start: var(--atp-space-xxs);
    inset-inline-start: var(--atp-space-xxs);
    block-size: var(--atp-space-s);
    inline-size: var(--atp-space-s);
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: var(--atp-border-radius-s);
  }

  .button-grandchild {
    all: unset;
    padding: var(--atp-space-xxs) 0 var(--atp-space-xxs) var(--atp-space-s);
    border-radius: var(--atp-border-radius-s);
    cursor: pointer;
  }

  .sidebar-wrapper .button-child {
    all: unset;
    border-radius: var(--atp-border-radius-s);
    padding: var(--atp-space-xxs) 0 var(--atp-space-xxs) var(--atp-space-xxs);
    display: flex;
    gap: var(--atp-space-xs);
    align-items: center;
    cursor: pointer;
  }

  .sidebar-wrapper .button-grandchild {
    all: unset;
    padding: var(--atp-space-xxs) 0 var(--atp-space-xxs) var(--atp-space-s);
    cursor: pointer;
  }

  .sidebar-wrapper .button-parent:focus-visible,
  .sidebar-wrapper .button-parent-alt:focus-visible,
  .sidebar-wrapper .button-child:focus-visible,
  .sidebar-wrapper .button-child-icon:focus-visible,
  .sidebar-wrapper .button-grandchild:focus-visible {
    border-radius: var(--atp-border-radius-s);
    outline: 0;
    box-shadow: inset 0 0 0 var(--atp-focus-width) var(--atp-focus-color);
  }

  .sidebar-wrapper .button-child-icon:hover,
  .sidebar-wrapper .button-child-icon:focus-visible {
    background: var(--atp-sidebar-item-hover);
  }

  .sidebar-wrapper .button-child-icon:active {
    background: var(--atp-sidebar-item-active);
  }

  .sidebar-wrapper .button-child:hover,
  .sidebar-wrapper .button-child:focus-visible,
  .sidebar-wrapper .list-item-grandchild:has(:hover),
  .sidebar-wrapper .list-item-grandchild:has(:focus-visible) {
    background: var(--atp-sidebar-item-hover);
    color: var(--atp-content-primary-strong-enabled);
  }

  .sidebar-wrapper .button-child:active,
  .sidebar-wrapper .list-item-grandchild:has(:active) {
    background: var(--atp-sidebar-item-active);
  }

  .sidebar-wrapper .list-item-child:has(.button-child-icon) .button-child {
    padding-inline-start: var(--atp-space-m);
  }

  .sidebar-wrapper .list-item-child.active .button-child,
  .sidebar-wrapper .list-item-grandchild.active {
    background: var(--atp-sidebar-item-selected);
    color: var(--atp-content-primary-strong-enabled);
    font-weight: var(--atp-font-weight-semibold);
  }

  .sidebar-wrapper .list-item-child.active .button-child:hover,
  .sidebar-wrapper .list-item-child.active .button-child.active:focus-visible,
  .sidebar-wrapper .list-item-grandchild.active:has(:hover),
  .sidebar-wrapper .list-item-grandchild.active:has(:focus-visible) {
    background: var(--atp-sidebar-item-hover);
    color: var(--atp-content-primary-strong-enabled);
  }

  .sidebar-wrapper .list-item-child.active .button-child:active,
  .sidebar-wrapper .list-item-grandchild.active:has(:active) {
    background: var(--atp-sidebar-item-active);
    color: var(--atp-content-primary-strong-enabled);
  }

  .sidebar-wrapper .divider {
    background: var(--atp-element-border-primary-medium-enabled);
    block-size: 1px;
    inline-size: 100%;
    margin: var(--atp-space-s) 0;
  }

  a:focus-visible,
  button:focus-visible {
    outline: var(--atp-focus-width) solid var(--atp-focus-color);
    outline-offset: var(--atp-focus-outline-offset);
  }
`;
var Rt = Object.defineProperty, Dt = Object.getOwnPropertyDescriptor, U = (e, t, i, r) => {
  for (var a = r > 1 ? void 0 : r ? Dt(t, i) : t, o = e.length - 1, s; o >= 0; o--)
    (s = e[o]) && (a = (r ? s(t, i, a) : s(a)) || a);
  return r && a && Rt(t, i, a), a;
};
let B = class extends b {
  constructor() {
    super(...arguments), this.openIds = [], this.sidebarHidden = !1, this.outputNavigationEvents = !1, this._buttonContent = !1, this._sidebarOpenIcon = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 15 12" fill="none">
<path d="M5.96304 9.53973C6.17899 9.57359 6.29677 9.78518 6.31641 10.1745C6.29677 10.53 6.17899 10.7246 5.96304 10.7585L0.655048 10.7585C0.448918 10.7246 0.336038 10.513 0.316406 10.1237C0.316406 9.97137 0.350761 9.83596 0.419471 9.71747C0.488181 9.59898 0.566707 9.53973 0.655048 9.53973L5.96304 9.53973ZM5.96304 1.41475C6.0612 1.41475 6.14463 1.48245 6.21334 1.61787C6.28205 1.73636 6.31641 1.88024 6.31641 2.04951C6.29677 2.40498 6.17899 2.59964 5.96304 2.6335H0.655048C0.566707 2.6335 0.488181 2.56579 0.419471 2.43037C0.350761 2.31188 0.316406 2.168 0.316406 1.99873C0.316406 1.84639 0.350761 1.71097 0.419471 1.59248C0.488181 1.47399 0.566707 1.41475 0.655048 1.41475L5.96304 1.41475ZM5.96304 5.47725C6.17899 5.5111 6.29677 5.71423 6.31641 6.08662C6.29677 6.45902 6.17899 6.66214 5.96304 6.696H0.655048C0.448918 6.66214 0.336038 6.45902 0.316406 6.08662C0.336038 5.71423 0.448918 5.5111 0.655048 5.47725H3.30904H5.96304Z" fill="var(--atp-content-primary-strong-enabled)"/>
<path d="M9.73828 11.0795L14.0273 6.42633C14.1523 6.26392 14.2148 6.11775 14.2148 5.98782C14.2148 5.84165 14.1602 5.7036 14.0508 5.57367L9.76172 0.920534C9.51172 0.693155 9.24609 0.693155 8.96484 0.920534C8.74609 1.18039 8.74609 1.4565 8.96484 1.74884L12.8789 5.98782L8.94141 10.2512C8.72266 10.5435 8.72266 10.8196 8.94141 11.0795C9.22266 11.3068 9.48828 11.3068 9.73828 11.0795Z" fill="var(--atp-content-primary-strong-enabled)"/>
</svg>`;
  }
  render() {
    return n`
      <aside
        @keydown=${this._handleKeydown}
        class="${this._getSidebarClass()}"
        aria-label="Main sidebar"
      >
        <button
          aria-label="Toggle sidebar"
          aria-expanded="${!this.sidebarHidden}"
          aria-controls="sidebar"
          @click=${() => this._toggleSidebar(!this.sidebarHidden)}
          class="toggle-button"
        >
          <atp-icon class="${this._getToggleClass()}" .height=${12} .icon=${this._sidebarOpenIcon}>
          </atp-icon>
        </button>
        <div class="top-button ${this.sidebarHidden ? "hidden" : ""}">
          <slot @slotchange=${this._onSlotChange} name="top-button"></slot>
        </div>
        <nav
          class="nav-links ${this.sidebarHidden ? "hidden" : ""}"
          aria-label="Sidebar navigation"
          style="${this._setCustomColors()}"
        >
          <ul class="list list-parent">
            ${this.items?.map(
      (e) => n`<li
                  class="${this._getButtonClasses(
        ["list-item-parent"],
        e.id === this.activeId && e.children?.length === 0,
        this._containsActive(e) && e.children?.length > 0
      )}"
                >
                  <a
                    class="button-parent"
                    href="${e.route}"
                    aria-expanded=${e.children?.length > 0 ? this._containsActive(e) : c}
                    aria-current=${e.id === this.activeId || c}
                    @click=${(t) => this._navigationHandler(t, e)}
                  >
                    ${e.name}
                  </a>
                  ${e.children?.length > 0 && this._containsActive(e) ? n`<ul class="list list-child">
                        ${e.children.map(
        (t) => n`<li
                              class="${this._getButtonClasses(
          ["list-item-child"],
          t.id === this.activeId,
          this.openIds.includes(t.id)
        )}"
                            >
                              ${t.children?.length > 0 ? n`<button
                                    class="${this._getButtonClasses(
          ["button-child-icon"],
          !1,
          this.openIds.includes(t.id)
        )}"
                                    aria-label="${t.name} menu toggle"
                                    aria-expanded="${this.openIds.includes(t.id)}"
                                    @click=${() => this._toggleOpenId(t.id)}
                                  >
                                    <atp-icon
                                      .height="${12}"
                                      .icon=${this.openIds.includes(t.id) ? "chevron-down" : "chevron-right"}
                                    ></atp-icon>
                                  </button>` : c}
                              ${t.route ? n`<a
                                    aria-current=${t.id === this.activeId || c}
                                    aria-expanded=${t.children?.length > 0 ? this.openIds.includes(t.id) : c}
                                    href="${t.route}"
                                    @click=${(i) => this._navigationHandler(i, t)}
                                    class="button-child"
                                  >
                                    ${t.name}
                                  </a>` : n`<button
                                    @click=${() => this._toggleOpenId(t.id)}
                                    class="button-child"
                                    aria-expanded="${this.openIds.includes(t.id)}"
                                  >
                                    ${t.name}
                                  </button>`}
                              ${t.children?.length > 0 && this.openIds.includes(t.id) ? n`<ul class="list list-grandchild">
                                    ${t.children.map(
          (i) => n`<li
                                          class="${this._getButtonClasses(
            ["list-item-grandchild"],
            i.id === this.activeId,
            this.openIds.includes(i.id)
          )}"
                                        >
                                          <a
                                            aria-current=${i.id === this.activeId || c}
                                            href="${i.route}"
                                            @click=${(r) => this._navigationHandler(r, i)}
                                            class="button-grandchild"
                                          >
                                            ${i.name}
                                          </a>
                                        </li>`
        )}
                                  </ul>` : c}
                            </li>`
      )}
                      </ul>` : c}
                </li>`
    )}
          </ul>
          ${this.secondaryItems?.length > 0 ? n`<div class="divider"></div>
                <ul class="list list-parent-alt">
                  ${this.secondaryItems.map(
      (e) => n`<li
                        class="${this._getButtonClasses(
        ["list-item-parent-alt"],
        e.id === this.activeId,
        !1
      )}"
                      >
                        <a
                          aria-current=${e.id === this.activeId || c}
                          class="button-parent-alt"
                          href="${e.route}"
                          @click=${(t) => this._navigationHandler(t, e)}
                        >
                          ${e.icon ? n`<atp-icon
                                .height=${e.icon.height}
                                .icon=${e.icon.icon}
                              ></atp-icon>` : c}
                          ${e.name}
                        </a>
                      </li>`
    )}
                </ul>` : c}
        </nav>
      </aside>
    `;
  }
  _setCustomColors() {
    return this.colorConfig ? `--atp-sidebar-item-hover: ${this.colorConfig.hover};
  --atp-sidebar-item-active: ${this.colorConfig.active};
  --atp-sidebar-item-selected: ${this.colorConfig.selected};
  --atp-sidebar-list-selected: ${this.colorConfig.selectedSection};` : "";
  }
  _onSlotChange() {
    const t = (this._buttonSlot?.assignedNodes({ flatten: !0 }) ?? []).some((i) => i.nodeType === Node.ELEMENT_NODE);
    this._buttonContent = t;
  }
  _toggleSidebar(e) {
    this.sidebarHidden = e, this.toggleAttribute("toggled", this.sidebarHidden);
  }
  _navigationHandler(e, t) {
    this.outputNavigationEvents && (e.preventDefault(), this.dispatchEvent(
      new CustomEvent("navigationEventOutput", { bubbles: !0, composed: !0, detail: t })
    ));
  }
  _toggleOpenId(e) {
    this.openIds.includes(e) ? this.openIds = this.openIds.filter((t) => t !== e) : this.openIds = [...this.openIds, e];
  }
  firstUpdated() {
    this.toggleAttribute("toggled", this.sidebarHidden);
  }
  updated(e) {
    super.updated(e), e.has("activeId") && this.updateComplete.then(() => {
      this.items.forEach((t) => {
        t.children?.forEach((i) => {
          (i.id === this.activeId || i.children?.some((r) => r.id === this.activeId)) && (this.openIds = [...this.openIds, i.id]);
        });
      });
    });
  }
  _containsActive(e) {
    return e.id === this.activeId || e.children?.some(
      (t) => t.id === this.activeId || t.children?.some((i) => i.id === this.activeId)
    );
  }
  _handleKeydown(e) {
    e.key === "Escape" && this._toggleSidebar(!0);
  }
  _getSidebarClass() {
    return v({
      "sidebar-wrapper": !0,
      "no-top-content": !this._buttonContent
    });
  }
  _getToggleClass() {
    return v({
      "icon-rotate": !this.sidebarHidden
    });
  }
  _getButtonClasses(e, t, i) {
    return v({
      "list-item-parent": e.includes("list-item-parent"),
      "list-item-parent-alt": e.includes("list-item-parent-alt"),
      "list-item-child": e.includes("list-item-child"),
      "list-item-grandchild": e.includes("list-item-grandchild"),
      "button-child-icon": e.includes("button-child-icon"),
      active: t,
      "is-open": i
    });
  }
};
B.styles = [m, Pt];
U([
  l({ type: Array })
], B.prototype, "items", 2);
U([
  l()
], B.prototype, "activeId", 2);
U([
  l({ type: Array })
], B.prototype, "openIds", 2);
U([
  l({ type: Array })
], B.prototype, "secondaryItems", 2);
U([
  l({ type: Boolean })
], B.prototype, "sidebarHidden", 2);
U([
  l({ type: Object })
], B.prototype, "colorConfig", 2);
U([
  l({ type: Boolean })
], B.prototype, "outputNavigationEvents", 2);
U([
  F1('slot[name="top-button"]')
], B.prototype, "_buttonSlot", 2);
B = U([
  u("atp-sidebar")
], B);
const jt = g`
  .status {
    display: flex;
    align-items: center;
    inline-size: fit-content;
    gap: var(--atp-space-xxs);
    color: var(--atp-content-primary-medium-enabled);
    font-family: var(--atpco-font-family);
    font-size: var(--atp-font-size-body-s);
    font-weight: var(--atp-font-weight-regular);
    line-height: var(--atp-line-height-body-s);
  }

  .status.large {
    font-size: var(--atp-font-size-body-m);
    line-height: var(--atp-line-height-body-m);
    gap: var(--atp-space-xs);
  }

  .bullet {
    block-size: 0.6em;
    inline-size: 0.6em;
    border-radius: 50%;
    background-color: var(--atp-element-fill-green-strong-enabled);
  }

  .info .bullet {
    background-color: var(--atp-utility-primary-medium-enabled);
  }

  .warning .bullet {
    background-color: var(--atp-button-warning-medium-enabled);
  }

  .danger .bullet {
    background-color: var(--atp-button-danger-medium-enabled);
  }

  .status.large .bullet {
    block-size: 0.75em;
    inline-size: 0.75em;
  }

  .label-container {
    display: flex;
    flex-direction: column;
  }
`;
var Nt = Object.defineProperty, Ut = Object.getOwnPropertyDescriptor, G1 = (e, t, i, r) => {
  for (var a = r > 1 ? void 0 : r ? Ut(t, i) : t, o = e.length - 1, s; o >= 0; o--)
    (s = e[o]) && (a = (r ? s(t, i, a) : s(a)) || a);
  return r && a && Nt(t, i, a), a;
}, Ft = /* @__PURE__ */ ((e) => (e.DANGER = "danger", e.SUCCESS = "success", e.INFO = "info", e.WARNING = "warning", e))(Ft || {}), qt = /* @__PURE__ */ ((e) => (e.L = "large", e.M = "medium", e))(qt || {});
let v1 = class extends b {
  constructor() {
    super(...arguments), this.label = "", this.color = "success", this.size = "medium";
  }
  render() {
    return n`
      <div class="${this._getClasses()}">
        <span class="bullet"></span>
        <div class="label-container">
          <span>${this.label}</span>
          <slot></slot>
        </div>
      </div>
    `;
  }
  _getClasses() {
    return v({ status: !0, [this.color]: !0, [this.size]: !0 });
  }
};
v1.styles = [m, jt];
G1([
  l()
], v1.prototype, "label", 2);
G1([
  l()
], v1.prototype, "color", 2);
G1([
  l()
], v1.prototype, "size", 2);
v1 = G1([
  u("atp-status")
], v1);
const Gt = g`
  .tab-set.fit-content {
    inline-size: fit-content;
  }

  .tab-bar {
    border-block-end: 1px solid var(--atp-element-border-primary-medium-enabled);
    display: flex;
    gap: var(--atp-space-xs);
  }

  .tab-bar.fit-content {
    inline-size: fit-content;
  }

  .tab {
    all: unset;
    display: flex;
    flex-wrap: nowrap;
    gap: var(--atp-space-xs);
    align-items: center;
    block-size: var(--atp-tab-height);
    padding: 0 var(--atp-space-xs);
    color: var(--atp-button-primary-medium-enabled);
    font-family: var(--atpco-font-family);
    font-size: var(--atp-font-size-body-m);
    font-weight: var(--atp-font-weight-regular);
    line-height: var(--atp-line-height-body-m);
    letter-spacing: var(--atp-letter-spacing-s);
    cursor: pointer;
    background: transparent;
    border-radius: var(--atp-border-radius-m) var(--atp-border-radius-m) 0 0;
    border-block-end: 2px solid transparent;
    transition: background-color 0.2s ease-out, color 0.2s ease-out;
  }

  .tab:hover,
  .tab:focus-visible {
    color: var(--atp-utility-primary-medium-hover);
  }

  .tab:focus-visible {
    outline: var(--atp-focus-width) solid var(--atp-focus-color);
    outline-offset: var(--atp-focus-outline-offset);
  }

  .tab:active {
    color: var(--atp-utility-primary-medium-pressed);
  }

  .tab-badge {
    block-size: var(--atp-space-s);
    border-radius: var(--atp-border-radius-s);
    padding: 0 var(--atp-space-xxs);
    background: var(--atp-element-fill-blue-medium-enabled);
    color: var(--atp-button-primary-medium-enabled);
    font-family: var(--atpco-font-family);
    font-size: var(--atp-font-size-body-xs);
    font-weight: var(--atp-font-weight-medium);
    line-height: var(--atp-line-height-body-xs);
    display: flex;
    align-items: center;
    transition: background-color 0.2s ease-out, color 0.2s ease-out;
  }

  .tab.active {
    border-block-end: 2px solid var(--atp-element-fill-blue-strong-enabled);
    background-color: var(--atp-element-fill-blue-medium-enabled);
  }

  .tab.active .tab-badge {
    color: var(--atp-content-inverse-medium-enabled);
    background-color: var(--atp-element-fill-blue-strong-enabled);
  }

  .tab.disabled,
  .tab.disabled:is(:hover, :focus-visible, :active) {
    background: transparent;
    color: var(--atp-button-primary-medium-disabled);
    cursor: not-allowed;
  }

  .tab.disabled .tab-badge {
    color: var(--atp-button-primary-medium-disabled);
    background: var(--atp-element-fill-primary-strong-disabled);
  }

  .tab-panel {
    display: none;
  }

  .tab-panel.active {
    display: block;
    margin-block-start: var(--atp-tab-set-panel-margin-block-start, var(--atp-space-s));
  }
`;
var Wt = Object.defineProperty, Kt = Object.getOwnPropertyDescriptor, A1 = (e, t, i, r) => {
  for (var a = r > 1 ? void 0 : r ? Kt(t, i) : t, o = e.length - 1, s; o >= 0; o--)
    (s = e[o]) && (a = (r ? s(t, i, a) : s(a)) || a);
  return r && a && Wt(t, i, a), a;
};
let n1 = class extends b {
  constructor() {
    super(...arguments), this.tabs = [], this.isFullWidth = !1, this.activeIndex = 0, this.ariaLabel = null, this._lastKeyPressed = "", this._tabHandler = () => {
      this._lastKeyPressed === "Tab" && Array.from(this.renderRoot.querySelectorAll('[role="tab"]')).forEach((t, i) => {
        t.setAttribute("tabindex", i === this.activeIndex ? "0" : "-1");
      });
    };
  }
  render() {
    const e = [], t = [];
    return this.tabs.map(() => {
      e.push(o1()), t.push(o1());
    }), ((r) => {
      this.activeIndex = r;
    })(this.activeIndex), n`<div class="${this._getTabSetClasses()}">
      <div
        role="tablist"
        class="tab-bar ${this.isFullWidth ? "" : "fit-content"}"
        aria-label=${V(this.ariaLabel)}
      >
        ${this.tabs?.map(
      (r, a) => n`<button
            @keydown=${this._onKeyDown}
            @click=${() => this._clickHandler(a)}
            class="${this._getTabClasses(r, a)}"
            ?disabled=${r.disabled}
            tabindex=${a === this.activeIndex ? 0 : -1}
            id="${t[a]}"
            aria-selected="${a === this.activeIndex}"
            aria-controls="${e[a]}"
            role="tab"
          >
            ${r.name} ${r.badge ? n`<span class="tab-badge">${r.badge}</span>` : ""}
          </button>`
    )}
      </div>

      ${Array(this.tabs.length).fill(0).map(
      (r, a) => n`<div
              class="${this._getTabPanelClasses(a)}"
              role="tabpanel"
              id="${e[a]}"
              aria-labelledby="${t[a]}"
            >
              <slot name="tabpanel${a}"></slot>
            </div>`
    )}
    </div>`;
  }
  _getTabClasses(e, t) {
    return v({ tab: !0, active: t === this.activeIndex, disabled: e.disabled });
  }
  _getTabSetClasses() {
    return v({
      "tab-set": !0,
      "fit-content": !this.isFullWidth
    });
  }
  _getTabPanelClasses(e) {
    return v({
      "tab-panel": !0,
      active: e === this.activeIndex
    });
  }
  async _onKeyDown(e) {
    if (this._lastKeyPressed = e.key, e.key === "ArrowRight" || e.key === "ArrowLeft") {
      e.preventDefault();
      const t = e.target, i = Array.from(this.renderRoot.querySelectorAll('[role="tab"]'));
      let r = i.indexOf(t);
      const a = e.key === "ArrowRight" ? 1 : -1;
      r = (r + a + i.length) % i.length;
      let o = i[r];
      for (let s = 0; s < this.tabs.length && o.hasAttribute("disabled"); s++)
        r = (r + a + i.length) % i.length, o = i[r];
      i.forEach((s, p) => {
        s.setAttribute("tabindex", p === r ? "0" : "-1");
      }), o.focus();
    }
  }
  async connectedCallback() {
    super.connectedCallback(), await this.updateComplete, this._tabBarRef = this.renderRoot.querySelector('[role="tablist"]'), this._tabBarRef?.addEventListener("focusout", this._tabHandler);
  }
  disconnectedCallback() {
    this._tabBarRef?.removeEventListener("focusout", this._tabHandler), super.disconnectedCallback();
  }
  _clickHandler(e) {
    this.activeIndex = e, this.dispatchEvent(
      new CustomEvent("clickEventOutput", { bubbles: !0, composed: !0, detail: e })
    );
  }
};
n1.styles = [m, Gt];
A1([
  l({ type: Array })
], n1.prototype, "tabs", 2);
A1([
  l({ type: Boolean })
], n1.prototype, "isFullWidth", 2);
A1([
  l({ type: Number })
], n1.prototype, "activeIndex", 2);
A1([
  l({ type: String })
], n1.prototype, "ariaLabel", 2);
n1 = A1([
  u("atp-tab-set")
], n1);
const Yt = g`
  :host {
    --atp-toggle-input-width: 34px;
    --atp-toggle-input-height: 20px;
    --atp-toggle-input-border-width: 2px;
    --atp-toggle-between-input-and-label: var(--atp-space-xs);
    --atp-toggle-label-line-height: var(--atp-line-height-body-s);
    --atp-toggle-label-padding-under-switch: calc(
      var(--atp-toggle-input-width) + var(--atp-toggle-between-input-and-label)
    );
    --atp-toggle-icon-width: 10px;

    --atp-toggle-bordered-label-padding-under-switch: calc(
      var(--atp-toggle-label-padding-under-switch) + var(--atp-toggle-bordered-padding-left)
    );
    --atp-toggle-bordered-label-padding-opposite-switch: var(--atp-space-s);
    --atp-toggle-bordered-padding-left: var(--atp-space-s);
  }

  .container {
    position: relative;
    display: inline-flex;
    align-items: flex-start;
    min-block-size: var(--atp-toggle-input-height);
  }

  .input {
    position: absolute;
    block-size: 1px;
    inline-size: 1px;
    overflow: hidden;
    clip-path: inset(50%);
    white-space: nowrap;
  }

  .label {
    color: var(--atp-content-primary-enabled-medium);
    cursor: pointer;
    display: inline-flex;
    flex-direction: column;
    min-block-size: var(--atp-toggle-input-height);
    margin-block: 0;
    padding-block-start: var(--atp-space-xxxs);
    padding-inline-start: var(--atp-toggle-label-padding-under-switch);
    font-size: var(--atp-font-size-body-s);
    font-weight: normal;
    line-height: var(--atp-toggle-label-line-height);
    vertical-align: middle;
    white-space: nowrap;
    border-radius: var(--atp-border-radius-m);
  }

  .label:focus-visible,
  .input:focus-visible + .label {
    border-radius: 1px;
    outline: var(--atp-focus-width) solid var(--atp-focus-color);
    outline-offset: var(--atp-focus-outline-offset);
  }

  /* the visible switch */
  .label::before {
    position: absolute;
    display: block;
    inset-block-start: 0;
    inset-inline-start: 0;
    background: currentcolor;
    border: var(--atp-toggle-input-border-width) solid currentcolor;
    border-radius: calc(var(--atp-toggle-input-height) / 2);

    /* color is used for border and background color via currentColor */
    color: var(--atp-element-fill-inverse-strong-enabled);
    content: '';
    padding: 0 1px;
    inline-size: var(--atp-toggle-input-width);
    block-size: var(--atp-toggle-input-height);
    z-index: var(--atp-z-index-base);
    transition: color 0.2s ease-out;
  }

  .label:hover::before {
    color: var(--atp-element-fill-inverse-strong-hover);
  }

  .label:active::before {
    color: var(--atp-element-fill-inverse-strong-pressed);
  }

  /* the switch handle */
  .label::after {
    content: '';
    position: absolute;
    inset-block-start: var(--atp-toggle-input-border-width);
    inset-inline-start: var(--atp-toggle-input-border-width);
    display: block;
    background: var(--atp-element-fill-inverse-weak-enabled);
    block-size: calc(var(--atp-toggle-input-height) - (2 * var(--atp-toggle-input-border-width)));
    inline-size: calc(var(--atp-toggle-input-height) - (2 * var(--atp-toggle-input-border-width)));
    border-radius: 100%;
    z-index: calc(var(--atp-z-index-base) + 1);
    transition: 0.2s ease-out;
  }

  /* description */
  .label-description {
    display: block;
    margin-block-start: var(--atp-space-xxs);
    font-size: var(--atp-font-size-body-xs);
    font-style: normal;
    font-weight: var(--atp-font-weight-light);
    line-height: var(--atp-line-height-body-xs);
    letter-spacing: -0.1px; /* TODO: replace with letter-spacing token */
  }

  /* on/checked state */
  .input:checked + .label::before {
    color: var(--atp-utility-primary-medium-enabled);
    background-color: currentcolor;
  }

  .input:checked + .label::after {
    inset-inline-start: calc(
      var(--atp-toggle-input-width) - var(--atp-toggle-input-height) +
        var(--atp-toggle-input-border-width)
    );
  }

  .input:checked + .label:hover::before {
    color: var(--atp-utility-primary-medium-hover);
  }

  .input:checked + .label:active::before {
    color: var(--atp-utility-primary-medium-pressed);
  }

  /* stylelint-disable no-descending-specificity -- so we can keep features grouped together */

  /* position */
  .container.label-position-left .label {
    padding-inline: 0 var(--atp-toggle-label-padding-under-switch);
  }

  .container.label-position-left .label::before {
    inset-inline: auto 0;
  }

  .container.label-position-left .label::after {
    inset-inline: auto
      calc(
        var(--atp-toggle-input-width) - var(--atp-toggle-input-height) +
          var(--atp-toggle-input-border-width)
      );
  }

  .container.label-position-left .input:checked + .label::after {
    inset-inline-end: var(--atp-toggle-input-border-width);
  }

  /* disabled state */
  .input:disabled + .label {
    cursor: not-allowed;
  }

  .input:disabled + .label::before {
    color: var(--atp-element-fill-inverse-strong-disabled);
  }

  .input:checked:disabled + .label::before {
    color: var(--atp-utility-primary-medium-disabled);
  }

  /* error/invalid */
  .input[aria-invalid] + .label::before {
    border-color: var(--atp-danger-primary-medium-enabled);
  }

  .input[aria-invalid] + .label:hover::before {
    border-color: var(--atp-danger-primary-medium-hover);
  }

  .input[aria-invalid] + .label:active::before {
    border-color: var(--atp-danger-primary-medium-pressed);
  }

  .input[aria-invalid]:checked + .label::before {
    color: var(--atp-danger-primary-strong-enabled);
    background-color: currentcolor;
    border-color: currentcolor;
  }

  .input[aria-invalid]:checked + .label:hover::before {
    color: var(--atp-danger-primary-strong-hover);
  }

  .input[aria-invalid]:checked + .label:active::before {
    color: var(--atp-danger-primary-strong-pressed);
  }

  .input[aria-invalid]:disabled + .label::before,
  .input[aria-invalid]:disabled + .label:hover::before,
  .input[aria-invalid]:disabled + .label:active::before {
    background-color: var(--atp-element-fill-inverse-strong-disabled);
    border-color: var(--atp-danger-primary-medium-disabled);
  }

  .input[aria-invalid]:checked:disabled + .label::before,
  .input[aria-invalid]:checked:disabled + .label:hover::before,
  .input[aria-invalid]:checked:disabled + .label:active::before {
    background-color: var(--atp-danger-primary-strong-disabled);
    border-color: var(--atp-danger-primary-strong-disabled);
  }

  /* bordered */
  .bordered .label {
    display: inline-block;
    min-block-size: calc(var(--atp-toggle-label-line-height) + var(--atp-toggle-input-height));
    padding: var(--atp-space-xs) var(--atp-toggle-bordered-label-padding-opposite-switch)
      var(--atp-space-xs) var(--atp-toggle-bordered-label-padding-under-switch);
    border-radius: var(--atp-border-radius-s);
    border: 1px solid var(--atp-element-border-primary-medium-enabled);
    transition: background-color 0.2s ease-out;
  }

  .bordered .label::before {
    inset-block-start: var(--atp-space-xs);
    inset-inline-start: var(--atp-toggle-bordered-padding-left);
  }

  .bordered .label::after {
    inset-block-start: calc(var(--atp-space-xs) + var(--atp-toggle-input-border-width));
    inset-inline-start: calc(
      var(--atp-toggle-bordered-padding-left) + var(--atp-toggle-input-border-width)
    );
  }

  .bordered .input:checked + .label::after {
    inset-inline-start: calc(
      var(--atp-toggle-bordered-padding-left) + var(--atp-toggle-input-height) -
        (2 * var(--atp-toggle-input-border-width))
    );
  }

  .bordered.label-position-left.bordered .label {
    padding-inline: var(--atp-toggle-bordered-label-padding-opposite-switch)
      var(--atp-toggle-bordered-label-padding-under-switch);
  }

  .bordered.label-position-left.bordered .label::before {
    inset-inline-end: var(--atp-toggle-bordered-label-padding-opposite-switch);
  }

  .bordered.label-position-left.bordered .label::after {
    inset-inline: auto
      calc(
        var(--atp-toggle-bordered-label-padding-opposite-switch) + var(--atp-toggle-input-width) -
          var(--atp-toggle-input-height) + var(--atp-toggle-input-border-width)
      );
  }

  .bordered.label-position-left.bordered .input:checked + .label::after {
    inset-inline: auto
      calc(
        var(--atp-toggle-bordered-label-padding-opposite-switch) +
          var(--atp-toggle-input-border-width)
      );
  }

  .bordered .input:checked + .label {
    background: var(--atp-element-fill-blue-medium-enabled);
    border-color: var(--atp-utility-primary-medium-enabled);
  }

  .bordered .input[aria-invalid]:checked + .label {
    background: var(--atp-element-fill-red-weak-enabled);
  }

  .bordered .label:hover,
  .bordered .input:checked + label:hover {
    border-color: var(--atp-utility-primary-medium-enabled);
  }

  .bordered .label:active,
  .bordered .input:checked + label:active {
    border-color: var(--atp-utility-primary-medium-pressed);
  }

  .bordered .input:disabled + .label,
  .bordered .input:checked:disabled + .label {
    background: var(--atp-element-fill-inverse-medium-disabled);
    border-color: var(--atp-element-border-primary-medium-enabled);
  }

  .bordered .input[aria-invalid] + .label {
    border-color: var(--atp-danger-primary-strong-enabled);
  }

  .bordered .input[aria-invalid] + .label:hover {
    background-color: var(--atp-element-fill-red-weak-hover);
    border-color: var(--atp-danger-primary-strong-hover);
  }

  .bordered .input[aria-invalid] + .label:active {
    background-color: var(--atp-element-fill-red-weak-pressed);
    border-color: var(--atp-danger-primary-strong-pressed);
  }

  .bordered .input[aria-invalid]:disabled + .label {
    background: var(--atp-element-fill-inverse-medium-disabled);
    border-color: var(--atp-element-border-primary-medium-enabled);
  }

  /* no label */
  .no-label {
    --atp-toggle-between-input-and-label: 0;

    /* stylelint-disable-next-line -- logical property value "inline-start" doesn't have baseline support yet */
    float: left;
    margin-inline-end: var(--atp-toggle-between-input-and-label);
  }

  .no-label .label {
    padding-inline-start: var(--atp-toggle-input-width);
  }

  .bordered.no-label .label {
    min-block-size: calc(1em + (2 * var(--atp-space-xs)));
    margin-inline-end: 0;
    padding: var(--atp-space-xs) var(--atp-space-xs) var(--atp-space-xs)
      calc(var(--atp-toggle-label-padding-under-switch) + var(--atp-toggle-bordered-padding-left));
  }

  /* stylelint-enable no-descending-specificity */
`;
var Xt = Object.defineProperty, Jt = Object.getOwnPropertyDescriptor, L = (e, t, i, r) => {
  for (var a = r > 1 ? void 0 : r ? Jt(t, i) : t, o = e.length - 1, s; o >= 0; o--)
    (s = e[o]) && (a = (r ? s(t, i, a) : s(a)) || a);
  return r && a && Xt(t, i, a), a;
}, Qt = /* @__PURE__ */ ((e) => (e.LEFT = "left", e.RIGHT = "right", e))(Qt || {});
let w = class extends b {
  constructor() {
    super(), this.labelPosition = "right", this.checked = !1, this.disabled = !1, this.isError = !1, this.required = !1, this.bordered = !1, this.tabindex = 0, this._inputId = o1(this.id), this.inputRef = h1(), this._invalidMessage = "This toggle is required.", this._internals = this.attachInternals();
  }
  static get formAssociated() {
    return !0;
  }
  render() {
    const e = this.description ? n`<span class="label-description">${this.description}</span>` : "";
    return n`
      <div class=${this._getContainerStyleClasses()}>
        <input
          ${b1(this.inputRef)}
          class="input"
          type="checkbox"
          name=${V(this.name)}
          value=${V(this.value)}
          ?checked=${this.checked}
          ?disabled=${this.disabled}
          ?required=${this.required}
          ?aria-required=${this.required}
          tabindex=${this.tabindex}
          id=${this._inputId}
          ?aria-invalid=${this.isError}
          aria-errormessage=${V(this.ariaErrorMessage)}
          aria-label=${V(this.ariaLabel)}
          @click=${this._onClick}
          @change=${this._onChange}
          @keydown=${this._onKeyDown}
          @blur=${this._onBlur}
          @focus=${this._onFocus}
        />
        <label
          class="label"
          for=${this._inputId}
          title=${this.label}
          @keydown=${this._onKeyDown}
          @blur=${this._onBlur}
          @focus=${this._onFocus}
        >
          ${this.label} ${e}
        </label>
      </div>
    `;
  }
  setValidity() {
    this._internals.setValidity(
      { valueMissing: this.required && !this.checked },
      this.required && !this.checked ? this._invalidMessage : ""
    ), this._internals.setFormValue(this.checked ? this.value ? this.value : "on" : null);
  }
  checkValidity() {
    return this._internals.checkValidity();
  }
  reportValidity() {
    this._internals.reportValidity();
  }
  get validity() {
    return this._internals.validity;
  }
  get validationMessage() {
    return this._internals.validationMessage;
  }
  updated(e) {
    (e.has("checked") || e.has("required")) && (this.setValidity(), this._internals.setFormValue(this.checked ? this.value ? this.value : "on" : null));
  }
  _onKeyDown(e) {
    if (e.code === "Space" && this.disabled == !1) {
      this._onChange();
      const t = this.inputRef.value;
      t.checked = !t.checked;
    }
    e.code === "Space" && e.preventDefault();
  }
  _onChange() {
    this.checked = !this.checked, this._internals.setFormValue(this.checked ? this.value ? this.value : "on" : null), this.dispatchEvent(new CustomEvent("changeEventOutput", { bubbles: !0, composed: !0 }));
  }
  _onClick() {
    this.dispatchEvent(new CustomEvent("clickEventOutput", { bubbles: !0, composed: !0 }));
  }
  _onFocus() {
    this.dispatchEvent(new CustomEvent("focusEventOutput", { bubbles: !0, composed: !0 }));
  }
  _onBlur() {
    this.dispatchEvent(new CustomEvent("blurEventOutput", { bubbles: !0, composed: !0 }));
  }
  /* TODO: update this to use the utility class that sets style classes */
  _getContainerStyleClasses() {
    return `container ${this.labelPosition === "left" ? "label-position-left" : ""} ${this.label ? "" : "no-label"} ${this.bordered ? "bordered" : ""}`.trim();
  }
  connectedCallback() {
    super.connectedCallback(), this.setValidity(), this._internals.setFormValue(this.checked ? this.value ? this.value : "on" : null);
  }
  formDisabledCallback(e) {
    this.disabled = e;
  }
};
w.styles = [m, Yt];
L([
  l({ type: String || void 0 })
], w.prototype, "label", 2);
L([
  l({ type: String || void 0 })
], w.prototype, "labelPosition", 2);
L([
  l({ type: String || void 0 })
], w.prototype, "description", 2);
L([
  l({ type: String })
], w.prototype, "name", 2);
L([
  l({ type: String })
], w.prototype, "value", 2);
L([
  l({ type: String })
], w.prototype, "ariaLabel", 2);
L([
  l({ type: String })
], w.prototype, "ariaErrorMessage", 2);
L([
  l({ type: Boolean, reflect: !0 })
], w.prototype, "checked", 2);
L([
  l({ type: Boolean })
], w.prototype, "disabled", 2);
L([
  l({ type: Boolean, reflect: !0 })
], w.prototype, "isError", 2);
L([
  l({ type: Boolean, reflect: !0 })
], w.prototype, "required", 2);
L([
  l({ type: Boolean })
], w.prototype, "bordered", 2);
L([
  l({ type: Number })
], w.prototype, "tabindex", 2);
w = L([
  u("atp-toggle")
], w);
const Ce = g`
  :host {
    --atp-card-gutter-vertical: var(--atp-space-s);
    --atp-card-gutter-horizontal-start: var(--atp-space-s);
    --atp-card-gutter-horizontal-end: var(--atp-space-s);
    --atp-card-header-font-size: var(--atp-font-size-body-l);
    --atp-card-header-line-height: var(--atp-font-size-body-l);
    --atp-card-border-width: 1px;
    --atp-card-border-radius: var(--atp-border-radius-m);
    --atp-card-border-decoration-width: 8px;
    --atp-card-border-decoration-color: var(--atp-slate-600);

    display: block;
  }

  .card {
    position: relative;
    display: block;
    block-size: 100%;
    border: var(--atp-card-border-width) solid var(--atp-element-border-primary-strong-enabled);
    border-radius: var(--atp-card-border-radius);
  }

  .card-header,
  .card-footer {
    position: relative;
    z-index: var(--atp-z-index-base);
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: var(--atp-space-xs);
  }

  .card-header,
  .card-footer,
  .card-content-wrapper {
    padding: var(--atp-card-gutter-vertical) var(--atp-card-gutter-horizontal-end)
      var(--atp-card-gutter-vertical) var(--atp-card-gutter-horizontal-start);
  }

  /* 
   For a11y, users can/should use the appropriate h* tag for the Card's heading, but we want the 
   typography and layout to stay consistent regardless of which tag (or no tag) gets used.
   We also want the same size for the footer content.
  */
  .card-header,
  .card-header ::slotted(:is(h1, h2, h3, h4, h5, h6, p)),
  .card-footer,
  .card-footer ::slotted(:is(h1, h2, h3, h4, h5, h6, p, *)) {
    margin: 0;
    font-size: var(--atp-card-header-font-size);
    line-height: var(--atp-card-header-line-height);
  }

  .card-header ::slotted(:is(h1, h2, h3, h4, h5, h6, p)) {
    font-weight: var(--atp-font-weight-bold);
  }

  .card-header {
    font-weight: bold;
  }

  .header-fill-light .card-header-wrapper {
    background: var(--atp-element-fill-primary-weak-enabled);
  }

  /* we want to maximize the width for the header/footer's actual text, but not the buttons and icons */
  .card-header ::slotted(*),
  .card-footer ::slotted(*) {
    flex-grow: 9999;
  }

  .card-header ::slotted(atp-icon),
  .card-header ::slotted(button),
  .card-header ::slotted(atp-button),
  .card-footer ::slotted(atp-icon),
  .card-footer ::slotted(button),
  .card-footer ::slotted(atp-button) {
    flex-grow: 1;
  }

  /* dividers */
  .divider-header .card-header-wrapper {
    border-block-end: 1px solid var(--atp-element-border-primary-medium-enabled);
  }

  .divider-footer .card-footer-wrapper {
    border-block-start: 1px solid var(--atp-element-border-primary-medium-enabled);
  }

  /* compact density */
  .card.density-compact {
    --atp-card-gutter-vertical: var(--atp-space-xs);
    --atp-card-gutter-horizontal-start: var(--atp-space-xs);
    --atp-card-gutter-horizontal-end: var(--atp-space-xs);
  }

  .card-header.density-compact,
  .card-footer.density-compact {
    --atp-card-header-font-size: var(--atp-font-size-body-s);
    --atp-card-gutter-vertical: var(--atp-space-xs);
    --atp-card-gutter-horizontal-start: var(--atp-space-xs);
    --atp-card-gutter-horizontal-end: var(--atp-space-xs);
  }

  /* if the card is compact and had a border, add some extra space */
  .card.density-compact.border-decoration-start {
    padding-inline-start: var(--atp-space-xs);
  }

  /* wide density */
  .card.density-wide {
    --atp-card-gutter-vertical: var(--atp-space-m);
    --atp-card-gutter-horizontal-start: var(--atp-space-m);
    --atp-card-gutter-horizontal-end: var(--atp-space-m);
  }

  .card-header.density-wide,
  .card-footer.density-wide {
    --atp-card-gutter-vertical: var(--atp-space-s);
    --atp-card-gutter-horizontal-start: var(--atp-space-m);
    --atp-card-gutter-horizontal-end: var(--atp-space-m);
  }

  /* colors */
  .header-fill-light-slate .card-header-wrapper {
    background: var(--atp-element-fill-primary-weak-enabled);
  }

  .color-red,
  .header-fill-red .card-header-wrapper {
    background: var(--atp-element-fill-red-weak-enabled);
  }

  .color-red.border-decoration-start {
    --atp-card-border-decoration-color: var(
      --atp-danger-primary-strong-enabled
    ); /* TODO: update to --atp-element-fill-red-strong-enabled, once it's available */
  }

  .color-orange,
  .header-fill-orange .card-header-wrapper {
    background: var(--atp-element-fill-orange-weak-enabled);
  }

  .color-orange.border-decoration-start {
    --atp-card-border-decoration-color: var(--atp-element-fill-orange-strong-enabled);
  }

  .color-green,
  .header-fill-green .card-header-wrapper {
    background: var(--atp-element-fill-green-weak-enabled);
  }

  .color-green.border-decoration-start {
    --atp-card-border-decoration-color: var(--atp-element-fill-green-strong-enabled);
  }

  .color-blue,
  .header-fill-blue .card-header-wrapper {
    background: var(--atp-element-fill-blue-weak-enabled);
  }

  .color-blue.border-decoration-start {
    --atp-card-border-decoration-color: var(--atp-element-fill-blue-strong-enabled);
  }

  .color-purple,
  .header-fill-purple .card-header-wrapper {
    background: var(--atp-element-fill-purple-weak-enabled);
  }

  .color-purple.border-decoration-start {
    --atp-card-border-decoration-color: var(--atp-element-fill-purple-strong-enabled);
  }

  /* 
   * the "border" decoration is done as a positioned pseudo-element, so that it covers any divider
   * in the header and footer 
  */
  .border-decoration-start::before {
    content: '';
    display: block;
    position: absolute;
    z-index: var(--atp-z-index-over-base);

    inset-block: calc(
      var(--atp-card-border-width) * -1
    ); /* so the decoration covers the card's border */

    inset-inline-start: calc(
      var(--atp-card-border-width) * -1
    ); /* so the decoration covers the card's border */

    inline-size: var(--atp-card-border-decoration-width);
    background: var(--atp-card-border-decoration-color);
    border-radius: var(--atp-card-border-radius) 0 0 var(--atp-card-border-radius);
  }

  /* header corners */
  /* stylelint-disable no-descending-specificity -- so we can keep features grouped together */
  .card-header-wrapper {
    border-start-start-radius: var(--atp-card-border-radius);
    border-start-end-radius: var(--atp-card-border-radius);
  }

  .card.collapsible:not([open]) .card-header-wrapper {
    border-end-start-radius: var(--atp-card-border-radius);
    border-end-end-radius: var(--atp-card-border-radius);
  }

  /* collapsible */
  .card.collapsible summary {
    position: relative;
    list-style: none;
    display: flex;
    justify-content: space-between;
    align-items: center;
    inline-size: 100%;
    cursor: pointer;
  }

  .card-collapsible-header-icon {
    flex-grow: 1;
    display: flex;
    align-items: center;
    margin-inline: var(--atp-card-gutter-horizontal-start)
      calc(var(--atp-card-gutter-horizontal-end) * -1 + var(--atp-space-xs));
    rotate: 0deg;
    transition: 0.2s ease-out;
  }

  .card.collapsible[open] .card-collapsible-header-icon {
    rotate: 90deg;
    transition: 0.2s ease-out;
  }

  .card.collapsible:not([open]) .card-header-wrapper,
  .card.collapsible:not([open]) .card-footer-wrapper {
    border-width: 0;
    transition-delay: 300ms;
  }

  .card-collapsible-header-content {
    flex-grow: 9999;
  }

  .card.collapsible[animate] {
    overflow: hidden;
  }

  /* 
    animate the opening/closing. 

    disabling stylelint because while this uses properties without baseline support,
    it also gracefully degrades.
   */
  /* stylelint-disable */
  .card.collapsible::details-content {
    interpolate-size: allow-keywords;
  }

  .card.collapsible::details-content {
    block-size: 0;
    overflow: hidden;
    transition: all;
    transition-duration: 300ms;
    transition-behavior: allow-discrete;
  }

  .card.collapsible[open]::details-content {
    block-size: auto;
    overflow: visible;
    content-visibility: visible;
  }
  /* stylelint-enable */

  /* full bleed */
  .full-bleed .card-content-wrapper {
    padding: 0;
  }
`;
var e2 = Object.defineProperty, t2 = Object.getOwnPropertyDescriptor, H = (e, t, i, r) => {
  for (var a = r > 1 ? void 0 : r ? t2(t, i) : t, o = e.length - 1, s; o >= 0; o--)
    (s = e[o]) && (a = (r ? s(t, i, a) : s(a)) || a);
  return r && a && e2(t, i, a), a;
}, i2 = /* @__PURE__ */ ((e) => (e.DEFAULT = "default", e.RED = "red", e.ORANGE = "orange", e.GREEN = "green", e.BLUE = "blue", e.PURPLE = "purple", e))(i2 || {}), a2 = /* @__PURE__ */ ((e) => (e.DEFAULT = "default", e.RED = "red", e.ORANGE = "orange", e.GREEN = "green", e.BLUE = "blue", e.PURPLE = "purple", e.LIGHT_SLATE = "light-slate", e))(a2 || {}), r2 = /* @__PURE__ */ ((e) => (e.DEFAULT = "default", e.COMPACT = "compact", e.WIDE = "wide", e))(r2 || {}), o2 = /* @__PURE__ */ ((e) => (e.DEFAULT = "default", e.START = "start", e))(o2 || {}), s2 = /* @__PURE__ */ ((e) => (e.DEFAULT = "default", e.HEADER = "header", e.FOOTER = "footer", e.BOTH = "both", e))(s2 || {});
let A = class extends b {
  constructor() {
    super(...arguments), this.color = "default", this.density = "default", this.borderDecoration = "default", this.divider = "default", this.collapsible = !1, this.open = !1, this.headerFill = "default", this.fullBleed = !1, this.isAnimating = !1;
  }
  render() {
    return this.collapsible ? n`
          <details
            class=${this._getStyleClasses()}
            ?animate=${this.isAnimating}
            @transitionend=${() => this.isAnimating = !1}
            open=${this.open ? "true" : c}
            @toggle=${this._onDetailsToggle}
          >
            <summary class="card-header-wrapper">
              <div class="card-collapsible-header-icon">
                <atp-icon icon="chevron-right" height="16"></atp-icon>
              </div>
              <div class="card-collapsible-header-content">
                <slot name="header"></slot>
              </div>
            </summary>
            <div class="card-content-wrapper">
              <slot></slot>
            </div>
            <div class="card-footer-wrapper">
              <slot name="footer"></slot>
            </div>
          </details>
        ` : n` <div class=${this._getStyleClasses()}>
          <div class="card-header-wrapper">
            <slot name="header"></slot>
          </div>
          <div class="card-content-wrapper">
            <slot></slot>
          </div>
          <div class="card-footer-wrapper">
            <slot name="footer"></slot>
          </div>
        </div>`;
  }
  _getStyleClasses() {
    return v({
      card: !0,
      collapsible: this.collapsible,
      [`header-fill-${this.headerFill}`]: this.headerFill !== "default",
      "divider-header": this.divider === "header" || this.divider === "both",
      "divider-footer": this.divider === "footer" || this.divider === "both",
      [`density-${this.density}`]: this.density !== "default",
      "full-bleed": this.fullBleed,
      [`color-${this.color}`]: this.color !== "default",
      "border-decoration-start": this.borderDecoration !== "default" && this.headerFill === "default" && !this.collapsible
    });
  }
  _onDetailsToggle(e) {
    this.isAnimating = !0;
    const t = e.currentTarget.open;
    this.dispatchEvent(
      new CustomEvent("collapsibleCardToggleEvent", {
        detail: { open: t },
        bubbles: !0,
        composed: !0
      })
    );
  }
};
A.styles = [m, Ce];
H([
  l()
], A.prototype, "color", 2);
H([
  l()
], A.prototype, "density", 2);
H([
  l()
], A.prototype, "borderDecoration", 2);
H([
  l()
], A.prototype, "divider", 2);
H([
  l({ type: Boolean })
], A.prototype, "collapsible", 2);
H([
  l({ type: Boolean })
], A.prototype, "open", 2);
H([
  l()
], A.prototype, "headerFill", 2);
H([
  l({ type: Boolean })
], A.prototype, "fullBleed", 2);
H([
  d5()
], A.prototype, "isAnimating", 2);
A = H([
  u("atp-card")
], A);
let D1 = class extends b {
  constructor() {
    super(...arguments), this.density = "default";
  }
  render() {
    return n`
      <div class=${this._getStyleClasses()}>
        <slot></slot>
      </div>
    `;
  }
  _getStyleClasses() {
    return v({
      "card-header": !0,
      [`density-${this.density}`]: this.density !== "default"
      /* DEFAULT */
    });
  }
};
D1.styles = [Ce, m];
H([
  l()
], D1.prototype, "density", 2);
D1 = H([
  u("atp-card-header")
], D1);
let j1 = class extends b {
  constructor() {
    super(...arguments), this.density = "default";
  }
  render() {
    return n`
      <div class=${this._getStyleClasses()}>
        <slot></slot>
      </div>
    `;
  }
  _getStyleClasses() {
    return v({
      "card-footer": !0,
      [`density-${this.density}`]: this.density !== "default"
      /* DEFAULT */
    });
  }
};
j1.styles = [Ce, m];
H([
  l()
], j1.prototype, "density", 2);
j1 = H([
  u("atp-card-footer")
], j1);
const l2 = g`
  :host {
    --atp-tooltip-arrow-size: 6px;
  }

  .tooltip-container {
    position: relative;
    display: inline-block;
    border-radius: var(--atp-border-radius-s);
  }

  .tooltip-container:focus-visible {
    outline: var(--atp-focus-width) solid var(--atp-focus-color);
    outline-offset: var(--atp-focus-outline-offset);
  }

  .trigger-container {
    display: inline-block;
    cursor: help;
  }

  .display-block.tooltip-container,
  .display-block .trigger-container {
    display: block;
  }

  .tooltip {
    margin: 0;
    padding: 0;
    border: none;
    background: none;
    overflow: hidden;
    block-size: fit-content;
    inline-size: fit-content;
    opacity: 0;
    transition: opacity 0.2s;
    cursor: help;
  }

  .tooltip.tooltip-shown {
    opacity: 1;
    transition: opacity 0.2s;
  }

  .tooltip-content {
    position: relative;
    display: inline-block;
    max-inline-size: 250px;
    padding: var(--atp-space-xxs) var(--atp-space-xs);
    color: var(--atp-content-inverse-medium-enabled);
    text-align: start;
    font-size: var(--atp-font-size-body-xs);
    line-height: var(--atp-line-height-body-xs);
    font-weight: var(--atp-font-weight-regular);
    background: var(--atp-element-fill-primary-strong-enabled);
    border-radius: var(--atp-border-radius-s);
    margin: var(--atp-tooltip-arrow-size);
  }

  /* default position is above the trigger, so draw a downward arrow */
  .tooltip-content::after {
    box-sizing: border-box;
    content: '';
    display: block;
    position: absolute;
    inset-block-start: 100%;
    inset-inline-start: calc(50% - (var(--atp-tooltip-arrow-size) / 2));
    border-width: var(--atp-tooltip-arrow-size);
    border-style: solid;
    border-color: var(--atp-element-fill-primary-strong-enabled) transparent transparent transparent;
  }

  .arrow-right .tooltip-content::after {
    border-color: transparent transparent transparent var(--atp-element-fill-primary-strong-enabled);
    inset-block-start: calc(50% - var(--atp-tooltip-arrow-size));
    inset-inline-start: 100%;
  }

  .arrow-top .tooltip-content::after {
    border-color: transparent transparent var(--atp-element-fill-primary-strong-enabled) transparent;
    inset-block: auto 100%;
  }

  .arrow-left .tooltip-content::after {
    border-color: transparent var(--atp-element-fill-primary-strong-enabled) transparent transparent;
    inset-block-start: calc(50% - var(--atp-tooltip-arrow-size));
    inset-inline: auto 100%;
  }

  /* inline alignment */
  .inline-align-start .tooltip-content::after {
    inset-inline-start: var(--atp-space-xs);
  }

  .inline-align-end .tooltip-content::after {
    inset-inline: auto var(--atp-space-xs);
  }

  /* when tooltip content is empty */
  .tooltip-empty .trigger-container {
    cursor: initial;
  }

  .tooltip-empty .tooltip {
    display: none;
  }
`;
var n2 = Object.defineProperty, d2 = Object.getOwnPropertyDescriptor, W1 = (e, t, i, r) => {
  for (var a = r > 1 ? void 0 : r ? d2(t, i) : t, o = e.length - 1, s; o >= 0; o--)
    (s = e[o]) && (a = (r ? s(t, i, a) : s(a)) || a);
  return r && a && n2(t, i, a), a;
}, c2 = /* @__PURE__ */ ((e) => (e.INLINE_BLOCK = "inline-block", e.BLOCK = "block", e))(c2 || {}), p2 = /* @__PURE__ */ ((e) => (e.CENTER = "center", e.START = "start", e.END = "end", e))(p2 || {});
let g1 = class extends b {
  constructor() {
    super(...arguments), this.blockStartOffset = 0, this.inlineStartOffset = 0, this.inlineAlign = "center", this.display = "inline-block", this._containerRef = h1(), this._triggerRef = h1(), this._tooltipRef = h1(), this._isTriggerActive = !1, this._isTooltipActive = !1, this._suppressShowAfterScrolling = !1, this._onEscape = (e) => {
      e.key === "Escape" && (e.preventDefault(), this._tooltipRef.value?.hidePopover());
    }, this._onScroll = () => {
      this._hideTooltip(), (this._isTooltipActive || this._isTriggerActive) && (this._suppressShowAfterScrolling = !0);
    };
  }
  render() {
    return n`
      <span
        ${b1(this._containerRef)}
        class="${this._getClassesContainer()}"
        @mouseover=${this._onTriggerMouseover}
        @mouseout=${this._onTriggerMouseout}
        @focus=${this._onTriggerFocus}
        @blur=${this._onTriggerBlur}
        tabindex="0"
      >
        <span
          ${b1(this._triggerRef)}
          class="${this._getClassesTrigger()}"
          popovertarget="tooltip"
          aria-describedby="tooltip"
          @mouseover=${this._onTooltipMouseover}
          @mouseout=${this._onTooltipMouseout}
        >
          <slot name="trigger"></slot>
        </span>

        <span ${b1(this._tooltipRef)} class="tooltip" id="tooltip" role="tooltip" popover="hint">
          <span class="tooltip-content">
            <slot name="tooltip" id="tooltipSlot"></slot>
          </span>
        </span>
      </span>
    `;
  }
  _showTooltip() {
    if (!this._suppressShowAfterScrolling) {
      this._tooltipRef.value?.showPopover();
      const e = this._triggerRef.value?.getBoundingClientRect(), t = this._triggerRef.value?.offsetHeight, i = this._triggerRef.value?.offsetWidth, r = this._tooltipRef.value?.offsetHeight, a = this._tooltipRef.value?.offsetWidth;
      if (this._tooltipRef.value && e) {
        this._tooltipRef.value.style.top = `${e.top - r}px`, this._tooltipRef.value.style.left = `${e.left + i / 2 - a / 2}px`;
        const o = this._tooltipRef.value?.getBoundingClientRect();
        o.top - this.blockStartOffset < 0 && (this._tooltipRef.value?.classList.add("arrow-top"), this._tooltipRef.value.style.top = `${e.bottom}px`), o.left - this.inlineStartOffset < 0 && (this._tooltipRef.value?.classList.add("arrow-left"), this._tooltipRef.value.style.left = `${e.right}px`, this._tooltipRef.value.style.top = `${e.top + (t - r) / 2}px`), o.right > window.innerWidth && (this._tooltipRef.value?.classList.add("arrow-right"), this._tooltipRef.value.style.left = `${e.left - a}px`, this._tooltipRef.value.style.top = `${e.top + (t - r) / 2}px`), !this._tooltipRef.value.classList.contains("arrow-left") && !this._tooltipRef.value.classList.contains("arrow-right") && (this.inlineAlign === "start" && (this._tooltipRef.value?.classList.add("inline-align-start"), this._tooltipRef.value.style.left = `${e.left}px`), this.inlineAlign === "end" && (this._tooltipRef.value?.classList.add("inline-align-end"), this._tooltipRef.value.style.left = `${e.left + i - a}px`));
      }
      this._tooltipRef.value?.classList.add("tooltip-shown");
    }
  }
  _checkWhetherToHideTooltip() {
    !this._isTriggerActive && !this._isTooltipActive && (this._hideTooltip(), this._suppressShowAfterScrolling = !1);
  }
  _hideTooltip() {
    this._tooltipRef.value?.hidePopover(), this._tooltipRef.value?.classList.remove(
      "tooltip-shown",
      "arrow-top",
      "arrow-right",
      "arrow-left"
    );
  }
  _onTriggerMouseover() {
    this._isTriggerActive = !0, this._showTooltip();
  }
  _onTriggerMouseout() {
    this._isTriggerActive = !1, this._checkWhetherToHideTooltip();
  }
  _onTriggerFocus() {
    this._isTriggerActive = !0, this._showTooltip();
  }
  _onTriggerBlur() {
    this._isTriggerActive = !1, this._checkWhetherToHideTooltip();
  }
  _onTooltipMouseover() {
    this._isTooltipActive = !0;
  }
  _onTooltipMouseout() {
    this._isTooltipActive = !1, this._checkWhetherToHideTooltip();
  }
  connectedCallback() {
    super.connectedCallback(), window.addEventListener("keyup", this._onEscape), document.addEventListener("scroll", this._onScroll, !0);
  }
  disconnectedCallback() {
    super.disconnectedCallback(), window.removeEventListener("keyup", this._onEscape), document.removeEventListener("scroll", this._onScroll, !0);
  }
  firstUpdated() {
    const t = this.shadowRoot.querySelector("#tooltipSlot").assignedNodes();
    let i = 0;
    t.forEach((r) => {
      i += r.childNodes.length;
    }), i === 0 && this._containerRef.value.classList.add("tooltip-empty");
  }
  _getClassesContainer() {
    return v({
      "tooltip-container": !0,
      "display-block": this.display === "block"
      /* BLOCK */
    });
  }
  _getClassesTrigger() {
    return v({
      "trigger-container": !0,
      "display-block": this.display === "block"
      /* BLOCK */
    });
  }
};
g1.styles = [m, l2];
W1([
  l({ type: Number })
], g1.prototype, "blockStartOffset", 2);
W1([
  l({ type: Number })
], g1.prototype, "inlineStartOffset", 2);
W1([
  l()
], g1.prototype, "display", 2);
g1 = W1([
  u("atp-tooltip")
], g1);
const h2 = g`
  :host {
    display: block;
  }

  .anchor-bar {
    background: var(--atp-element-fill-inverse-weak-enabled);
  }
`;
var b2 = Object.defineProperty, u2 = Object.getOwnPropertyDescriptor, K1 = (e, t, i, r) => {
  for (var a = r > 1 ? void 0 : r ? u2(t, i) : t, o = e.length - 1, s; o >= 0; o--)
    (s = e[o]) && (a = (r ? s(t, i, a) : s(a)) || a);
  return r && a && b2(t, i, a), a;
};
let m1 = class extends b {
  constructor() {
    super(...arguments), this.scrollableViewportId = "", this.parentBarId = "", this.scrollOffsetTop = 0, this._anchorBarLinks = null, this._activeIndex = -1, this._sectionIds = [], this._intersectionObserver = null, this._observedEls = [], this._lockedIndex = null, this._isProgrammaticScroll = !1, this._scrollIdleTimer = null, this._lockEpsilonPx = 12, this._idleMs = 150, this._overshootPx = 1, this._onScroll = () => {
      if (this._scrollIdleTimer != null && (clearTimeout(this._scrollIdleTimer), this._scrollIdleTimer = null), this._isProgrammaticScroll) {
        this._scrollIdleTimer = window.setTimeout(() => {
          this._isProgrammaticScroll = !1, this._updateActiveSectionFromPositions();
        }, this._idleMs);
        return;
      }
      this._updateActiveSectionFromPositions();
    }, this._onHostClick = (e) => {
      const t = e.target?.closest?.("a");
      if (!t) return;
      const i = t.getAttribute("href") || "";
      if (!i.startsWith("#")) return;
      e.preventDefault(), e.stopImmediatePropagation?.(), e.stopPropagation();
      const r = i.slice(1), a = document.getElementById(r);
      if (!a) return;
      const o = this._sectionIds.indexOf(r);
      o >= 0 && (this._lockedIndex = o, this._selectLinkByIndex(o));
      const s = this._computeTargetScrollTop(a);
      this._isProgrammaticScroll = !0, requestAnimationFrame(() => this._scrollTo(s));
    }, this._setupObserverAndSections = () => {
      this._intersectionObserver && (this._observedEls.forEach((e) => this._intersectionObserver.unobserve(e)), this._intersectionObserver.disconnect()), this._intersectionObserver = null, this._observedEls = [], this._anchorBarLinks = this.querySelectorAll(
        '.atp-anchor-bar-list a, a[href^="#"]'
      ), this._sectionIds = [], this._anchorBarLinks.forEach((e) => {
        const t = (e.getAttribute("href") || "").replace("#", "");
        this._sectionIds.push(t);
      }), this._intersectionObserver = new IntersectionObserver(this._handleIntersection, {
        root: this._getContainer(),
        rootMargin: `-${this.scrollOffsetTop}px 0px 0px 0px`,
        threshold: [0, 0.01, 0.25, 0.5, 0.75, 1]
      }), this._observedEls = [], this._sectionIds.forEach((e) => {
        if (!e) return;
        const t = document.getElementById(e);
        t && (this._intersectionObserver.observe(t), this._observedEls.push(t));
      }), this._updateActiveSectionFromPositions();
    }, this._handleIntersection = (e) => {
      if (this._isProgrammaticScroll) {
        this._lockedIndex != null && this._activeIndex !== this._lockedIndex && this._selectLinkByIndex(this._lockedIndex);
        return;
      }
      this._updateActiveSectionFromPositions();
    };
  }
  // scroll past the line by 1px
  _getContainer() {
    return document.getElementById(this.scrollableViewportId);
  }
  /** Gets top activation boundry, it use this to compare to section positions to determine which is active  */
  _getActivationLineTop() {
    return this._getContainer().getBoundingClientRect().top + this.scrollOffsetTop;
  }
  _scrollTo(e) {
    this._getContainer().scrollTo({ top: e, behavior: "smooth" });
  }
  /** Compute target scrollTop for a given section, for either window or element root. */
  _computeTargetScrollTop(e) {
    const t = this._getContainer().getBoundingClientRect(), i = e.getBoundingClientRect();
    return this._getContainer().scrollTop + (i.top - t.top) - this.scrollOffsetTop - this._overshootPx;
  }
  _attachScrollListener() {
    this._getContainer().addEventListener("scroll", this._onScroll, { passive: !0 });
  }
  _detachScrollListener() {
    this._getContainer().removeEventListener("scroll", this._onScroll), this._scrollIdleTimer != null && (clearTimeout(this._scrollIdleTimer), this._scrollIdleTimer = null);
  }
  /** set active link */
  _selectLinkByIndex(e) {
    if (!this._anchorBarLinks || e < 0 || e >= this._anchorBarLinks.length) return;
    const t = this._anchorBarLinks[e];
    this.querySelectorAll("a[aria-current]").forEach((i) => i.removeAttribute("aria-current")), t.setAttribute("aria-current", "location"), this._activeIndex = e;
  }
  /** Logic for setting the active section  */
  _updateActiveSectionFromPositions() {
    if (this._lockedIndex != null) {
      const s = this._sectionIds[this._lockedIndex], p = s ? document.getElementById(s) : null;
      if (p) {
        const d = p.getBoundingClientRect().top - this._getActivationLineTop(), h = d > 0, f = d <= 0 && d > -this._lockEpsilonPx;
        if (h || f) {
          this._activeIndex !== this._lockedIndex && this._selectLinkByIndex(this._lockedIndex);
          return;
        }
      }
      this._lockedIndex = null;
    }
    if (!this._sectionIds.length || !this._anchorBarLinks?.length) return;
    const e = this._getActivationLineTop();
    let t = -1, i = -1 / 0, r = -1, a = 1 / 0;
    for (let s = 0; s < this._sectionIds.length; s++) {
      const p = this._sectionIds[s], d = p ? document.getElementById(p) : null;
      if (!d) continue;
      const h = d.getBoundingClientRect().top - e;
      h <= 0 && h > i && (i = h, t = s), h > 0 && h < a && (a = h, r = s);
    }
    const o = t >= 0 ? t : r >= 0 ? r : -1;
    o >= 0 && o !== this._activeIndex && this._selectLinkByIndex(o);
  }
  connectedCallback() {
    super.connectedCallback(), this.addEventListener("click", this._onHostClick, { capture: !0, passive: !1 }), this._attachScrollListener(), this._sentinel = document.createElement("div"), this._sentinel.setAttribute("aria-hidden", "true"), this._sentinel.style.cssText = `
      height:1px; pointer-events:none; inline-size:100%; block-size:1px; visibility:hidden;
    `;
    const e = document.getElementById(this.parentBarId);
    e ? e?.before(this._sentinel) : this.parentElement?.insertBefore(this._sentinel, this), this._rootEl = this._getContainer(), this._io = new IntersectionObserver(
      ([t]) => {
        const i = t.intersectionRatio === 0;
        this.classList.toggle("at-top", i);
      },
      {
        root: this._rootEl,
        threshold: [0, 1]
      }
    ), this._io.observe(this._sentinel);
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this.removeEventListener("click", this._onHostClick, { capture: !0 }), this._detachScrollListener(), this._intersectionObserver && (this._observedEls.forEach((e) => this._intersectionObserver.unobserve(e)), this._intersectionObserver.disconnect()), this._intersectionObserver = null, this._observedEls = [], this._lockedIndex = null, this._scrollIdleTimer != null && (clearTimeout(this._scrollIdleTimer), this._scrollIdleTimer = null), this._io?.disconnect(), this._sentinel?.parentNode && this._sentinel.parentNode.removeChild(this._sentinel), this._sentinel = void 0;
  }
  render() {
    return n`
      <nav aria-label="Sections on this page" class="anchor-bar">
        <slot @slotchange=${this._setupObserverAndSections}></slot>
      </nav>
    `;
  }
};
m1.styles = [m, h2];
K1([
  l()
], m1.prototype, "scrollableViewportId", 2);
K1([
  l()
], m1.prototype, "parentBarId", 2);
K1([
  l({ type: Number })
], m1.prototype, "scrollOffsetTop", 2);
m1 = K1([
  u("atp-anchor-bar")
], m1);
export {
  K as Alert,
  L5 as AlertAppearance,
  $5 as AlertColor,
  m1 as AnchorBar,
  V1 as Breadcrumbs,
  z5 as BreadcrumbsSize,
  y as Button,
  he as ButtonAppearance,
  te as ButtonSize,
  A as Card,
  o2 as CardBorderDecoration,
  i2 as CardColor,
  r2 as CardDensity,
  s2 as CardDivider,
  j1 as CardFooter,
  D1 as CardHeader,
  a2 as CardHeaderFill,
  x as Checkbox,
  I as Dialog,
  U5 as DialogDrawer,
  N5 as DialogPosition,
  P1 as Divider,
  W5 as DividerOrientation,
  _ as Dropdown,
  Ct as DropdownPosition,
  O as Header,
  D as Icon,
  ee as IconPosition,
  k as Input,
  Qt as LabelPosition,
  R1 as ListBounded,
  ie as ListBoundedItem,
  Y as MediaObject,
  wt as MediaObjectColor,
  l1 as Meter,
  $t as MeterAppearance,
  S as Pill,
  zt as PillAppearance,
  Mt as PillColor,
  C1 as Progress,
  Ot as ProgressAppearance,
  T as RadioButtonGroup,
  Tt as RadioButtonGroupDirection,
  B as Sidebar,
  s1 as Spinner,
  a1 as SpinnerColor,
  H1 as SpinnerSize,
  v1 as Status,
  Ft as StatusColor,
  qt as StatusSize,
  n1 as TabSet,
  j as Tag,
  nt as TagAppearance,
  dt as TagColor,
  w as Toggle,
  g1 as Tooltip,
  c2 as TooltipDisplay,
  p2 as TooltipInlineAlign,
  Y5 as VisualColor,
  q as VisualPosition,
  X5 as VisualSize
};
